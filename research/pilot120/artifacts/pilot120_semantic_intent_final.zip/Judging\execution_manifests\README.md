# Blind-judge execution manifests

Included manifests prove prediction-blind input hashes, model revisions, fresh contexts, output hashes, and record counts for Judge A Pass 1, Judge A Pass 2, and Judge B Pass 1.

Judge B Pass 2 output was retrieved and locally validated at 120/120 rows; its remote manifest file could not be retrieved during the final packaging pass because the cluster transfer timed out. The validated output JSONL and its combined Judge-B SHA-256 remain included under `Judging/Judge_B/`; no metric depends on the missing duplicate run manifest.
