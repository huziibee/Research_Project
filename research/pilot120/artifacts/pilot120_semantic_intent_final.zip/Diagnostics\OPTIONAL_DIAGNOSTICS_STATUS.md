# Optional embedding and NLI diagnostics

Status: **NOT COMPUTED**.

The optional diagnostics runner is present in the supplied package, but the local environment lacks `sentence_transformers`. These diagnostics are convergent only and were never used to define Semantic Goal Correctness, select a threshold, or alter any judgment.
