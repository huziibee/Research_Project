# Pilot-120 semantic-intent final adversarial audit

## Result

**PASS** for the completed prediction-blind, model-judged semantic-intent addendum. This is not an official primary-correctness determination under the existing project governance policy.

## Integrity and freeze

- Supplied semantic package SHA-256: `541f2990305a54ccabee9f2e24c77da5b1597b54453956374c97f74b47ab3116`.
- Frozen T41 closure SHA-256: `aea638cf05eab66610429e69f0d88f112eb09b4bd5582bb0d1b23d0a6dd3c21a`.
- All 138 supplied package-manifest entries were previously verified with zero mismatches.
- Final semantic judgments: 240/240 rows; SHA-256 `34f47470d61ae1f9743dce6ecef07c025bc14d4af356824a988b1e5c132d4419`.
- Final judgments comprise 197 A/B exact consensuses and 43 prediction-blind Judge-C adjudications. The sealed mapping was opened only after that SHA was written.

## Blindness and command-copy checks

- Blind packet uses opaque IDs and excludes system identity, terminal route, correctness outcomes, CPC, ambiguity outcomes, and aggregate results.
- Judge-C packet had 43 rows, exact ID coverage, and no forbidden top-level identity/outcome key.
- Exact source-command copies in prepared semantic candidate excerpts: `0/240`.

## Scoring and failure analysis

- Final SGC/FIC calculations use only the frozen final semantic judgment file, frozen speech-act predictions, sealed mapping after freeze, and frozen route/CPC evidence.
- Wilson intervals are produced by the supplied implementation.
- Layer allocation is first-observable: semantic goal, speech act, then frozen CPC/resolution. Frozen T41 emits no exact CPC frame, so no route error qualifies for Layer 4.

## Verification

- Judge-C input validation: 43/43, zero errors.
- Final judgment validation: 240/240, zero errors.
- Supplied metric tests: 7 passed.
- New prospective-V2 and semantic edge-case tests: 10 passed.

## Optional diagnostics

Embedding/NLI diagnostics are **NOT COMPUTED**: `sentence_transformers` is absent from the local environment. No threshold was tuned and no optional diagnostic influenced SGC.

## Claim boundary

For frozen T39, SGC is **observable semantic-goal trace correctness**, not hidden-model-intent or structured-intent-summary accuracy. The generative judges make this a completed prediction-blind model-judged addendum. Existing project policy still prohibits presenting it as the primary official correctness judge without governance approval.
