# Pilot-120 semantic-intent final results

## What this measures

Frozen T39 did not request or preserve a structured `intent_summary`. These results therefore measure **observable semantic-goal trace correctness**, not hidden internal model intent. Semantic Goal Correctness (SGC) is the conjunction of five prediction-blind binary checks; Full Intent Correctness (FIC) is SGC AND frozen speech-act correctness.

## Main results

| System | SAA | SGC | FIC | SGC correct + route wrong |
|---|---:|---:|---:|---:|
| Degree router | 76/120 (63.3%) | 113/120 (94.2%) | 70/120 (58.3%) | 65/120 (54.2%) |
| Full manager | 76/120 (63.3%) | 113/120 (94.2%) | 70/120 (58.3%) | 83/120 (69.2%) |
| Context blind | 82/120 (68.3%) | 95/120 (79.2%) | 69/120 (57.5%) | 75/120 (62.5%) |

For the full manager, `P(SGC correct | route wrong) = 83/87 = 95.4%`. The context-ablation difference in SGC is +15.0 percentage points for full context (exact McNemar p=0.000912).

## Indirect requests

For the full manager, indirect-request SGC is 29/29 (100.0%), but SAA is 1/29 (3.45%) and FIC is 1/29 (3.45%). This is the central separation: the observable goal trace may survive while communicative-force classification and downstream interaction strategy fail.

## First-observable route-error layer: full manager

- Layer 1, semantic goal wrong: 4.
- Layer 2, semantic goal correct but speech act wrong: 33.
- Layer 3, goal and speech act correct but frozen CPC/resolution wrong: 50.
- Layer 4, interpretation sufficient but pure router/policy wrong: 0 observable cases.

Layer 4 is not evidenced because frozen T39 emitted no exact CPC frame; it must not be inferred from absence.

## Reliability and boundaries

Two independent prediction-blind model judges agreed exactly on all five fields for 197/240 evaluations (82.08%); 43 disagreements were adjudicated prediction-blind by Judge C. Optional embedding/NLI diagnostics are not computed because `sentence_transformers` is unavailable, and they were never used to set SGC.

This is a completed model-judged addendum. Existing project governance still prevents treating a generative judge as the primary official correctness authority without recorded approval.
