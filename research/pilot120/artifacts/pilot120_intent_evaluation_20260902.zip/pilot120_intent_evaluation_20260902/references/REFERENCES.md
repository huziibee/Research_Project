# Research references for Pilot-120 semantic intent evaluation

This protocol is a **research-backed synthesis** tailored to the Pilot-120 question. No single published paper defines the exact metric `Semantic Goal Correctness` for this benchmark. The design combines established task-oriented intent evaluation, dialogue-act semantics, paraphrase/NLI evidence, semantic-similarity diagnostics, and reliability findings for LLM judges.

## Core task decomposition

1. **FitzGerald, J. et al. (2023). MASSIVE: A 1M-Example Multilingual Natural Language Understanding Dataset with 51 Typologically-Diverse Languages. ACL 2023.** DOI: 10.18653/v1/2023.acl-long.235. https://aclanthology.org/2023.acl-long.235/
   - MASSIVE reports intent-classification accuracy separately from slot-filling F1 and exact match.
   - Supports keeping closed-class intent/communicative-force evaluation separate from CPC/slot evaluation.

2. **Gupta, S., Shah, R., Mohit, M., Kumar, A., & Lewis, M. (2018). Semantic Parsing for Task Oriented Dialog using Hierarchical Representations. EMNLP 2018.** DOI: 10.18653/v1/D18-1300. https://aclanthology.org/D18-1300/
   - Describes task-oriented semantic frames as intents plus slots and motivates structured separation of these layers.

3. **Gupta, A., Hewitt, J., & Kirchhoff, K. (2019). Simple, Fast, Accurate Intent Classification and Slot Labeling for Goal-Oriented Dialogue Systems. SIGDIAL 2019.** DOI: 10.18653/v1/W19-5906. https://aclanthology.org/W19-5906/
   - Explicitly treats intent classification and slot labeling as separate SLU tasks.

4. **Bunt, H. et al. (2012). ISO 24617-2: A semantically-based standard for dialogue annotation. LREC 2012.** https://aclanthology.org/L12-1296/
   - Dialogue-act annotation distinguishes communicative functions from semantic content.

5. **Malchanau, A., Petukhova, V., & Bunt, H. (2024). Fusing ISO 24617-2 Dialogue Acts and Application-Specific Semantic Content Annotations. ISA @ LREC-COLING 2024.** https://aclanthology.org/2024.isa-1.15/
   - Explicitly describes a dialogue act as involving semantic content plus communicative function. This closely motivates the Pilot split between speech-act correctness and semantic-goal correctness.

6. **Mannekote, A., Nam, J., Li, Z., Boyer, K. E., & Dorr, B. J. (2025). Making Task-Oriented Dialogue Datasets More Natural by Synthetically Generating Indirect User Requests. COLING 2025.** https://aclanthology.org/2025.coling-main.696/
   - Shows indirect requests require pragmatic/world-knowledge reasoning and are a distinct NLU challenge. Relevant to Pilot's `indirect_request` failures.

## Semantic equivalence and similarity

7. **Cer, D., Diab, M., Agirre, E., Lopez-Gazpio, I., & Specia, L. (2017). SemEval-2017 Task 1: Semantic Textual Similarity Multilingual and Crosslingual Focused Evaluation. SemEval 2017.** DOI: 10.18653/v1/S17-2001. https://aclanthology.org/S17-2001/
   - Establishes semantic textual similarity as a graded measure of sentence meaning similarity.
   - Useful for a continuous diagnostic, not a binary intent-correctness rule.

8. **Reimers, N., & Gurevych, I. (2019). Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks. EMNLP-IJCNLP 2019.** DOI: 10.18653/v1/D19-1410. https://aclanthology.org/D19-1410/
   - Provides sentence embeddings designed for semantic similarity and cosine comparison.
   - Used here only for convergent diagnostics.

9. **Zhang, Y., Baldridge, J., & He, L. (2019). PAWS: Paraphrase Adversaries from Word Scrambling. NAACL 2019.** DOI: 10.18653/v1/N19-1131. https://aclanthology.org/N19-1131/
   - Demonstrates that high lexical overlap can occur between non-paraphrases, including argument/order reversals.
   - Strong reason not to use word overlap or embedding similarity alone as correctness.

10. **Hanna, M., & Bojar, O. (2021). A Fine-Grained Analysis of BERTScore. WMT 2021.** https://aclanthology.org/2021.wmt-1.59/
    - Finds BERTScore can be less sensitive to smaller errors, especially when candidate/reference are lexically or stylistically similar.
    - Supports treating embedding metrics as secondary evidence rather than the primary pass/fail rule.

11. **Hauer, B., Riley, J., & Kondrak, G. (2024). Paraphrase Identification via Textual Inference. *SEM 2024.** DOI: 10.18653/v1/2024.starsem-1.11. https://aclanthology.org/2024.starsem-1.11/
    - Formalizes a connection between paraphrase identification and natural-language inference and demonstrates NLI-based paraphrase identification.
    - Supports bidirectional entailment as a semantic-equivalence diagnostic.

## Reliable judgment protocol

12. **Lee, Y. et al. (2025). CheckEval: A reliable LLM-as-a-Judge framework for evaluating text generation using checklists. EMNLP 2025.** DOI: 10.18653/v1/2025.emnlp-main.796. https://aclanthology.org/2025.emnlp-main.796/
    - Replaces vague Likert evaluation with decomposed binary checks.
    - Reports substantially improved cross-evaluator agreement and reduced variance.
    - Primary inspiration for the five binary Semantic Goal Correctness checks.

13. **Liu, Y. et al. (2023). G-Eval: NLG Evaluation using GPT-4 with Better Human Alignment. EMNLP 2023.** DOI: 10.18653/v1/2023.emnlp-main.153. https://aclanthology.org/2023.emnlp-main.153/
    - Supports form-based LLM evaluation while noting potential bias toward LLM-generated text.

14. **Shi, L. et al. (2025). Judging the Judges: A Systematic Study of Position Bias in LLM-as-a-Judge. IJCNLP-AACL 2025.** DOI: 10.18653/v1/2025.ijcnlp-long.18. https://aclanthology.org/2025.ijcnlp-long.18/
    - Demonstrates position/comparison bias across LLM judges.
    - Motivates anonymization, independent item scoring, and two fresh-context passes rather than showing paired conditions side-by-side.

## Observable trace is not guaranteed internal reasoning

15. **Turpin, M., Michael, J., Perez, E., & Bowman, S. R. (2023). Language Models Don't Always Say What They Think: Unfaithful Explanations in Chain-of-Thought Prompting.** arXiv:2305.04388. https://arxiv.org/abs/2305.04388
    - Shows chain-of-thought explanations can systematically misrepresent causes of model predictions.

16. **Parcalabescu, L., & Frank, A. (2024). On Measuring Faithfulness or Self-consistency of Natural Language Explanations. ACL 2024.** DOI: 10.18653/v1/2024.acl-long.329. https://aclanthology.org/2024.acl-long.329/
    - Argues many explanation-faithfulness tests measure output self-consistency rather than access to model internals.
    - Justifies the term `observable semantic-goal trace correctness` for frozen T39.

## Optional implementation models

17. **SentenceTransformers `all-mpnet-base-v2` model card.** https://huggingface.co/sentence-transformers/all-mpnet-base-v2
    - Apache-2.0 sentence-similarity encoder. Optional continuous diagnostic.

18. **SentenceTransformers `cross-encoder/nli-deberta-v3-large` model card.** https://huggingface.co/cross-encoder/nli-deberta-v3-large
    - Apache-2.0 NLI cross-encoder trained on SNLI/MultiNLI; model card gives output order `contradiction, entailment, neutral` and reports SNLI test 92.20% / MNLI mismatched 90.49%.
    - Optional bidirectional-entailment diagnostic only.

## What the literature does NOT justify

The references above do **not** justify:
- a universal cosine-similarity threshold for intent correctness;
- BLEU/ROUGE/string match as the primary semantic-intent metric;
- treating a model's chain-of-thought as faithful internal cognition;
- one unblinded judge score as ground truth;
- folding CPC slot correctness into semantic-goal correctness.
