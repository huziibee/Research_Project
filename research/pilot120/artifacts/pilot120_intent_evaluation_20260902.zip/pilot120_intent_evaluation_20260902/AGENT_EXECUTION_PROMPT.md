# Execute Pilot-120 semantic intent judging and final scoring

Use the attached package exactly as specified in `README.md` and `protocol/JUDGE_GUIDE.md`.

Goal: determine whether the frozen manager states the correct underlying user goal even when its terminal route is wrong. Do not score CPC as intent.

## Mandatory design

1. Use two independent prediction-blind semantic judges.
2. For each judge, run `blind_judge_pass_1_120.jsonl` and `blind_judge_pass_2_120.jsonl` in fresh evaluator contexts. Do not expose one pass's judgments to the other.
3. Do not expose system identity, route, T39 performance, CPC scores, or `SEALED_evaluation_mapping.jsonl` before the semantic judgments are frozen.
4. Use the five binary checks in `JUDGE_GUIDE.md`; do not substitute a 1-10 similarity rating.
5. Merge judges, recompute per-field raw agreement and Cohen kappa, and send only disagreements to a fresh prediction-blind adjudicator.
6. Assemble all 240 final judgments and freeze their SHA-256 before opening the sealed mapping or computing system results.
7. Run `finalize_intent_results.py` exactly as documented.
8. Optionally run SBERT + bidirectional NLI diagnostics, but never use an uncalibrated threshold as the primary correctness label.
9. Return all judge files, agreement report, adjudication ledger, frozen judgment SHA, final JSON/CSV results, and exact commands/logs.

## Required final interpretation

Explicitly report:
- structured speech-act accuracy;
- Semantic Goal Correctness;
- Full Intent Correctness;
- `semantic goal correct + route wrong` count;
- `P(goal correct | route wrong)`;
- `P(route wrong | goal correct)`;
- full-context vs context-blind paired semantic-goal difference and exact McNemar p-value;
- per-class speech-act behavior, especially indirect requests.

Use the term **observable Semantic Goal Trace Correctness** for frozen T39. Do not claim access to hidden/internal reasoning because the frozen prompt never emitted a structured intent summary.

Do not modify frozen T39. Future `intent_summary` changes belong to a new separately versioned system.
