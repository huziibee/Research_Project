#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, random
from pathlib import Path
from intent_eval_common import load_jsonl, write_jsonl, clean_observable_trace, extract_intent_candidate_text, sha256_text


def by_id(rows):
    d={}
    for r in rows:
        rid=r['record_id']
        if rid in d: raise ValueError(f'duplicate:{rid}')
        d[rid]=r
    return d


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--closure-root', required=True)
    ap.add_argument('--review-root', required=True)
    ap.add_argument('--out', required=True)
    args=ap.parse_args()
    c=Path(args.closure_root); rr=Path(args.review_root); out=Path(args.out); out.mkdir(parents=True,exist_ok=True)

    A=by_id(load_jsonl(c/'reviews/normalized_historical_review_A.jsonl'))
    B=by_id(load_jsonl(c/'reviews/normalized_historical_review_B.jsonl'))
    key=by_id(load_jsonl(c/'key/pilot120_interpretation_key_candidate_v2.jsonl'))
    src=by_id(load_jsonl(c/'reference/source_canonical.jsonl'))
    ids=list(src)
    if not (set(ids)==set(A)==set(B)==set(key)) or len(ids)!=120:
        raise SystemExit('pilot_id_binding_failed')

    # Verify the relevant observable raw traces are stable across all accepted R1-R5.
    systems=['degree_based_router','full_type_risk_aware_manager','context_blind_manager']
    reps={}
    for rep in ['R1','R2','R3','R4','R5']:
        root=rr/f'cluster_outputs/{rep}/manager/predictions'
        reps[rep]={s:by_id(load_jsonl(root/f'{s}.predictions.jsonl')) for s in systems}
        for s in systems:
            if set(reps[rep][s]) != set(ids): raise SystemExit(f'prediction_id_binding_failed:{rep}:{s}')
    trace_stability={}
    for s in systems:
        stable=sum(all(reps[rep][s][rid].get('raw_output')==reps['R1'][s][rid].get('raw_output') for rep in ['R2','R3','R4','R5']) for rid in ids)
        trace_stability[s]=stable
        if stable!=120: raise SystemExit(f'raw_trace_drift:{s}:{stable}/120')

    D=reps['R1']['degree_based_router']; F=reps['R1']['full_type_risk_aware_manager']; C=reps['R1']['context_blind_manager']
    same_raw=sum(D[i]['raw_output']==F[i]['raw_output'] for i in ids)
    same_speech=sum(D[i]['parsed']['analysis'].get('speech_act')==F[i]['parsed']['analysis'].get('speech_act') for i in ids)
    if same_raw != 120: raise SystemExit(f'full_degree_raw_trace_not_identical:{same_raw}/120')

    gold=[]; traces=[]; verbatim_before=0; verbatim_after=0
    for rid in ids:
        s=src[rid]
        a=A[rid]['historical_raw']; b=B[rid]['historical_raw']
        ga=a.get('intent_text'); gb=b.get('intent_text')
        if not ga or not gb: raise SystemExit(f'missing_pre_t39_intent_reference:{rid}')
        gold.append({
            'record_id':rid,
            'gold_speech_act':key[rid]['gold']['intent']['label'],
            'reference_A_intent_text':ga,
            'reference_B_intent_text':gb,
            'reference_A_sha256':sha256_text(ga),
            'reference_B_sha256':sha256_text(gb),
            'source':{
                'command':s.get('command'),
                'dialogue_history':s.get('dialogue_history'),
                'scene_context':s.get('scene_context'),
                'capability_context':s.get('capability_context'),
            },
            'gold_provenance':'two_pre_T39_prediction_blind_historical_annotator_intent_text_references_plus_frozen_speech_act_taxonomy',
        })
        for cond, row in [('FULL_CONTEXT_SHARED',F[rid]),('CONTEXT_BLIND',C[rid])]:
            raw=row.get('raw_output') or ''; cmd=s.get('command') or ''
            if cmd and cmd.lower() in raw.lower(): verbatim_before+=1
            clean=clean_observable_trace(raw, source_command=cmd)
            excerpt=extract_intent_candidate_text(raw, source_command=cmd)
            if cmd and cmd.lower() in excerpt.lower(): verbatim_after+=1
            traces.append({
                'record_id':rid,
                'analysis_condition':cond,
                'structured_speech_act':row['parsed']['analysis'].get('speech_act'),
                'raw_output_sha256':sha256_text(raw),
                'cleaned_observable_trace':clean,
                'intent_candidate_text':excerpt,
                'verbatim_command_omitted':bool(cmd and cmd.lower() in raw.lower()),
                'trace_provenance':'frozen_T39_R1_raw_output; raw_output equality reverified across accepted R1-R5',
            })

    write_jsonl(out/'intent_gold_references_120.jsonl',gold)
    write_jsonl(out/'intent_observable_traces_240.jsonl',traces)

    # Stable anonymized evaluation rows. No record ID, route, system name, or correctness.
    # Create two fresh-context passes so the same source record never appears twice in one pass.
    rng=random.Random(41021); rows=[]; rows_by_record={}
    gold_by={x['record_id']:x for x in gold}
    for t in traces:
        g=gold_by[t['record_id']]
        opaque=hashlib.sha256(f"intent-v1|{t['record_id']}|{t['analysis_condition']}".encode()).hexdigest()[:20]
        jr={
            'evaluation_id':'IE-'+opaque,
            'source':g['source'],
            'gold_reference_A':g['reference_A_intent_text'],
            'gold_reference_B':g['reference_B_intent_text'],
            'candidate_observable_trace':t['cleaned_observable_trace'],
            'candidate_intent_excerpt':t['intent_candidate_text'],
            'verbatim_source_command_policy':'Exact source-command copies are replaced and cannot by themselves earn semantic-goal credit.',
            'instructions_scope':'Judge semantic user-goal only. Ignore terminal route and CPC/slot correctness.',
        }
        rows.append(jr); rows_by_record.setdefault(t['record_id'],[]).append((t['analysis_condition'],jr))
    rng.shuffle(rows); write_jsonl(out/'blind_semantic_goal_judge_packet_240.jsonl',rows)

    pass1=[]; pass2=[]
    assign_rng=random.Random(41022)
    for rid in ids:
        pair=rows_by_record[rid]
        if len(pair)!=2: raise SystemExit(f'condition_pair_failure:{rid}:{len(pair)}')
        pair=sorted(pair,key=lambda x:x[0])
        if assign_rng.random()<0.5:
            pass1.append(pair[0][1]); pass2.append(pair[1][1])
        else:
            pass1.append(pair[1][1]); pass2.append(pair[0][1])
    random.Random(51021).shuffle(pass1); random.Random(51022).shuffle(pass2)
    write_jsonl(out/'blind_judge_pass_1_120.jsonl',pass1)
    write_jsonl(out/'blind_judge_pass_2_120.jsonl',pass2)

    mapping=[]
    for r in rows:
        matches=[]
        for t in traces:
            eid='IE-'+hashlib.sha256(f"intent-v1|{t['record_id']}|{t['analysis_condition']}".encode()).hexdigest()[:20]
            if eid==r['evaluation_id']: matches.append(t)
        if len(matches)!=1: raise SystemExit(f'mapping_failure:{r["evaluation_id"]}:{len(matches)}')
        t=matches[0]; mapping.append({'evaluation_id':r['evaluation_id'],'record_id':t['record_id'],'analysis_condition':t['analysis_condition']})
    write_jsonl(out/'SEALED_evaluation_mapping.jsonl',mapping)

    audit={
        'pilot_records':len(ids),'gold_references':len(gold),'unique_analysis_traces':len(traces),
        'full_degree_raw_output_identical':same_raw,'full_degree_structured_speech_act_identical':same_speech,
        'raw_trace_stability_R1_R5':trace_stability,
        'nonempty_gold_A':sum(bool(x['reference_A_intent_text']) for x in gold),
        'nonempty_gold_B':sum(bool(x['reference_B_intent_text']) for x in gold),
        'nonempty_candidate_excerpt':sum(bool(x['intent_candidate_text']) for x in traces),
        'nonempty_cleaned_trace':sum(bool(x['cleaned_observable_trace']) for x in traces),
        'raw_outputs_containing_exact_source_command':verbatim_before,
        'candidate_excerpts_still_containing_exact_source_command_after_omission':verbatim_after,
        'randomization_seed':41021,
        'pass_assignment_seed':41022,
        'judge_pass_1_rows':len(pass1),'judge_pass_2_rows':len(pass2),
        'record_id_exposed_in_blind_packet':False,
    }
    (out/'build_audit.json').write_text(json.dumps(audit,indent=2,sort_keys=True)+'\n')
    print(json.dumps(audit,indent=2))

if __name__=='__main__': main()
