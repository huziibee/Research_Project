#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from collections import Counter,defaultdict
from pathlib import Path
from intent_eval_common import load_jsonl, wilson_interval

LABELS=['directive_command','indirect_request','information_question','permission_request','prohibition','conditional_directive','multi_intent','other_non_actionable']

def macro_f1(golds,preds):
    fs=[]
    for lab in LABELS:
        tp=sum(g==lab and p==lab for g,p in zip(golds,preds)); fp=sum(g!=lab and p==lab for g,p in zip(golds,preds)); fn=sum(g==lab and p!=lab for g,p in zip(golds,preds))
        if tp+fp+fn==0: continue
        prec=tp/(tp+fp) if tp+fp else 0; rec=tp/(tp+fn) if tp+fn else 0
        fs.append(2*prec*rec/(prec+rec) if prec+rec else 0)
    return sum(fs)/len(fs) if fs else None

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--gold',required=True); ap.add_argument('--review-root',required=True); ap.add_argument('--out',required=True); args=ap.parse_args()
    gold={r['record_id']:r['gold_speech_act'] for r in load_jsonl(args.gold)}
    root=Path(args.review_root)/'cluster_outputs/R1/manager/predictions'
    systems=['degree_based_router','full_type_risk_aware_manager','context_blind_manager']
    result={}
    for sys in systems:
        rows=load_jsonl(root/f'{sys}.predictions.jsonl'); G=[];P=[]
        for r in rows:
            G.append(gold[r['record_id']]); P.append(r['parsed']['analysis']['speech_act'])
        k=sum(g==p for g,p in zip(G,P)); lo,hi=wilson_interval(k,len(G))
        per={}
        for lab in LABELS:
            ix=[i for i,g in enumerate(G) if g==lab]
            if ix:
                kk=sum(P[i]==lab for i in ix); l,h=wilson_interval(kk,len(ix)); per[lab]={'n':len(ix),'correct':kk,'accuracy':kk/len(ix),'wilson95':[l,h]}
        conf=Counter((g,p) for g,p in zip(G,P))
        result[sys]={'n':len(G),'correct':k,'accuracy':k/len(G),'wilson95':[lo,hi],'macro_f1':macro_f1(G,P),'per_gold_class':per,'confusion':{f'{g} -> {p}':n for (g,p),n in sorted(conf.items())}}
    Path(args.out).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__': main()
