#!/usr/bin/env python3
from __future__ import annotations
import argparse
from intent_eval_common import load_jsonl, write_jsonl

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--packet',required=True)
    ap.add_argument('--disagreements',required=True)
    ap.add_argument('--out',required=True)
    args=ap.parse_args()
    packet={r['evaluation_id']:r for r in load_jsonl(args.packet)}
    dis=load_jsonl(args.disagreements)
    rows=[]
    for d in dis:
        eid=d['evaluation_id']
        if eid not in packet: raise SystemExit(f'unknown_disagreement_id:{eid}')
        p=packet[eid]
        rows.append({
            **p,
            'disagreement_fields':d['disagreement_fields'],
            'judge_A':{k:v for k,v in d['judge_A'].items() if k!='rationale'} | {'rationale':d['judge_A'].get('rationale','')},
            'judge_B':{k:v for k,v in d['judge_B'].items() if k!='rationale'} | {'rationale':d['judge_B'].get('rationale','')},
            'adjudication_instruction':'Independently decide all five checklist fields from source, gold references, and candidate evidence. A/B are advisory evidence only. Remain prediction-blind.',
        })
    write_jsonl(args.out,rows)
    print(f'wrote {len(rows)} adjudication rows')
if __name__=='__main__': main()
