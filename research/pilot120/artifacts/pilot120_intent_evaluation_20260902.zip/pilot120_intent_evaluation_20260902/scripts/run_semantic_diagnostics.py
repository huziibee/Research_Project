#!/usr/bin/env python3
"""Optional diagnostics only: SBERT cosine + bidirectional NLI.

These scores MUST NOT be thresholded into the primary correctness label without a
separately frozen calibration study. Primary correctness comes from the blinded
binary checklist. This script exists for convergent validity / disagreement analysis.
"""
from __future__ import annotations
import argparse,json,math
from pathlib import Path
from intent_eval_common import load_jsonl, write_jsonl

def softmax(xs):
    m=max(xs); es=[math.exp(x-m) for x in xs]; s=sum(es); return [x/s for x in es]

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--packet',required=True); ap.add_argument('--out',required=True); ap.add_argument('--sbert-model',default='sentence-transformers/all-mpnet-base-v2'); ap.add_argument('--nli-model',default='cross-encoder/nli-deberta-v3-large'); args=ap.parse_args()
    try:
        from sentence_transformers import SentenceTransformer, CrossEncoder
    except Exception as e:
        raise SystemExit('Install sentence-transformers first: pip install sentence-transformers\n'+repr(e))
    emb=SentenceTransformer(args.sbert_model); nli=CrossEncoder(args.nli_model)
    rows=load_jsonl(args.packet); out=[]
    for r in rows:
        cand=r['candidate_intent_excerpt']
        refs=[r['gold_reference_A'],r['gold_reference_B']]
        vecs=emb.encode([cand]+refs,normalize_embeddings=True)
        cos=[float(vecs[0]@vecs[i]) for i in (1,2)]
        nli_refs=[]
        for ref in refs:
            # CrossEncoder label order for this model family: contradiction, entailment, neutral.
            logits=nli.predict([(cand,ref),(ref,cand)])
            probs=[softmax(list(map(float,x))) for x in logits]
            nli_refs.append({
                'candidate_to_reference':{'contradiction':probs[0][0],'entailment':probs[0][1],'neutral':probs[0][2]},
                'reference_to_candidate':{'contradiction':probs[1][0],'entailment':probs[1][1],'neutral':probs[1][2]},
                'mutual_entailment_min':min(probs[0][1],probs[1][1]),
            })
        out.append({
            'evaluation_id':r['evaluation_id'],
            'sbert_cosine_A':cos[0], 'sbert_cosine_B':cos[1], 'sbert_cosine_max':max(cos),'sbert_cosine_min':min(cos),
            'nli_A':nli_refs[0], 'nli_B':nli_refs[1],
            'nli_mutual_entailment_maxref':max(x['mutual_entailment_min'] for x in nli_refs),
            'nli_mutual_entailment_minref':min(x['mutual_entailment_min'] for x in nli_refs),
            'diagnostic_only':True,
        })
    write_jsonl(args.out,out)
    print(f'wrote {len(out)} rows')
if __name__=='__main__': main()
