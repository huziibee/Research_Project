#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
from intent_eval_common import load_jsonl, write_jsonl, INTENT_FIELDS, cohen_kappa_binary

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--judge-a',required=True); ap.add_argument('--judge-b',required=True); ap.add_argument('--consensus-out',required=True); ap.add_argument('--disagreements-out',required=True); ap.add_argument('--agreement-out',required=True); args=ap.parse_args()
 A={r['evaluation_id']:r for r in load_jsonl(args.judge_a)}; B={r['evaluation_id']:r for r in load_jsonl(args.judge_b)}
 if set(A)!=set(B): raise SystemExit('judge_id_sets_differ')
 con=[]; dis=[]; ag={}
 for fld in INTENT_FIELDS:
  av=[bool(A[i][fld]) for i in sorted(A)]; bv=[bool(B[i][fld]) for i in sorted(A)]
  ag[fld]={'raw_agreement':sum(x==y for x,y in zip(av,bv))/len(av),'cohen_kappa':cohen_kappa_binary(av,bv),'n':len(av)}
 for eid in sorted(A):
  dif=[f for f in INTENT_FIELDS if A[eid][f]!=B[eid][f]]
  if dif:
   dis.append({'evaluation_id':eid,'disagreement_fields':dif,'judge_A':A[eid],'judge_B':B[eid]})
  else:
   r={'evaluation_id':eid,'prediction_blind_attestation':True,'source':'A_B_consensus'}
   for f in INTENT_FIELDS:r[f]=A[eid][f]
   r['rationale_A']=A[eid]['rationale']; r['rationale_B']=B[eid]['rationale']; con.append(r)
 ag['overall']={'exact_all_fields_agreement':len(con)/len(A),'consensus_rows':len(con),'disagreement_rows':len(dis)}
 write_jsonl(args.consensus_out,con); write_jsonl(args.disagreements_out,dis); Path(args.agreement_out).write_text(json.dumps(ag,indent=2,sort_keys=True)+'\n')
 print(json.dumps(ag,indent=2))
if __name__=='__main__': main()
