#!/usr/bin/env python3
from __future__ import annotations
import argparse
from intent_eval_common import load_jsonl, write_jsonl, INTENT_FIELDS, semantic_goal_correct, semantic_goal_component_score, path_category

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--packet',required=True)
    ap.add_argument('--consensus',required=True)
    ap.add_argument('--adjudicated',required=True)
    ap.add_argument('--out',required=True)
    args=ap.parse_args()
    expected={r['evaluation_id'] for r in load_jsonl(args.packet)}
    con={r['evaluation_id']:r for r in load_jsonl(args.consensus)}
    adj={r['evaluation_id']:r for r in load_jsonl(args.adjudicated)}
    overlap=set(con)&set(adj)
    if overlap: raise SystemExit(f'consensus_adjudication_overlap:{len(overlap)}')
    if set(con)|set(adj) != expected:
        raise SystemExit(f'coverage_failure expected={len(expected)} got={len(set(con)|set(adj))}')
    rows=[]
    for eid in sorted(expected):
        src=con.get(eid) or adj[eid]
        if src.get('prediction_blind_attestation') is not True: raise SystemExit(f'blind_attestation:{eid}')
        r={'evaluation_id':eid,'prediction_blind_attestation':True,'decision_source':'A_B_consensus' if eid in con else 'blind_adjudication'}
        for f in INTENT_FIELDS:
            if not isinstance(src.get(f),bool): raise SystemExit(f'bad_bool:{eid}:{f}')
            r[f]=src[f]
        r['rationale']=src.get('rationale') or src.get('rationale_A','')+' | '+src.get('rationale_B','')
        r['semantic_goal_correct']=semantic_goal_correct(r)
        r['semantic_goal_component_score']=semantic_goal_component_score(r)
        r['goal_path_category']=path_category(r)
        rows.append(r)
    write_jsonl(args.out,rows)
    print(f'wrote {len(rows)} final judgments')
if __name__=='__main__': main()
