#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,json
from collections import Counter
from pathlib import Path
from intent_eval_common import load_jsonl, wilson_interval, semantic_goal_correct, semantic_goal_component_score, path_category, exact_mcnemar_p, paired_bootstrap_difference

SYSTEMS=[
 ('degree_based_router','FULL_CONTEXT_SHARED'),
 ('full_type_risk_aware_manager','FULL_CONTEXT_SHARED'),
 ('context_blind_manager','CONTEXT_BLIND'),
]

def get_gold_route(row):
    for k in ['gold_terminal_strategy','terminal_strategy','gold_strategy']:
        if k in row:
            v=row[k]
            if isinstance(v,dict): v=v.get('terminal_strategy') or v.get('strategy')
            if isinstance(v,str): return v
    return None

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--gold',required=True)
    ap.add_argument('--mapping',required=True)
    ap.add_argument('--judgments',required=True)
    ap.add_argument('--review-root',required=True)
    ap.add_argument('--core-gold',required=True)
    ap.add_argument('--out',required=True)
    ap.add_argument('--row-out',required=True)
    args=ap.parse_args()

    gold={r['record_id']:r for r in load_jsonl(args.gold)}
    mp={r['evaluation_id']:r for r in load_jsonl(args.mapping)}
    J={r['evaluation_id']:r for r in load_jsonl(args.judgments)}
    if set(mp)!=set(J): raise SystemExit('judgment_mapping_id_mismatch')
    core={r['record_id']:r for r in load_jsonl(args.core_gold)}
    if set(core)!=set(gold): raise SystemExit('core_gold_id_mismatch')
    routes={rid:get_gold_route(r) for rid,r in core.items()}
    if any(v is None for v in routes.values()): raise SystemExit('missing_core_gold_route')

    root=Path(args.review_root)/'cluster_outputs/R1/manager/predictions'
    preds={sys:{r['record_id']:r for r in load_jsonl(root/f'{sys}.predictions.jsonl')} for sys,_ in SYSTEMS}
    cond_j={(mp[eid]['record_id'],mp[eid]['analysis_condition']):j for eid,j in J.items()}

    rows=[]
    for sys,cond in SYSTEMS:
        for rid,g in gold.items():
            j=cond_j[(rid,cond)]; p=preds[sys][rid]
            speech=p['parsed']['analysis']['speech_act']; speech_ok=speech==g['gold_speech_act']
            sem=semantic_goal_correct(j); comp=semantic_goal_component_score(j); cat=path_category(j)
            route=p['terminal_strategy']; gr=routes[rid]; route_ok=route==gr
            rows.append({
                'record_id':rid,'system_id':sys,'analysis_condition':cond,
                'gold_speech_act':g['gold_speech_act'],'predicted_speech_act':speech,
                'speech_act_correct':speech_ok,'semantic_goal_correct':sem,
                'semantic_goal_component_score':comp,'goal_path_category':cat,
                'full_intent_correct':bool(sem and speech_ok),
                'gold_terminal_strategy':gr,'terminal_strategy':route,'route_correct':route_ok,
            })

    res={}
    for sys,_ in SYSTEMS:
        rr=[r for r in rows if r['system_id']==sys]; n=len(rr)
        def rate(field):
            k=sum(bool(r[field]) for r in rr); lo,hi=wilson_interval(k,n)
            return {'n':n,'correct':k,'rate':k/n,'wilson95':[lo,hi]}
        wrong=[r for r in rr if not r['route_correct']]
        intent_ok=[r for r in rr if r['semantic_goal_correct']]
        matrix=Counter((bool(r['semantic_goal_correct']),bool(r['route_correct'])) for r in rr)
        res[sys]={
            'semantic_goal_accuracy':rate('semantic_goal_correct'),
            'speech_act_accuracy':rate('speech_act_correct'),
            'full_intent_accuracy':rate('full_intent_correct'),
            'mean_component_score':sum(r['semantic_goal_component_score'] for r in rr)/n,
            'path_categories':dict(Counter(r['goal_path_category'] for r in rr)),
            'route_decomposition':{
                'intent_x_route_matrix':{
                    'goal_correct_route_correct':matrix[(True,True)],
                    'goal_correct_route_wrong':matrix[(True,False)],
                    'goal_wrong_route_correct':matrix[(False,True)],
                    'goal_wrong_route_wrong':matrix[(False,False)],
                },
                'route_wrong_n':len(wrong),
                'semantic_goal_correct_among_route_wrong':sum(r['semantic_goal_correct'] for r in wrong),
                'P_goal_correct_given_route_wrong':sum(r['semantic_goal_correct'] for r in wrong)/len(wrong) if wrong else None,
                'semantic_goal_correct_n':len(intent_ok),
                'route_wrong_among_goal_correct':sum(not r['route_correct'] for r in intent_ok),
                'P_route_wrong_given_goal_correct':sum(not r['route_correct'] for r in intent_ok)/len(intent_ok) if intent_ok else None,
            },
        }

    f={r['record_id']:r for r in rows if r['system_id']=='full_type_risk_aware_manager'}
    b={r['record_id']:r for r in rows if r['system_id']=='context_blind_manager'}
    ids=sorted(f)
    n01=sum((not f[i]['semantic_goal_correct']) and b[i]['semantic_goal_correct'] for i in ids)
    n10=sum(f[i]['semantic_goal_correct'] and (not b[i]['semantic_goal_correct']) for i in ids)
    res['paired_full_context_vs_blind_semantic_goal']={
        'full_wrong_blind_right':n01,'full_right_blind_wrong':n10,
        'accuracy_difference_full_minus_blind':sum(int(f[i]['semantic_goal_correct'])-int(b[i]['semantic_goal_correct']) for i in ids)/len(ids),
        'exact_mcnemar_p':exact_mcnemar_p(n01,n10),
        'paired_bootstrap_difference':paired_bootstrap_difference([f[i]['semantic_goal_correct'] for i in ids],[b[i]['semantic_goal_correct'] for i in ids]),
    }
    Path(args.out).write_text(json.dumps(res,indent=2,sort_keys=True)+'\n')
    with open(args.row_out,'w',encoding='utf-8',newline='') as fcsv:
        w=csv.DictWriter(fcsv,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    print(json.dumps(res,indent=2))
if __name__=='__main__': main()
