#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json,re
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--source',required=True); ap.add_argument('--out',required=True); args=ap.parse_args()
    p=Path(args.source); text=p.read_text(encoding='utf-8'); lines=text.splitlines()
    def hits(pattern):
        rx=re.compile(pattern,re.I)
        return [{'line':i+1,'text':line.strip()} for i,line in enumerate(lines) if rx.search(line)]
    report={
      'source_path':str(p),
      'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
      'intent_summary_references':hits(r'intent_summary'),
      'prompt_exact_key_lines':hits(r'Return ONLY one JSON object|speech_act \(one allowed label\)|unresolved_slots \(array'),
      'schema_lines':hits(r'MANAGER_ANALYSIS_JSON_SCHEMA|"speech_act"|"unresolved_slots"'),
      'findings':{
        'structured_speech_act_requested':bool(hits(r'speech_act \(one allowed label\)')),
        'structured_intent_summary_requested':bool(hits(r'intent_summary.*Return ONLY|Return ONLY.*intent_summary')),
        'normalizer_sets_intent_summary_none':any('"intent_summary": None' in h['text'] for h in hits(r'intent_summary')),
      }
    }
    report['conclusion']='Frozen T39 exposes closed-class speech_act but does not request a semantic intent summary; normalizer explicitly stores intent_summary=None.'
    Path(args.out).write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__': main()
