#!/usr/bin/env python3
import argparse,json
from pathlib import Path
from intent_eval_common import load_jsonl, INTENT_FIELDS, semantic_goal_correct, semantic_goal_component_score, path_category, write_jsonl

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--packet',required=True); ap.add_argument('--judgments',required=True); ap.add_argument('--normalized-out'); args=ap.parse_args()
 packet=load_jsonl(args.packet); expected={r['evaluation_id'] for r in packet}; rows=load_jsonl(args.judgments); seen=set(); errs=[]; norm=[]
 for i,r in enumerate(rows,1):
  eid=r.get('evaluation_id')
  if eid not in expected: errs.append(f'unknown_id:{i}:{eid}')
  if eid in seen: errs.append(f'duplicate:{eid}')
  seen.add(eid)
  if r.get('prediction_blind_attestation') is not True: errs.append(f'blind_attestation:{eid}')
  for k in INTENT_FIELDS:
   if not isinstance(r.get(k),bool): errs.append(f'bad_bool:{eid}:{k}')
  if not isinstance(r.get('rationale'),str) or not r['rationale'].strip(): errs.append(f'missing_rationale:{eid}')
  x=dict(r); x['semantic_goal_correct']=semantic_goal_correct(r); x['semantic_goal_component_score']=semantic_goal_component_score(r); x['goal_path_category']=path_category(r); norm.append(x)
 missing=expected-seen
 if missing: errs.append(f'missing_count:{len(missing)}')
 report={'expected':len(expected),'received':len(rows),'unique_received':len(seen),'errors':errs,'pass':not errs}
 print(json.dumps(report,indent=2))
 if errs: raise SystemExit(2)
 if args.normalized_out: write_jsonl(args.normalized_out,norm)
if __name__=='__main__': main()
