#!/usr/bin/env python3
from __future__ import annotations
import argparse
from intent_eval_common import load_jsonl, write_jsonl

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--pass1',required=True); ap.add_argument('--pass2',required=True); ap.add_argument('--out',required=True); args=ap.parse_args()
    rows=load_jsonl(args.pass1)+load_jsonl(args.pass2)
    ids=[r['evaluation_id'] for r in rows]
    if len(ids)!=240 or len(set(ids))!=240: raise SystemExit(f'combined_judge_coverage_failure:{len(ids)}:{len(set(ids))}')
    write_jsonl(args.out,rows); print('wrote 240 combined judgments')
if __name__=='__main__': main()
