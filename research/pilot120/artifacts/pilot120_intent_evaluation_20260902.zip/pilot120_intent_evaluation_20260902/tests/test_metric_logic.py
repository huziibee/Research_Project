from scripts.intent_eval_common import semantic_goal_correct, path_category, clean_observable_trace, extract_intent_candidate_text, exact_mcnemar_p

def j(**kw):
 d=dict(primary_goal_match=True,required_action_set_match=True,polarity_match=True,explicit_enough=True,no_incompatible_goal=True);d.update(kw);return d

def test_paraphrase_correct(): assert semantic_goal_correct(j())
def test_missing_second_action_partial():
 x=j(required_action_set_match=False); assert not semantic_goal_correct(x); assert path_category(x)=='PARTIAL'
def test_negation_wrong():
 x=j(polarity_match=False); assert path_category(x)=='WRONG'
def test_generic_vague_partial():
 x=j(explicit_enough=False); assert path_category(x)=='PARTIAL'
def test_incompatible_goal_wrong():
 x=j(no_incompatible_goal=False); assert path_category(x)=='WRONG'
def test_verbatim_command_removed_before_scoring():
 cmd='Move the red box to the shelf.'
 raw='<think>The user says, "Move the red box to the shelf." They want the box relocated.</think>\n{}'
 out=clean_observable_trace(raw,cmd)
 assert cmd.lower() not in out.lower()
 assert 'They want the box relocated' in out
 ex=extract_intent_candidate_text(raw,cmd)
 assert cmd.lower() not in ex.lower()
def test_exact_mcnemar_symmetry():
 assert exact_mcnemar_p(2,5)==exact_mcnemar_p(5,2)
