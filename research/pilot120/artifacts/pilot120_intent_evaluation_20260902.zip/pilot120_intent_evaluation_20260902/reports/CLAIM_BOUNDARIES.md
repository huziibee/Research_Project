# Claim boundaries

## Directly measurable from frozen T39
- closed-class `speech_act` accuracy;
- speech-act confusion/per-class performance;
- raw observable trace content;
- terminal route and other existing structured fields.

## New retrospective T41-style measure
`Semantic Goal Trace Correctness` evaluates whether the frozen observable analysis text states the correct semantic goal. It is route-independent and CPC-independent.

It must **not** be described as:
- guaranteed internal intent representation;
- faithful chain-of-thought;
- an output field that T39 explicitly produced;
- proof of causal reasoning.

## Future direct metric
Once a future system requires a structured `intent_summary`, the same SGC protocol can directly score that field. That is the preferred architecture going forward.

## Automatic diagnostics
SBERT/NLI scores are convergent diagnostics. They do not become correctness labels without a separate, frozen calibration study.
