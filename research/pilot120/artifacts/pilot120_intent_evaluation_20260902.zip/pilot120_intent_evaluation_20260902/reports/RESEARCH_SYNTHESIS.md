# Deep research synthesis: measuring whether Pilot-120 intent is actually correct

## Executive conclusion

For Pilot-120 there are **two distinct questions that had been conflated under “intent”**:

1. **Communicative force / speech act:** Did the model classify the utterance as a directive, indirect request, prohibition, information question, etc.?
2. **Semantic user goal:** Did the model state what the user actually wants done/asked/prohibited, even if it later chooses the wrong ambiguity-resolution or terminal route?

The literature strongly supports separating dialogue communicative function from semantic content, and task-oriented NLU conventionally evaluates intent and slots separately. Pilot therefore should not use CPC as the test of semantic intent.

The recommended evaluation is:

- **Primary A — Speech-Act Accuracy (SAA):** exact closed-class label accuracy.
- **Primary B — Semantic Goal Correctness (SGC):** prediction-blind binary semantic evaluation of the model's stated goal against two pre-T39 semantic intent references.
- **Derived — Full Intent Correctness (FIC):** `SAA AND SGC`.
- **Secondary diagnostics:** bidirectional NLI and sentence-embedding cosine, never silently thresholded into correctness.
- **Downstream analysis:** cross SGC with terminal-route correctness to determine whether route failures occur despite correct goal understanding.

There is no single published benchmark metric that can simply be copied for this exact free-text, route-independent question. The protocol is a preregisterable synthesis of established components. That is more defensible than inventing a similarity threshold and calling it “intent accuracy.”

## Why not compare text strings?

Exact text match is invalid because semantically equivalent goals can be paraphrased.

Lexical overlap is also unsafe: PAWS demonstrates high-overlap sentence pairs that are not paraphrases, including argument/order reversals. Semantic embeddings improve graded similarity but still do not enforce logical equivalence or polarity. BERTScore analysis likewise documents reduced sensitivity to some smaller errors.

Therefore similarity is evidence, not the decision rule.

## Why the binary checklist is primary

The actual decision we need is categorical: did the trace state the same goal or not? A decomposed checklist makes the judgment auditable:

1. same primary requested operation/end-state;
2. all materially required top-level actions represented;
3. polarity/prohibition preserved;
4. intent stated explicitly enough to identify it;
5. no materially incompatible substituted/added goal.

`SGC = TRUE` only if all five pass.

This is deliberately strict. The accompanying component score is diagnostic only and is not treated as a calibrated psychometric scale.

CheckEval provides empirical support for decomposed binary criteria over vague Likert scoring in LLM-as-judge settings. The protocol further uses two independent blind judges, field-wise agreement, Cohen kappa, and a third blind adjudication for disagreements.

## Why speech act remains separate

ISO dialogue-act work distinguishes communicative function from semantic content. A system can therefore correctly identify the requested action while misclassifying its communicative force, or vice versa.

This is especially important for Pilot's 29 indirect requests. A model may understand “deliver the tray” while calling the utterance an information question, or correctly recognize indirect-request force while misunderstanding the requested action. Those should be distinguishable errors.

## Why CPC is intentionally excluded

CPC evaluates argument grounding: object, destination, quantity, time, recipient, tool, etc. Those can be wrong even when the top-level user goal is understood.

Example:
- Gold goal: `move the package`.
- Model: `The user wants the package moved to Bay B.`
- True destination: Bay A.

Semantic goal = correct (`move`). CPC destination = wrong.

If the model says `inspect the package`, semantic goal is wrong because the requested operation changed.

## What counts as “on the right path”

`goal_path_category` is a transparent descriptive layer:
- `CORRECT`: all SGC checks pass;
- `PARTIAL`: primary goal, polarity, and no-incompatible-goal pass, but action coverage or explicitness is incomplete;
- `WRONG`: primary goal/polarity/compatibility fails.

This answers the user's “right path” question without allowing a vague 1–10 score to replace correctness.

## The command-copy confound and its fix

Inspection of the actual T39 traces found that many raw traces repeat the source command verbatim. A naive embedding/NLI or judge comparison could award high semantic similarity to parroting.

The implemented preparation therefore removes exact source-command repetitions from candidate evidence **before** semantic judging. The source remains available to the judge for context, but the copied string itself cannot earn credit.

This transformation is source-only and gold-independent.

## Frozen T39 limitation

The executed T39 manager prompt never requested a semantic `intent_summary`; it requested the closed-class `speech_act` and other analysis fields, and the normalizer explicitly writes `intent_summary = None`.

Therefore:
- SAA is a direct structured-output metric.
- SGC on T39 is a **retrospective observable-trace metric**.
- It does not prove hidden/internal reasoning.

For future experiments, `intent_summary` should be a required first-class output so semantic-goal accuracy is direct rather than reconstructed from reasoning prose.

## Automatic convergent diagnostics

### Sentence embeddings
Use `all-mpnet-base-v2` to compute cosine similarity between candidate intent evidence and each gold reference.

Report it continuously. Do not use a universal threshold as primary correctness.

### Bidirectional NLI
Use an NLI cross-encoder in both directions:
- candidate entails reference;
- reference entails candidate.

A conservative diagnostic is the minimum entailment probability across the two directions for each reference. Bidirectionality helps expose omission/addition asymmetry.

Again, no primary threshold is frozen without a separate calibration study.

## Blinding and comparison-bias control

The 240 candidate traces comprise 120 full-context-shared traces and 120 context-blind traces. Showing both versions of a record in one evaluator session could encourage direct comparison.

The implementation therefore creates two randomized 120-item passes, each containing exactly one condition per source record. Pass 2 must be judged in a fresh evaluator context. Evaluation IDs are opaque and record IDs/system identity/routes are excluded from the blind packet. The mapping is sealed until judgments are frozen.

## Primary reported outputs after judging

For each system:
- SAA with Wilson 95% interval;
- SGC with Wilson 95% interval;
- FIC with Wilson 95% interval;
- mean component score (descriptive);
- CORRECT/PARTIAL/WRONG counts;
- intent × route 2×2 matrix;
- `P(SGC correct | route wrong)`;
- `P(route wrong | SGC correct)`.

For full-context vs context-blind semantic-goal correctness:
- paired difference in SGC accuracy;
- exact McNemar test;
- paired bootstrap difference interval as a diagnostic effect interval.

## The scientific question this finally answers

If many terminal-route errors fall in:

`semantic goal correct + route wrong`

then the evidence supports a downstream decision failure rather than a failure to identify the user's goal.

If semantic goal is already wrong on most route errors, the weakness begins at interpretation.

That decomposition is the main scientific value of this protocol.
