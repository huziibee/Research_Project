# Current Pilot-120 intent findings that can already be computed

## Structured speech-act accuracy

Using the frozen 120-record intent taxonomy and frozen R1 structured manager analyses (R1-R5 raw trace stability independently reverified):

| System | Correct | N | Accuracy |
|---|---:|---:|---:|
| Degree router | 76 | 120 | 63.3% |
| Full manager | 76 | 120 | 63.3% |
| Context blind | 82 | 120 | 68.3% |

Wilson 95% intervals and full confusion matrices are in `speech_act_results.json`.

### By gold class

Degree/full manager:
- directive command: 75/90 = 83.3%;
- indirect request: 1/29 = 3.4%;
- prohibition: 0/1.

Context blind:
- directive command: 82/90 = 91.1%;
- indirect request: 0/29;
- prohibition: 0/1.

The indirect-request result is a major structural weakness, but it does **not** yet tell us whether the semantic requested action was understood despite the wrong force label. That is exactly what SGC tests.

## Frozen contract audit

`frozen_intent_contract_audit.json` confirms:
- structured `speech_act` was requested;
- semantic `intent_summary` was not requested;
- the normalizer explicitly stores `intent_summary = None`.

## Trace stability

The intent-evaluation builder directly rechecked raw manager outputs across R1-R5:
- degree router: 120/120 stable;
- full manager: 120/120 stable;
- context blind: 120/120 stable.

Degree and full manager raw analysis traces are identical on 120/120, and their structured speech-act labels are identical on 120/120. Therefore semantic-goal trace correctness will also be identical for these two systems; their later route divergence can be studied downstream.

## Copy confound audit

186/240 raw analysis outputs contain an exact copy of the source command somewhere in the raw text. After source-only omission, 0/240 prepared candidate excerpts retain the exact command string.

This prevents a semantic metric from being inflated simply because the model copied its input.

## What is intentionally not reported yet

No formal SGC/FIC number is reported until two prediction-blind semantic judges complete the two-pass packet and disagreements are adjudicated.

This is a methodological gate, not missing source data or missing code.

## Gold-reference consistency

The two historical pre-T39 normalized annotation streams agree on the intent/speech-act label for **120/120** records, and both agree with the frozen candidate-key intent label for **120/120**. Both free-text `intent_text` references are non-empty for **120/120**.

This makes them suitable as multiple semantic references for prediction-blind goal evaluation while retaining both phrasings rather than collapsing them post hoc.
