# Exact measurement method

## Metric 1 — Speech-Act Accuracy (SAA)

Per record:

`SAA_i = 1[predicted_speech_act == gold_speech_act]`

Aggregate:

`SAA = sum(SAA_i) / N`

Report Wilson 95% CI, macro-F1, per-gold-class accuracy and confusion matrix.

## Metric 2 — Semantic Goal Correctness (SGC)

A prediction-blind judge evaluates five booleans:

- G = primary goal match;
- A = required top-level action set match;
- P = polarity match;
- E = explicit enough to identify the requested goal;
- C = no incompatible substituted/added goal.

Per record/trace:

`SGC_i = G AND A AND P AND E AND C`

Aggregate:

`SGC = sum(SGC_i) / N`

Report Wilson 95% CI.

This is intentionally not CPC. Wrong object/destination/time/tool does not make SGC false unless it changes the requested top-level operation/end-state.

## Metric 3 — Full Intent Correctness (FIC)

`FIC_i = SGC_i AND SAA_i`

This requires both correct semantic goal and correct communicative-force label.

## Descriptive partial-path score

`component_i = (G + A + P + E + C) / 5`

This is diagnostic only. It is not treated as a calibrated interval measure.

Path category:
- CORRECT: SGC true;
- PARTIAL: G, P and C true but A and/or E false;
- WRONG: otherwise.

## Route-independent decomposition

After judgments are frozen, join route correctness and report:

- goal correct + route correct;
- goal correct + route wrong;
- goal wrong + route correct;
- goal wrong + route wrong;
- `P(goal correct | route wrong)`;
- `P(route wrong | goal correct)`.

This is the direct test of whether the manager can understand the user's goal yet take the wrong downstream path.

## Context comparison

For full-context versus context-blind SGC:
- paired accuracy difference;
- exact McNemar test on discordant pairs;
- paired bootstrap difference interval as an effect-size diagnostic.

Do not interpret this retrospective semantic trace comparison as hidden-reasoning access.
