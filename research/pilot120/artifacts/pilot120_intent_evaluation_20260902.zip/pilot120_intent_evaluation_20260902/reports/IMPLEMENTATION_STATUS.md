# Implementation status

## Completed locally

- Literature-grounded evaluation protocol.
- Two pre-T39 semantic intent references bound to all 120 Pilot records.
- Exact structured speech-act scoring.
- R1-R5 raw trace stability verification for all three manager variants.
- Verification that degree/full share the same raw analysis trace and speech-act output on all 120 records.
- Gold-independent observable trace preparation.
- Exact source-command parroting removal.
- Opaque evaluation IDs and sealed system/condition mapping.
- Two-pass anti-comparison design: 120 items/pass, one condition per source record/pass.
- Prediction-blind JSON judge schema and calibration examples.
- Independent-judge validation, agreement/kappa, disagreement extraction, adjudication packet, final assembly.
- Final SGC/SAA/FIC scorer and route-decomposition analysis.
- Optional SBERT + bidirectional-NLI diagnostics code.
- Frozen T39 intent-contract audit.
- Prospective `intent_summary` output contract for future systems.
- Unit tests and end-to-end synthetic workflow smoke test.
- Self-contained evidence snapshot and byte-identical rebuild verification.

## Not fabricated locally

Formal Semantic Goal Correctness / Full Intent Correctness values are not populated yet because the required two independent prediction-blind semantic judgments have not been run.

That is the only substantive gate for the new primary semantic-goal result. Source data and scoring code are complete.

## Optional diagnostic dependency

`sentence-transformers` / `transformers` model weights are not installed in this execution environment. The optional diagnostics script is complete, but these diagnostics are not required for the primary metric and must not replace blind checklist judgments.
