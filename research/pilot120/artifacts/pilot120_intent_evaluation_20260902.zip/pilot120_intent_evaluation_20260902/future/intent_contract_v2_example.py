"""Prospective example only. Do NOT patch or overwrite frozen T39 with this file."""
from __future__ import annotations

INTENT_SUMMARY_PROMPT = """
intent_summary: In one concise sentence, state the user's underlying requested goal.
- Preserve perform/prohibit/information direction and all top-level requested actions.
- Paraphrase; do not merely repeat the source command.
- Do not decide execute/clarify/reject here.
- Do not enumerate CPC slots unless needed to state the top-level goal.
""".strip()


def validate_intent_summary(obj: dict) -> tuple[bool, str | None]:
    value=obj.get('intent_summary')
    if not isinstance(value,str) or not value.strip():
        return False,'missing_intent_summary'
    if len(value.strip())<3:
        return False,'intent_summary_too_short'
    return True,None


def normalized_analysis_fragment(obj: dict) -> dict:
    ok,err=validate_intent_summary(obj)
    if not ok:
        raise ValueError(err)
    return {
        'speech_act':obj['speech_act'],
        'intent_summary':obj['intent_summary'].strip(),
    }
