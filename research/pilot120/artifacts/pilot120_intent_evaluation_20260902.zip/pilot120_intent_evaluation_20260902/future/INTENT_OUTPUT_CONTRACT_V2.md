# Prospective intent output contract v2

**Status:** future architecture proposal. It must not alter frozen T39.

## Why this exists

Frozen T39 requested a closed-class `speech_act` but did not request semantic goal text and explicitly normalized `intent_summary` to `None`. Therefore semantic-goal evaluation on T39 can only use observable trace evidence retrospectively.

For future T42/T43/T44-style runs, make the semantic user goal a first-class required output.

## Minimal new field

`intent_summary`

One concise sentence answering: **What does the user ultimately want, ask, or prohibit?**

Requirements:
- preserve all top-level requested actions;
- preserve perform/prohibit/information direction;
- paraphrase rather than copy the source command;
- do not choose execute/clarify/reject in this field;
- do not require CPC slot enumeration;
- do not justify with chain-of-thought.

Example:

Source: `Can the selected tray be delivered after meal service?` with dialogue saying to treat it as a request.

Good `intent_summary`: `Deliver the selected tray after the relevant meal service.`

Bad: `This is an indirect request and should be clarified.` (mixes force/route without stating the semantic goal.)

## Evaluation

Score `intent_summary` against prediction-blind gold intent references using the same five binary Semantic Goal Correctness checks in `protocol/JUDGE_GUIDE.md`.

This makes future semantic-goal accuracy a direct output-contract metric rather than a retrospective trace metric.
