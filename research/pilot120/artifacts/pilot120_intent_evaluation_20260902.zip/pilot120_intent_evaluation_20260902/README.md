# Pilot-120 semantic intent evaluation package

## Purpose

Measure whether the frozen manager **understood the user's semantic goal even when it later chose a different/wrong route**, without conflating intent with CPC.

This package is self-contained for the relevant Pilot evidence and scoring code.

## The three reported intent outcomes

1. **Speech-Act Accuracy (SAA)** — exact closed-class communicative-force label.
2. **Semantic Goal Correctness (SGC)** — route-independent semantic goal correctness from a prediction-blind five-item checklist.
3. **Full Intent Correctness (FIC)** — `SAA AND SGC`.

For frozen T39, SGC is formally **observable semantic-goal trace correctness** because the executed prompt did not request `intent_summary` and the normalizer stored it as `None`.

## Current completed result

Structured speech-act scoring is already complete in:

`reports/speech_act_results.json`

Degree/full = 76/120 (63.3%); context blind = 82/120 (68.3%).

Formal SGC/FIC is intentionally not filled in until two independent prediction-blind judges complete the supplied packet and disagreements are adjudicated.

## Research basis

Read:
- `reports/RESEARCH_SYNTHESIS.md`
- `references/REFERENCES.md`
- `protocol/intent_evaluation_protocol_v1.json`

## Why this is not cosine-similarity thresholding

Semantic similarity is useful but not equivalent to correctness. Negation, action reversal, missing actions, and incompatible extra goals can preserve high lexical/embedding similarity. Therefore SBERT and bidirectional NLI are included only as convergent diagnostics.

## Anti-contamination protections

- opaque evaluation IDs;
- no system identity, terminal route, correctness, or CPC score in blind packets;
- record IDs omitted from blind packets;
- exact source-command copies removed from candidate evidence;
- two 120-item passes, one condition per underlying record in each pass;
- pass 2 must run in a fresh evaluator context;
- SEALED mapping is not used until judgments are frozen.

## Blind judging workflow

Use **two independent judges**. Ideally use distinct strong model families if available. Each judge must run the two passes in fresh contexts.

For Judge A:

```bash
# Fresh context/session A1: judge data/blind_judge_pass_1_120.jsonl
# Save output as work/judge_A_pass_1.jsonl

# Fresh context/session A2: judge data/blind_judge_pass_2_120.jsonl
# Save output as work/judge_A_pass_2.jsonl

PYTHONPATH=scripts python scripts/combine_judge_passes.py \
  --pass1 work/judge_A_pass_1.jsonl \
  --pass2 work/judge_A_pass_2.jsonl \
  --out work/judge_A.jsonl

PYTHONPATH=scripts python scripts/validate_judge_output.py \
  --packet data/blind_semantic_goal_judge_packet_240.jsonl \
  --judgments work/judge_A.jsonl \
  --normalized-out work/judge_A.normalized.jsonl
```

Repeat independently for Judge B.

Then:

```bash
PYTHONPATH=scripts python scripts/merge_intent_judges.py \
  --judge-a work/judge_A.jsonl \
  --judge-b work/judge_B.jsonl \
  --consensus-out work/A_B_consensus.jsonl \
  --disagreements-out work/A_B_disagreements.jsonl \
  --agreement-out work/A_B_agreement.json

PYTHONPATH=scripts python scripts/build_disagreement_adjudication_packet.py \
  --packet data/blind_semantic_goal_judge_packet_240.jsonl \
  --disagreements work/A_B_disagreements.jsonl \
  --out work/blind_adjudication_packet.jsonl
```

Give only `work/blind_adjudication_packet.jsonl`, `protocol/JUDGE_GUIDE.md`, `protocol/ADJUDICATOR_PROMPT.txt`, the schema, and calibration cases to a fresh third adjudicator.

Save its result as `work/adjudicated.jsonl`, then:

```bash
PYTHONPATH=scripts python scripts/validate_judge_output.py \
  --packet work/blind_adjudication_packet.jsonl \
  --judgments work/adjudicated.jsonl

PYTHONPATH=scripts python scripts/assemble_final_judgments.py \
  --packet data/blind_semantic_goal_judge_packet_240.jsonl \
  --consensus work/A_B_consensus.jsonl \
  --adjudicated work/adjudicated.jsonl \
  --out work/final_semantic_goal_judgments.jsonl

sha256sum work/final_semantic_goal_judgments.jsonl > work/final_semantic_goal_judgments.sha256
```

**Freeze that SHA before scoring/unsealing.**

## Final scoring

Only after the final judgment SHA is frozen:

```bash
PYTHONPATH=scripts python scripts/finalize_intent_results.py \
  --gold data/intent_gold_references_120.jsonl \
  --mapping data/SEALED_evaluation_mapping.jsonl \
  --judgments work/final_semantic_goal_judgments.jsonl \
  --review-root evidence/review_snapshot \
  --core-gold evidence/closure_snapshot/reference/pilot_120_final_gold.jsonl \
  --out work/final_intent_results.json \
  --row-out work/final_intent_rows.csv
```

The final report includes the crucial route-independent quantities:
- `P(semantic goal correct | route wrong)`;
- `P(route wrong | semantic goal correct)`;
- the 2x2 semantic-goal-correct × route-correct matrix.

## Optional automatic semantic diagnostics

Install optional dependencies in a separate environment:

```bash
python -m pip install -r requirements-intent-eval.txt
```

Then:

```bash
PYTHONPATH=scripts python scripts/run_semantic_diagnostics.py \
  --packet data/blind_semantic_goal_judge_packet_240.jsonl \
  --out work/semantic_diagnostics.jsonl
```

These results are diagnostics only. Do not invent a cosine/NLI pass threshold after seeing Pilot outcomes.

## Rebuild from contained evidence

```bash
rm -rf work/rebuilt
mkdir -p work/rebuilt/data work/rebuilt/reports

PYTHONPATH=scripts python scripts/build_intent_eval_packet.py \
  --closure-root evidence/closure_snapshot \
  --review-root evidence/review_snapshot \
  --out work/rebuilt/data

PYTHONPATH=scripts python scripts/score_speech_act.py \
  --gold work/rebuilt/data/intent_gold_references_120.jsonl \
  --review-root evidence/review_snapshot \
  --out work/rebuilt/reports/speech_act_results.json
```

`validation/self_contained_rebuild_report.json` confirms the shipped packets/results rebuild byte-for-byte from the packaged evidence.

## Tests

```bash
PYTHONPATH=. pytest -q tests/test_metric_logic.py
python -m py_compile scripts/*.py
```

The full synthetic workflow smoke test is under `validation/smoke2/`. Its semantic scores are synthetic and **must never be reported as science**.

## Future system

See `future/INTENT_OUTPUT_CONTRACT_V2.md` and `future/manager_analysis_schema_v2.json`.

Do not alter frozen T39. In a future separately versioned system, require `intent_summary` as a first-class output and score it directly with SGC.
