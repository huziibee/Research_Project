# Three failed clarify-recovery cases (seed 0)

Kept in the denominator. Not re-labelled and not dropped.

- `CA-0702` answered_route=`` first=`clarify`
- `CA-0733` answered_route=`` first=`clarify`
- `CA-0778` answered_route=`` first=`clarify`
