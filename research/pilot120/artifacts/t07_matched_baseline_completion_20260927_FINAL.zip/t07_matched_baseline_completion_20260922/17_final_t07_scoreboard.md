# T0.7 matched baseline scoreboard

| System | Official intent /120 | Exact routing /120 |
|---|---:|---:|
| Raw Qwen | 106 | 96 |
| Fine-Tune | 112 | 92 |
| Goal-First | 117 | 56 |
| Degree | 117 | 57 |
| Timid | 117 | 29 |
| Context-Blind | 119 | 21 |

Degree and Timid inherit Goal-First official intent (shared written generation).
T0.3 is not included. Historical T0 official intent (Raw 113 / Fine-Tune 107 / Goal-First 113) is preserved.
