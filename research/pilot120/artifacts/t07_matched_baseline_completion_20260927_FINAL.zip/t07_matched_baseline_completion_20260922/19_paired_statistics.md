# Paired analyses (same 120 cases)

### finetune_vs_goal_first_official_intent
- both correct: 111
- Fine-Tune only: 1
- Goal-First only: 6
- both wrong: 2
- exact McNemar p = 0.125

### finetune_vs_goal_first_routing
- both correct: 45
- Fine-Tune only: 47
- Goal-First only: 11
- both wrong: 17
- exact McNemar p = 2.031594536044956e-06

### raw_vs_finetune_official_intent
- both correct: 103
- Raw Qwen only: 3
- Fine-Tune only: 9
- both wrong: 5
- exact McNemar p = 0.14599609375

### raw_vs_finetune_routing
- both correct: 83
- Raw Qwen only: 13
- Fine-Tune only: 9
- both wrong: 15
- exact McNemar p = 0.5234670639038086

### raw_vs_goal_first_official_intent
- both correct: 106
- Raw Qwen only: 0
- Goal-First only: 11
- both wrong: 3
- exact McNemar p = 0.0009765625

### raw_vs_goal_first_routing
- both correct: 47
- Raw Qwen only: 49
- Goal-First only: 9
- both wrong: 15
- exact McNemar p = 8.959402428981855e-08

## Wilson 95% CI

- Raw Qwen: intent 106/120 (0.814–0.929); routing 96/120 (0.720–0.862)
- Fine-Tune: intent 112/120 (0.874–0.966); routing 92/120 (0.683–0.833)
- Goal-First: intent 117/120 (0.929–0.991); routing 56/120 (0.380–0.556)
- Degree: intent 117/120 (0.929–0.991); routing 57/120 (0.388–0.564)
- Timid: intent 117/120 (0.929–0.991); routing 29/120 (0.174–0.326)
- Context-Blind: intent 119/120 (0.954–0.999); routing 21/120 (0.117–0.253)
