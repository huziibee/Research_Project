# Adapter provenance note — T0.7 Fine-Tune comparator

This note resolves a config/manifest inconsistency **without rewriting** either historical file.

## 1. Adapter actually used for the completed T0.7 Fine-Tune emit

Runtime source of truth: `emit/t28_selected_adapter_llm/run_manifest.json`

- **adapter_id:** `t28-tc-full-v1-1500`
- **adapter_scale:** `0.18`
- **path:** `/home-mscluster/mbangie/t12-hpc/runs/t28-r6/t28-tc-full-20260811/early_pilot_package_excluding_clara1170_v1`
- **identity file:** `.../early_pilot_package_excluding_clara1170_v1/adapter_identity.json`
- **selected_adapter:** `true`
- **valid_for_official_use:** `true` (as recorded on the identity after 2026-09-13)
- **unofficial_fine_tune:** `false` on the completed run
- **base model:** `Qwen/Qwen3-8B` @ `b968826d9c46dd6066d109eabc6255188de91218`
- **temperature / seed:** `0.7` / `0`

Job **58442** wrote 120/120 Fine-Tune predictions with this adapter. Those rows were not regenerated.

## 2. Why `04_config_finetune_t07.json` still says unofficial

`04_config_finetune_t07.json` is a **protocol-freeze snapshot** taken on 2026-09-22. At T0 final-close the same adapter path was still labelled unofficial (`allow_unofficial_adapter = true`, `valid_for_official_use = false`). The freeze copied that historical close-protocol wording.

On 2026-09-13 the **same weights** were officialized in `adapter_identity.json` (`officialized_at_utc` on that identity). The T0.7 emit therefore loaded the official+selected identity and did **not** pass `--allow-unofficial-adapter`.

The older config was not edited after the fact. The run manifest is what the job actually executed.

## 3. Source of truth

| File | Role |
|---|---|
| `emit/t28_selected_adapter_llm/run_manifest.json` | **Runtime source of truth** for the completed T0.7 Fine-Tune rows |
| `adapter_identity.json` next to the adapter | Identity the loader checked |
| `04_config_finetune_t07.json` | Frozen pre-run protocol note; do not rewrite |

## 4. What “officialized” means here

It means this adapter is the selected T28 comparator **inside this frozen Pilot-120 project protocol**. It does not mean an externally released or vendor-official model.
