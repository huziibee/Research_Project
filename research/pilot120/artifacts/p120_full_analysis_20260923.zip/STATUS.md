# Pilot-120 analysis pack

{
  "packed_at_utc": "2026-09-23T16:27:02Z",
  "one_zip_note": "This archive is the single analysis pack. Fine-Tune/official T0.7 judges and new T0.3 seeds are live jobs, not invented numbers.",
  "recovery_job": {
    "id": 58441,
    "state": "COMPLETED"
  },
  "t07_job": {
    "id": 58442,
    "finetune_rows_now": 97,
    "official_two_judge": "waits_for_finetune_inside_58442"
  },
  "t03_submission": "t03_gf_ablation\t58550\tafterok\t58442\tseeds\t1 2 3\tout\t/home-mscluster/mbangie/t12-hpc/results/pilot120_t03_gf_ablation-20260923",
  "able_ix_existing_fixstack_scores": {
    "T0.0": {
      "path": "/home-mscluster/mbangie/t12-hpc/results/pilot120_temp_priority-20260915/T0.0/predictions/goal_first_manager_v2.predictions.jsonl",
      "n": 120,
      "route": 49,
      "intent_screen": 0,
      "failed": 1,
      "temperature": 0.0,
      "seed": 0,
      "status": "VERIFY_PASSED_WITH_ROW_FAILURES"
    },
    "T0.3": {
      "path": "/home-mscluster/mbangie/t12-hpc/results/pilot120_temp_priority-20260915/T0.3/predictions/goal_first_manager_v2.predictions.jsonl",
      "n": 120,
      "route": 53,
      "intent_screen": 0,
      "failed": 1,
      "temperature": 0.3,
      "seed": 0,
      "status": "VERIFY_PASSED_WITH_ROW_FAILURES"
    },
    "T0.5": {
      "path": "/home-mscluster/mbangie/t12-hpc/results/pilot120_temp_priority-20260915/T0.5/predictions/goal_first_manager_v2.predictions.jsonl",
      "n": 120,
      "route": 51,
      "intent_screen": 0,
      "failed": 1,
      "temperature": 0.5,
      "seed": 0,
      "status": "VERIFY_PASSED_WITH_ROW_FAILURES"
    },
    "T0.7": {
      "path": "/home-mscluster/mbangie/t12-hpc/results/pilot120_temp_priority-20260915/T0.7/predictions/goal_first_manager_v2.predictions.jsonl",
      "n": 120,
      "route": 56,
      "intent_screen": 0,
      "failed": 0,
      "temperature": 0.7,
      "seed": 0,
      "status": "VERIFY_PASSED"
    },
    "T1.0": {
      "path": "/home-mscluster/mbangie/t12-hpc/results/pilot120_temp_priority-20260915/T1.0/predictions/goal_first_manager_v2.predictions.jsonl",
      "n": 120,
      "route": 44,
      "intent_screen": 0,
      "failed": 0,
      "temperature": 1.0,
      "seed": 0,
      "status": "VERIFY_PASSED"
    }
  },
  "finetune": "RESULTS IN PROGRESS",
  "t03_new_seeds": "RESULTS IN PROGRESS (pre-specified seeds 1 2 3; all retained)",
  "able_ix_rescored_locally": {
    "T0.0": {"route": 49, "intent_screen": 116, "failed": 1},
    "T0.3": {"route": 53, "intent_screen": 116, "failed": 1},
    "T0.5": {"route": 51, "intent_screen": 116, "failed": 1},
    "T0.7": {"route": 56, "intent_screen": 118, "failed": 0},
    "T1.0": {"route": 44, "intent_screen": 119, "failed": 0}
  },
  "canonical_zip": "C:\\\\Users\\\\huzii\\\\Downloads\\\\p120_full_analysis_20260923.zip"
}
