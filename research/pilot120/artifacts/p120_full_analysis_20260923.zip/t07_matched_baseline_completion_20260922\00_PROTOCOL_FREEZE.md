# Protocol freeze — T0.7 matched baseline completion

Built (UTC): 2026-09-22T14:39:29Z

## Purpose

Complete the paper's **study-default (T=0.7)** six-system table with official two-judge intent
and exact routing for Raw Qwen and Fine-Tune, plus official intent for Goal-First and
Context-Blind from existing frozen T0.7 manager artifacts.

This does **not** replace or rewrite the historical T0 final-close matched protocol
(Raw 113 / Fine-Tune 107 / Goal-First 113).

## Recovered sources

### A. Pilot-120 inputs/gold
- data/annotations/pilot_120_v1/source_canonical.jsonl
- data/annotations/pilot_120_v1/pilot_120_final_gold.jsonl
- Intent refs: pilot120_intent_evaluation_20260902/.../intent_gold_references_120.jsonl

### B/C. T0 final-close Raw / Fine-Tune comparator
- Script: scripts/evaluate_pilot_120_intent_box.py
- Prompt/output contract: intent_summary + speech_act + ambiguity_types + capability_status + terminal_strategy
- T0 settings in cluster/final_close_20260913/close.sbatch: temperature **0.0**, seed **20260913**
- Fine-Tune adapter: t28 early_pilot_package_excluding_clara1170_v1, scale 0.18, unofficial

### D. Official two-judge
- Judges Gemma-4-26B-A4B-IT + GLM-4.7-Flash via server_lifecycle.py + 
un_blind_semantic_judge.py
- Finalize: inalize_sgc_rates_20260913.py (both-judges-yes five-boolean AND)
- T0 results: Raw 113, Fine-Tune 107, Goal-First 113

### E. Existing T0.7 manager artifacts (do not re-emit)
- Goal-First repaired: unified_55670_repaired_20260918/T0.7/.../goal_first_manager_v2.predictions.jsonl → routing **56/120**
- Degree / Timid / Context-Blind: unified_55670/T0.7/predictions/ → **57 / 29 / 21**
- Shared GF intent judged once; Degree/Timid inherit that official intent count

### F. T0.7 runtime (manager)
- Model: Qwen/Qwen3-8B @ b968826d9c46dd6066d109eabc6255188de91218
- Temperature 0.7, seed **0**, thinking-on chat template, max_new_tokens 4096
- Manifest: pilot120_temp_priority-20260915/T0.7/run_manifest.json

## Documented mismatch (STOP-and-resolve)

| Setting | T0 final-close Raw/FT | T0.7 manager |
|---|---|---|
| temperature | 0.0 | 0.7 |
| seed | 20260913 | 0 |

**Resolution for this experiment:** change **only** temperature to 0.7 and seed to **0**
so Raw/FT match the study-default manager operating point. Keep the exact intent_box
prompt, parser, schema, adapter identity/scale, and judge protocol. Do not invent a new
intent prompt. T0 remains the historical matched protocol under its original seed.

## Claim boundary
- T0.7 = operating-temperature completion/replication
- No T0.3 in this experiment or summary
- Failures remain in denominator /120
- Automatic Jaccard is secondary diagnostic only
