# Protocol freeze — ABLE IX Goal-First T=0.3 ablation

Built (UTC): 2026-09-23T16:25:00Z

## Purpose

Add the missing **T=0.3** Goal-First point to the retained temperature ablation
around the study default T=0.7.

Intent is the **automatic overlap screen** (Jaccard ≥ 0.18, polarity-flip skip).
This is **not** official two-judge.

Published anchors (do not rewrite):

| T | Route /120 | Intent screen /120 |
|---|------------|--------------------|
| 0.5 | 51 | 117 |
| 0.7 | 56 | 118 |
| 1.0 | 44 | 119 |

Predicted descriptive pattern: T0.0 route < T0.3 route < T0.5 route.
**Every pre-specified seed is kept.** Runs are not discarded for failing to interpolate.

## Matched emit protocol

Same as unified job 55670 / `pilot120_fix_emit-20260915`:

- Script: `scripts/evaluate_goal_first_manager_v2.py`
- Model: Qwen/Qwen3-8B, thinking-on, max_new_tokens 4096
- Temperature **0.3**
- Pre-specified seeds **1, 2, 3** (seed 0 already exists on the unified T0.3 tree if complete)
- Frozen Pilot-120 cases, order, gold
- Failures remain in the /120 denominator
- No gold leak into prompts

## Cluster

- Code: `/home-mscluster/mbangie/t12-hpc/code/pilot120_t03_gf_ablation-20260923`
- Out: `/home-mscluster/mbangie/t12-hpc/results/pilot120_t03_gf_ablation-20260923/t03_gf_ablation_able_ix_20260923`
- Depends on T0.7 matched-baseline job **58442** (`afterok`) so it does not steal the Fine-Tune GPU
