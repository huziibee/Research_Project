# Pilot-120 analysis pack (single zip)

Packed 2026-09-23. Use this archive for your own analysis. Live jobs are still filling Fine-Tune, official T0.7 two-judge, and new T0.3 seeds.

## What’s inside

| Folder | Status |
|---|---|
| `one_turn_recovery_20260922/` | **Complete** (job 58441, exit 0:0) |
| `t07_matched_baseline_completion_20260922/` | Protocol freeze + Raw 120/120. Fine-Tune snapshot only. Official two-judge **not started**. |
| `temperature_ablation_existing/` | Unified fix-stack seed-0 emits T0.0–T1.0 (all four manager systems) + rescored ABLE IX table |
| `t03_gf_ablation_able_ix_20260923/` | Protocol freeze for **new** T0.3 seeds 1/2/3 (job **58550**, waits on 58442) |
| `logs/` | Recovery log + T0.7 log tail |
| `STATUS.md` | Job snapshot at pack time |

## Jobs still running

- **58442** `p120-t07-match` — Fine-Tune intent-box @ T0.7, then official two-judge, then scoreboard.
- **58550** `p120-t03-ableix` — Goal-First T=0.3 seeds **1, 2, 3** after 58442 succeeds. All seeds kept.

Monitor:

```bash
squeue -u mbangie
sacct -j 58442,58550 --format=JobID,JobName,State,Elapsed,ExitCode,NodeList
```

## ABLE IX (Goal-First, automatic intent screen)

Intent = Jaccard ≥ 0.18 with polarity-flip skip. **Not** official two-judge.

Rescored from the files in this zip (failed rows stay in the /120 denominator; they do not add an intent pass):

| T | Route /120 | Intent screen /120 | Notes |
|---|------------|--------------------|-------|
| 0.0 | 49 | 116 | 1 failed row |
| 0.3 | 53 | 116 | existing seed 0; 1 failed row |
| 0.5 | 51 | 116 | published table said 117; 1 failed row explains the 1-count gap |
| 0.7 | 56 | 118 | matches published anchor |
| 1.0 | 44 | 119 | matches published anchor |

Existing seed-0 T0.3 **53 is above T0.5 (51)**, not between T0.0 (49) and T0.5 (51). That completed run is retained. New seeds 1/2/3 are a pre-specified robustness set, not a search-until-pretty loop.

## T0.7 six-system table (still incomplete)

| System | Official intent /120 | Exact routing /120 |
|---|---|---|
| Raw Qwen | PENDING two-judge | 96 |
| Fine-Tune | RESULTS IN PROGRESS | RESULTS IN PROGRESS |
| Goal-First | PENDING two-judge | 56 (frozen repaired) |
| Degree | shared GF intent | 57 (frozen repaired) |
| Timid | shared GF intent | 29 (frozen repaired) |
| Context-Blind | PENDING two-judge | 21 (frozen repaired) |

Do not treat the Fine-Tune `INPROGRESS` file as official.
