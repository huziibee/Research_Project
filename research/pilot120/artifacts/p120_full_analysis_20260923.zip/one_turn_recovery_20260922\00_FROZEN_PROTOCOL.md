# Frozen protocol — one-turn recovery (oracle upper bound)

Built (UTC): 2026-09-23T09:19:55Z

## Claim boundary

This experiment asks whether an **unnecessary CLARIFY** on a gold-EXECUTE case is
**recoverable after one oracle user response**.

It is an **oracle upper bound**, not a naturalistic user simulation.
It does **not** replace or alter the first-turn exact routing score (83/120 under
LLM capability patch).

## Stack (must match repaired T0.7 capability-rescue)

1. Goal-First manager v2 analysis (Qwen3-8B, thinking-on, T=0.7)
2. Capability LLM adjudication (`capability_llm_judge_20260918`)
3. Deterministic router (`goal_first_v2`)
4. Clarification wording generator only if terminal route remains clarify
   (`deterministic_clarification@1.2.0`)

## Cohorts (frozen before inference)

- Primary (n=22): repaired T0.7 route REFUSE → post-capability route CLARIFY,
  gold terminal route EXECUTE.
- Secondary (n=26): all post-capability CLARIFY ∩ gold EXECUTE
  (primary 22 + 4 already-CLARIFY pre-capability).

## Intervention

- **Answered / treatment:** second-turn `command` = `I mean: <reference_A_intent_text>`;
  dialogue history = original history + original user command + actual first-turn
  clarification question from `goal_first_v2.llmcap_route_scene_clarify`.
- **Control:** matched NO-ANSWER replay of the original first-turn inputs under the
  same seed/model/runtime.

## Seeds

- Primary freeze: seed 0 (matches `fix_emit.sbatch` / study default).
- Optional robustness: seed 1 (reported separately; not pooled as new cases).

## Blindness

The model under test never receives gold route, risk, capability, or evaluation labels.
Oracle responses are checked to exclude explicit route/risk/capability/evaluation wording.

## Outcomes

- Primary recovery rate among 22; Wilson 95% CI; 3-way transition table.
- Secondary recovery rate among 26; same reporting.
- Interaction-level one-turn success on gold-EXECUTE:
  `(46 + recovered_among_26) / 76`
  where 46/76 is first-turn immediate EXECUTE after capability intervention.
- Seed-0 paired 2×2 control vs answered + exact McNemar (case = unit).

## Interpretation limits

Do not claim naturalistic recoverability, question pleasantness, or wording quality.
Those remain separate clarification-quality results.
