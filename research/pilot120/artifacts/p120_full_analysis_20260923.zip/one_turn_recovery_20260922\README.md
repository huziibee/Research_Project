# One-turn recovery experiment (`one_turn_recovery_20260922`)

Oracle upper-bound follow-up to the repaired T0.7 capability-rescue study.

## Status

- Freeze: complete (`01_frozen_manifest.json`)
- Inference: run via cluster sbatch (see `cluster/pilot120_one_turn_recovery_20260922/`)

## Key frozen facts

- Primary n=22 (REFUSE→CLARIFY under capability intervention; gold EXECUTE)
- Secondary n=26 (all post-capability CLARIFY ∩ gold EXECUTE)
- First-turn immediate EXECUTE on gold-EXECUTE remains **46/76**
- First-turn exact routing score remains **83/120** (untouched)

## Reproduce scoring after GPU job

```bash
python3 scripts/one_turn_recovery_20260922.py score \
  --experiment-dir "$OUT/one_turn_recovery_20260922"
```
