# Blind clarification-wording annotator brief

You annotate **exactly one** record. You are Annotator B.

Gold already decided this command should **ask** (clarify), not do it or refuse.
Your job is only the **wording rubric** for a good question.

Return JSON:
{
  "record_id": "...",
  "targets": ["slot names the question must ask about"],
  "must_convey": ["short licensed facts the question must make the human choose between or name"],
  "must_not_convey": ["claims the question must not make"],
  "acceptable_paraphrase": true,
  "rationale": "one or two sentences from the source card"
}

Rules:
- Use ONLY the command, dialogue, scene, and capability card. No gold, no model output, no other cards.
- targets are CPC-like slot names: object, recipient, destination, time, quantity, tool, action, conditions, constraints.
- must_convey items must be licensed by the scene (named objects, named people/roles, named times). Do not invent extra options.
- must_not_convey: do not pretend the ambiguity is already resolved; do not add an unsupported extra target.
- Paraphrase is allowed at scoring time. Write the facts, not a sample question.
