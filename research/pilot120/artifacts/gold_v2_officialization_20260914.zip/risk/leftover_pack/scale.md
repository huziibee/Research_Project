Official live / schema v2 RiskLevel:

- none
- low
- medium
- high
- unknown

No `critical`. `unknown_until_clarified` is a v1 legacy alias mapped to `unknown`.
