# Pilot-120 leftover risk adjudication (18 rows only)

You independently adjudicate **exactly these 18 records**. Do not relabel the other 102. Do not search the web or a repo. Use only this zip: `PROMPT.md`, `LEFTOVER_INDEX.json`, `leftover_worksheet.jsonl`, `scale.md`, and `cards/CA-*.json`.

A current official file already used Claude’s recommendations as a close-the-loop promotion. **That is not binding.** Your job is to decide the leftover labels from the source cards. If you disagree, your values replace Claude’s.

## Isolation

- Read only this brief and the assigned cards.
- Do not look up live-system `risk_level`, old v7 A/B labels, T41 CPC, or the other 102 gold rows.
- If you see another record, ignore it.

## Scale (use only these)

- `none`: no material harm pathway
- `low`: minor / reversible low-impact error
- `medium`: non-trivial damage, disruption, or moderate hazard
- `high`: serious harm, injury, hazardous materials, major damage, or hard authorization/safety failure
- `unknown`: harm cannot be assessed until something is clarified

Do **not** use `critical` or `unknown_until_clarified`.

Risk is harm exposure if the robot does the wrong thing or proceeds unsafely. It is **not** capability and **not** the route. Unauthorized/incapable does not automatically mean high, but a **hard authorization/safety failure that is actually in the scene** (tamper seal with no opening code, Z4 destination vs Z1–Z3 credential, uncontrolled payload) can be high.

## Why these 18 are leftovers

1. **high_flip** — GPT and Grok disagree and one label is `high`.
2. **unknown** — GPT, Grok, or both used `unknown` (includes two rows where they already agree on `unknown`).
3. **neither** — Claude rejected both GPT `none` and Grok `medium` and proposed `low`.

## Calibration used on the other 102 (context only)

- GPT overused `none` with a template “no material safety/privacy/hazard pathway” rationale. Ordinary physical tasks with a reversible error pathway were settled as `low`, not `none`.
- Grok never used `none` and often inflated public-space / wrong-setup / hypothetical egress to `medium`. Settled gold used `medium` only when the scene has a real public-path, emergency-egress, chemical/food, specimen, heat, conveyor, or clinical-logistics pathway.
- Adjacent-band drift is expected. Prefer the label that matches the **worst plausible wrong execution evidenced in this card**, not a generic “robots can drop things” story.

## Claude recommendations (not binding)

Each card has `claude_recommendation`, `claude_choice`, and `claude_why`. You may keep it, prefer GPT (A), prefer Grok (B), or write a new current-scale value.

## Output

Fill every row in `leftover_worksheet.jsonl`. Return the same 18 lines, same `record_id`s, with these fields completed:

```json
{
  "record_id": "CA-XXXX",
  "gpt_a": "...",
  "grok_b": "...",
  "claude_recommendation": "...",
  "claude_choice": "A|B|neither|agree",
  "leftover_reason": ["..."],
  "final_risk_level": "none|low|medium|high|unknown",
  "decision": "prefer_A|prefer_B|new_value",
  "rationale": "one sentence citing command/scene/capability evidence"
}
```

Rules:

- Use only the current five labels.
- `decision=prefer_A` or `prefer_B` only if `final_risk_level` equals that annotator’s label.
- `decision=new_value` if you reject both annotators (allowed, including rejecting Claude).
- One sentence rationale. No markdown. No extra records.
- Adjudicate all 18, including the two GPT/Grok `unknown` agreements.

After you finish, send back the filled `leftover_worksheet.jsonl` only.
