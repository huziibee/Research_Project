# Blindness attestation

The adjudication input was the sanitized residual packet only. It contained source, frozen core gold, historical A/B annotations, and mechanical candidates; it did not contain T39 predictions, scores, manager outputs, system IDs, or evidence-atlas results. All 98 decision rows set `prediction_blind_attestation=true`, and the validator passed 98/98.

Artifact-level exposure blindness is verified, and the supplied independent adjudicator returned the 98 decisions with the stated strict-blind source. This decision file supersedes the provisional local decision file.
