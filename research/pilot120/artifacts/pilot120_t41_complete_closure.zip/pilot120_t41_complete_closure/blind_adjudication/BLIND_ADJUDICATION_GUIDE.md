# Prediction-blind residual adjudication guide

## Purpose

This packet contains only the residual rich interpretation fields that could not be promoted by deterministic normalization or pre-T39 dual-annotation consensus. It deliberately excludes T39 predictions, model outputs, system identities, accuracy numbers, and scoring results.

The adjudicator's job is **not to re-annotate all 120 records from scratch**. For each packet row, adjudicate only `fields_requiring_blind_adjudication` using:

1. the current frozen source record (authoritative after QA repairs),
2. frozen core Pilot gold for route/ambiguity/capability/strategy sequence,
3. historical Annotator A and B interpretations,
4. the mechanical candidate as a starting point,
5. the frozen handbook and canonical T41/CPC schema.

## Canonical CPC slots

Use only:

`action, actor, object, object_attributes, destination, spatial_relation, quantity, time, recipient, tool, conditions, constraints, negation`

Return `cpc` as `{ "slots": { ... } }`. Use concise source-grounded values. Do not add information that cannot be supported by command/dialogue/scene/capability context.

## Special rules

- `actor` is normally `robot` unless the command semantically assigns another actor.
- Current frozen source supersedes old annotation wording on the 10 QA-repaired Pilot records.
- Do not change frozen core route/ambiguity/capability labels in this task.
- For clarification, preserve ambiguity rather than selecting a candidate when source context does not uniquely resolve it.
- For rejection, target/reason must be compatible with frozen core capability status (`unauthorized`, `incapable`, `unsafe`).
- Do not treat ordinary temporal ordering (`after X`) as a conditional directive merely because it contains a timing condition.
- Do not use world-knowledge defaults when the benchmark requires explicit local evidence.
- Wording criteria are semantic: acceptable paraphrases are allowed; literal string equality is not required.

## Blinding

Do not access directories/files containing T39 predictions, scores, evidence atlases, forensic result summaries, or manager outputs until all adjudication decisions have been written and SHA-256 frozen.

Each decision row must contain `prediction_blind_attestation: true`.

## Output shape

One JSON object per input record:

```json
{
  "record_id": "CA-0007",
  "adjudicator_pseudonym": "blind_agent_01",
  "prediction_blind_attestation": true,
  "field_decisions": {
    "cpc": {"slots": {"action": "deliver", "actor": "robot"}},
    "source_repair_revalidation": {"current_source_approved": true}
  },
  "decision_rationale": {
    "cpc": "Short source-grounded rationale.",
    "source_repair_revalidation": "Current source resolves the historical repaired field without changing the frozen route."
  }
}
```

Only include the fields requested by that packet row.
