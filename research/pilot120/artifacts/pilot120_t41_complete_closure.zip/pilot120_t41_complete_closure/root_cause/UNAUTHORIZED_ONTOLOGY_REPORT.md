# Unauthorized ontology defect

Confirmed. Frozen Pilot gold includes `unauthorized` (12 records), while the manager capability enum is `capable`, `conditional`, `incapable`, `unknown` (`scripts/evaluate_pilot_120_manager_systems.py:70-74, 107`). The frozen canonical map converts `unauthorized` to `unknown` at line 74. The full manager predictions show these 12 records distributed as conditional 2, incapable 3, unknown 7; routes are clarify 9 and rejection 3. This conflates authorization with inability/uncertainty and is a prospective architecture defect. Frozen T39 is unchanged.
