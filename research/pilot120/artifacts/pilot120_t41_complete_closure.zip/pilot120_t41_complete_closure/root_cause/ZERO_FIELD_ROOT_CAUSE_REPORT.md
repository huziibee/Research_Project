# Zero-field root-cause report

## Finding

Across the frozen R1 manager outputs, every structured interpretation field is empty on all 120 records: CPC 0/120, candidates 0/120, selected interpretation 0/120, resolved slots 0/120, and resolution evidence 0/120. The same parsed structures are invariant across R1-R5.

## Exact mechanism

The frozen manager prompt requests only `speech_act`, `pilot_ambiguity_types`, `pilot_capability_status`, `risk_level`, `unresolved_slots`, and `uncertainty` (frozen source `scripts/evaluate_pilot_120_manager_systems.py:160-171`). It does not elicit CPC values, candidate frames, selected interpretation, resolved values, or resolution evidence. The manager schema at lines 93-109 contains only the reduced analysis contract. Normalization at lines 205-269 maps that reduced response into the manager object; absent rich fields are consequently defaulted by the downstream contract to empty/null structures.

The saved raw response is therefore not evidence that the model emitted the missing rich fields: for the audited rows these keys are absent from raw content. The information is not recovered by parsing, and the evaluator correctly observes empty saved fields. This is primarily `PROMPT_NOT_ELICITED` + `MODEL_DID_NOT_EMIT` + `SCHEMA_DEFAULTED_EMPTY`, with no evidence of parser loss for the missing fields.

## Evaluator

The T41 scorer reads `parsed.analysis.cpc`, `candidate_interpretations`, and runtime `resolution_events`; the frozen row contract uses these same locations. Empty structures are counted as incorrect, not excluded. Direct base/adapter rich fields are `NOT_COMPUTED` because their official contract does not expose comparable structured fields.

See `aggregate_failure_layer_counts.json` and `record_traces.json` for machine-generated counts and exemplars.
