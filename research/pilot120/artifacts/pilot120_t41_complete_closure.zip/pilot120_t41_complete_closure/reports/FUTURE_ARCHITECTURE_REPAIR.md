# Future architecture repair

`future_architecture/interpretation_manager_v2.py` is a separate prospective implementation. It makes intent, canonical CPC, candidates, selected frame, unresolved/resolved slots, resolution evidence, confidence, capability, authorization, risk, clarification, rejection, and terminal recommendation first-class serialized fields.

The parser rejects invalid capability enums and resolved values without evidence. The router rejects unsafe, incapable, and unauthorized actions distinctly; it clarifies unresolved or non-unique cases and executes a unique evidenced resolution without unnecessary clarification. `test_interpretation_manager_v2.py` proves prompt-fixture → parser → manager/router → serialization → evaluator preservation with 16 passing tests.

This repair has not been run on Pilot-120 and must not be presented as an improved T39/T41 model result.
