# What is now closed

A 120-record adjudicated interpretation sidecar exists, with field-level provenance and frozen SHA-256. Residual coverage is 98 records / 222 decisions. Frozen R1 manager outputs were scored without inference. The zero-field mechanism and unauthorized ontology defect are documented. A separately versioned v2 contract/parser/router passes end-to-end synthetic tests.
