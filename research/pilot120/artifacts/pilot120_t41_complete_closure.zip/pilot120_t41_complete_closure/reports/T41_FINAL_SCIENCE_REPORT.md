# T41 final science report

The frozen Pilot-120 interpretation key is complete for all 120 records. Residual adjudication covers 98 records / 222 field items; the supplied independent adjudicator returned the decisions from the sanitized packet only, with no prediction or metric fields.

Frozen R1 manager results (R2-R5 have identical structured-field behavior): degree intent 76/120 (63.33%), full type/risk-aware intent 76/120 (63.33%), context-blind intent 82/120 (68.33%). All three: CPC 0/120, candidate sets 0/120, selected interpretation 0/120, resolved slots 0/120, resolution evidence 0/120, silent value+evidence 0/51. Final gold has 660 CPC slots under the now-frozen CPC v1.1 policy. Full manager clarification: route 23/23, useful target 20/23, clean target 4/23. Full manager rejection: route 10/21, route+reason 7/21.

The richer manager can route worse because the rich ambiguity information is not represented in its output contract; the deterministic router receives unresolved/uncertain signals and conservative capability mappings, while authorization is collapsed into an incompatible ontology. These are supported mechanism findings, not a claim that any one latent model behavior caused every terminal decision.

No T39 inference, prompt, model, adapter, threshold, or frozen input was changed or rerun. The v2 repair is synthetic-fixture-only and has no scientific performance claim.
