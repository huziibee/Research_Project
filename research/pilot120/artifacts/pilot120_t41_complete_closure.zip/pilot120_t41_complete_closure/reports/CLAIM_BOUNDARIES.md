# Claim boundaries

**Confirmed:** the 120-record interpretation key, frozen T39 manager outputs, reported denominators, zero structured-field emission, intent/clarification/rejection results, and the unauthorized ontology mismatch.

**Supported mechanism:** prompt omission followed by reduced schema normalization and empty defaults; R1-R5 invariance supports this as a systemic contract issue.

**Exploratory:** explanations for why the model's reduced intent/risk analysis made particular terminal choices beyond the observable router traces.

**Future hypothesis:** interpretation_manager_v2 will improve future scientific performance. It is only tested on synthetic fixtures here and has not been run on Pilot-120.
