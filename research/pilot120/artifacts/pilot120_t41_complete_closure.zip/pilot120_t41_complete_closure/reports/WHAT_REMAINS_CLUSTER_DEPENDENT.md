# What remains cluster-dependent

No cluster compute is required to close this T41 interpretation sidecar. The next cluster experiment is a separately frozen T42/T43/T44 study using the repaired contract; it requires new inference, exact prompt/render/token attestation, and fresh performance evidence. No claim of improved scientific performance is made here.
