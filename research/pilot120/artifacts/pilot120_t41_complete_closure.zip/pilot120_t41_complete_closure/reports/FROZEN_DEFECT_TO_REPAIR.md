| Frozen defect | Root cause | Future repair | Test |
|---|---|---|---|
| CPC 0/120 | Prompt does not elicit CPC; reduced contract defaults fields empty | First-class canonical CPC response | `test_structured_fields_survive_end_to_end` |
| Candidates 0/120 | No candidate field in frozen analysis prompt/schema | Candidate list required in v2 contract | same |
| Resolution/evidence 0/120 and 0/51 | No resolved/evidence fields requested or preserved | Evidence-gated resolved slots | `test_unique_resolution_does_not_clarify`, invalid-evidence test |
| Unauthorized collapsed | Frozen map converts unauthorized to unknown | Six-state capability ontology | `test_authorization_and_safety_are_not_capability_aliases` |
| Clarify after unique resolution | Router cannot see resolution confidence/evidence | Router consumes unresolved/resolved/confidence/evidence | unique-resolution test |
