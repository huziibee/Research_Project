# Exact remaining blockers

1. **Official CPC policy:** resolved by `frozen_evidence/cpc_normalisation_v1_1_frozen.json`, which freezes the 13-slot vocabulary and deterministic comparison rules. The original development artifact remains preserved unchanged.
2. **Independent blindness:** resolved by the supplied independent adjudicator artifact at the artifact/process-attestation level. The decisions SHA is `46bb3d7db5f4941bd21097105424b2bbc427314e61edfc96db4b7cd20d2a3aa1`.
3. **Cluster blocker for future science only:** no new T41 inference is needed. Future T42/T43/T44 results require a separately frozen repaired system, prompt/render/token binding, cluster inference, and new evaluation. No improvement claim is made here.
