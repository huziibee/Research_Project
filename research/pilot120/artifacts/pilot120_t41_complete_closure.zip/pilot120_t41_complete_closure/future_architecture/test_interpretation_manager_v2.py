import json
import pytest

from interpretation_manager_v2 import build_prompt, evaluate_saved, manager_from_model_response, parse_response, route, serialize


def frame(**extra):
    value = {"intent": "direct_execute", "cpc": {"slots": {"action": "deliver", "object": "tray"}}, "candidate_interpretations": [{"id": "c1"}], "selected_interpretation": "c1", "unresolved_slots": [], "resolved_slots": {"time": "11:00"}, "resolution_evidence": [{"text": "at 11:00", "source": "scene"}], "resolution_confidence": "unique", "capability": "capable", "authorization": "authorized", "risk": "low", "clarification": None, "rejection_reason": None, "terminal_recommendation": "execute"}
    value.update(extra)
    return value


@pytest.mark.parametrize("kind", ["direct_execute", "reference_resolution", "discourse_resolution", "lexical_resolution", "scope_resolution", "silent_resolution", "multi_slot_cpc", "candidate_enumeration"])
def test_structured_fields_survive_end_to_end(kind):
    obj = parse_response(json.dumps(frame(test_kind=kind)))
    assert route(obj) == "execute"
    saved = evaluate_saved(serialize(obj))
    assert saved["cpc"]["slots"]
    assert saved["candidate_interpretations"]
    assert saved["resolved_slots"] == {"time": "11:00"}
    assert saved["resolution_evidence"]


@pytest.mark.parametrize("capability,authorization", [("capable", "unauthorized"), ("incapable", "authorized"), ("unsafe", "authorized")])
def test_authorization_and_safety_are_not_capability_aliases(capability, authorization):
    obj = parse_response(json.dumps(frame(capability=capability, authorization=authorization, resolved_slots={}, resolution_evidence=[])))
    assert route(obj) == "reject"
    assert obj["capability"] == capability and obj["authorization"] == authorization


def test_ambiguous_clarification():
    obj = parse_response(json.dumps(frame(unresolved_slots=["object"], resolved_slots={}, resolution_evidence=[], resolution_confidence=None)))
    assert route(obj) == "clarify"


def test_unique_resolution_does_not_clarify():
    assert route(parse_response(json.dumps(frame()))) == "execute"


def test_prompt_to_evaluator_pipeline():
    prompt = build_prompt({"record_id": "CA-SYNTH", "command": "deliver the tray"})
    assert "candidate_interpretations" in prompt and "resolution_evidence" in prompt
    obj = manager_from_model_response(json.dumps(frame()))
    assert evaluate_saved(serialize(obj))["terminal_recommendation"] == "execute"


def test_empty_executable_interpretation_fails_closed():
    obj = parse_response(json.dumps(frame(cpc={"slots": {}}, candidate_interpretations=[], selected_interpretation=None)))
    with pytest.raises(ValueError, match="missing_structured_fields"):
        route(obj)


@pytest.mark.parametrize("raw", [json.dumps(frame(resolved_slots={"time": "11:00"}, resolution_evidence=[])), json.dumps(frame(capability="not_allowed")), json.dumps(frame(authorization="not_allowed"))])
def test_invalid_or_missing_structures_fail_closed(raw):
    with pytest.raises(ValueError): parse_response(raw)
