# interpretation_manager_v2

Prospective, synthetic-fixture-only repair. It is versioned separately from frozen T39 and was not used to rerun or reinterpret T39 inference.

The contract makes CPC, candidate frames, selected interpretation, unresolved/resolved slots, evidence, authorization, risk, clarification and rejection first-class fields. Parsing rejects resolved values without evidence and invalid capability values. Routing distinguishes `unauthorized`, `unsafe`, and `incapable`; it clarifies only for unresolved or non-unique cases.
