"""Prospective structured interpretation contract; never used by frozen T39."""
from __future__ import annotations
import json

CAPABILITY = {"capable", "conditional", "incapable", "unsafe", "unknown"}
AUTHORIZATION = {"authorized", "unauthorized", "unknown"}
CPC = {"action", "actor", "object", "object_attributes", "destination", "spatial_relation", "quantity", "time", "recipient", "tool", "conditions", "constraints", "negation"}


def parse_response(raw: str) -> dict:
    value = json.loads(raw)
    if not isinstance(value, dict):
        raise ValueError("response_must_be_object")
    value.setdefault("cpc", {"slots": {}})
    value.setdefault("candidate_interpretations", [])
    value.setdefault("selected_interpretation", None)
    value.setdefault("unresolved_slots", [])
    value.setdefault("resolved_slots", {})
    value.setdefault("resolution_evidence", [])
    capability = value.get("capability", "unknown")
    if capability not in CAPABILITY:
        raise ValueError(f"invalid_capability:{capability}")
    authorization = value.get("authorization", "unknown")
    if authorization not in AUTHORIZATION:
        raise ValueError(f"invalid_authorization:{authorization}")
    slots = value["cpc"].get("slots", {})
    if not set(slots) <= CPC:
        raise ValueError("invalid_cpc_slot")
    if value.get("resolved_slots") and not value.get("resolution_evidence"):
        raise ValueError("resolved_values_require_evidence")
    return value


def route(interpretation: dict) -> str:
    if interpretation["authorization"] == "unauthorized" or interpretation["capability"] in {"unsafe", "incapable"}:
        return "reject"
    if interpretation.get("unresolved_slots"):
        return "clarify"
    if not interpretation.get("cpc", {}).get("slots") or not interpretation.get("candidate_interpretations") or not interpretation.get("selected_interpretation"):
        raise ValueError("executable_interpretation_missing_structured_fields")
    if interpretation.get("resolved_slots"):
        if not interpretation.get("resolution_evidence"):
            raise ValueError("resolution_without_evidence")
        if interpretation.get("resolution_confidence") != "unique":
            return "clarify"
    return "execute"


def build_prompt(record: dict) -> str:
    return "Return JSON with intent, cpc, candidate_interpretations, selected_interpretation, unresolved_slots, resolved_slots, resolution_evidence, resolution_confidence, capability, authorization, risk, clarification, rejection_reason, and terminal_recommendation. Use evidence for every resolved value.\nSOURCE:\n" + json.dumps(record, ensure_ascii=False, sort_keys=True)


def manager_from_model_response(raw: str) -> dict:
    return parse_response(raw)


def serialize(interpretation: dict) -> str:
    # Preserve all structured fields, including explicit empty/non-empty values.
    return json.dumps(interpretation, ensure_ascii=False, sort_keys=True)


def evaluate_saved(serialized: str) -> dict:
    return parse_response(serialized)
