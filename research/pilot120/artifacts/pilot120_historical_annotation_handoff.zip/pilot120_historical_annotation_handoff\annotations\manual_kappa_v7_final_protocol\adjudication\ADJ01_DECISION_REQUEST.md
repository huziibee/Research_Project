# ADJ-01 Decision Request (Pilot-120 final-protocol)

## What ADJ-01 is

`ADJ-01` is the **official adjudicator identity slot** in:

- `configs/annotation/annotation_roles_v1.json`
- `docs/protocols/annotation_role_policy_v1.md`

It is the person (or explicitly approved role substitute) who may close
ANN-A / ANN-B disagreements for **official** final-protocol gold.

## What ADJ-01 is not

ADJ-01 is **not automatically** the pilot Claude Sonnet packet adjudicator.

For the **historical pilot** (`annotations/manual_kappa_v7/`), disagreement packets
were adjudicated under `GOLD_ADJUDICATION_RULES.md` by Claude Sonnet, with human
gates for terminal / `chose: neither` / validity conflicts. That work remains
labelled **`pilot_annotation_agreement`** and must not silently become
final-protocol ADJ-01 policy.

## Why it blocks freeze

Official gold export / freeze refuses unresolved adjudicator identity:

- role policy: ADJ-01 status = `unresolved`
- T14C ticket: adjudicator identity deferred until policy approval
- Pilot-120 freeze guard: `blocks_freeze = true` while unresolved

## Smallest possible human decision

Choose **one** option and write it to:

`annotations/manual_kappa_v7_final_protocol/adjudication/ADJ01_RESOLUTION.json`

### Option 1 — Name a human adjudicator (recommended for official claim)

```json
{
  "status": "resolved",
  "pseudonym": "ADJ-01",
  "person_name": "<FULL NAME>",
  "role_basis": "T14C_policy_approval",
  "may_adjudicate_pilot120_final_protocol": true,
  "must_not_be_ann_a_or_ann_b_on_same_record": true,
  "notes": "Official human adjudicator for Pilot-120 final-protocol disagreements only."
}
```

### Option 2 — Explicitly approve pilot-style model packet adjudicator + human gate

Only if supervisors formally approve this as Pilot-120 final-protocol policy
(do **not** imply this by silence):

```json
{
  "status": "resolved",
  "pseudonym": "ADJ-01",
  "person_name": null,
  "adjudicator_type": "model_packet_adjudicator_with_human_gate",
  "model": "claude-4.6-sonnet-medium-thinking",
  "rules_file": "annotations/manual_kappa_v7/GOLD_ADJUDICATION_RULES.md",
  "human_gate_required_for": [
    "terminal_strategy_disagreement",
    "chose_neither",
    "record_validity_disagreement"
  ],
  "role_basis": "explicit_supervisor_policy_for_pilot120_final_protocol",
  "may_adjudicate_pilot120_final_protocol": true,
  "notes": "Approved only for Pilot-120 final-protocol; does not rewrite frozen annotation_roles_v1 without a separate governance update."
}
```

Until one of these files exists with `"status": "resolved"`, Pilot-120 may be
prepared and annotated, but **must not** truthfully claim:

`Pilot-120 v1: FINAL-PROTOCOL ANNOTATED, ADJUDICATED, FROZEN, HASHED, EVALUATION-ONLY`
