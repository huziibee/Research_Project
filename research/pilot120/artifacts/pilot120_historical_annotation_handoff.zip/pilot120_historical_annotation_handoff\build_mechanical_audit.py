import csv, hashlib, json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
H = ROOT / 'annotations' / 'manual_kappa_v7'
A = H / 'annotator_a_grok'; B = H / 'annotator_b_claude'; G = H / 'gold'; ADJ = H / 'adjudication'

def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def canon(v): return json.dumps(v, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()
def ids_from_jsonl(p):
    return [json.loads(x)['record_id'] for x in p.read_text(encoding='utf-8-sig').splitlines() if x.strip()]

ids = sorted(p.stem for p in A.glob('CA-*.json'))
ar = {i: load(A/(i+'.json')) for i in ids}; br = {i: load(B/(i+'.json')) for i in ids}
gr = {p.stem: load(p) for p in G.glob('CA-*.json')}
fields=sorted(set().union(*(set(ar[i])|set(br[i]) for i in ids)))
rows=[]
for i in ids:
    for f in fields:
        av=ar[i].get(f); bv=br[i].get(f)
        if canon(av)!=canon(bv):
            rows.append([i,f,canon(av),canon(bv),'DISAGREE','JSON canonical sort_keys; no semantic normalization','YES' if (ADJ/'packets'/(i+'.json')).exists() else 'NO'])
out=ROOT/'disagreements'; out.mkdir(exist_ok=True)
with (out/'reconstructed_disagreement_ledger.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['record_id','field','annotator_a_value','annotator_b_value','agreement_status','normalization_used_if_any','sent_to_adjudication?']); w.writerows(rows)

inv=ROOT/'inventory'; inv.mkdir(exist_ok=True)
kmetrics=load(H/'kappa_report.json').get('metrics',{})
with (inv/'annotation_field_inventory.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['field_name','present_in_A?','present_in_B?','present_in_final?','records_covered','agreement_metric_available?','adjudicated?','notes'])
    for field in fields:
        ac=sum(field in ar[i] for i in ids); bc=sum(field in br[i] for i in ids); gc=sum(field in gr[i] for i in ids)
        metric = field in kmetrics or field == 'ambiguity_types'
        w.writerow([field,bool(ac),bool(bc),bool(gc),f'A={ac}; B={bc}; final={gc}','SEE historical kappa reports' if metric else 'NOT IDENTIFIED','SEE gold manifest/status' if field in ('terminal_strategy','ambiguity_types','capability_status') else 'NOT IDENTIFIED','Top-level presence only; nested structures remain raw.'])

with (ROOT/'provenance_ledger.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['record_id','field','final_value','source'])
    for i in ids:
        for field in sorted(set(gr[i])|set(ar[i])|set(br[i])):
            fv=gr[i].get(field); av=ar[i].get(field); bv=br[i].get(field)
            src='agreement_A_B' if canon(av)==canon(bv)==canon(fv) else ('adjudicator' if (ADJ/'decisions'/(i+'.json')).exists() else 'UNKNOWN_PROVENANCE')
            w.writerow([i,field,canon(fv),src])

align=ROOT/'pilot_alignment'; align.mkdir(exist_ok=True)
hist_ids=ids_from_jsonl(H/'eval'/'subset_120_eval.jsonl')
curp=Path('data/annotations/pilot_120_v1/source_canonical.jsonl'); cur_ids=ids_from_jsonl(curp) if curp.exists() else []
report={'historical_commit':'8e430ab','historical_ids_count':len(hist_ids),'current_frozen_source':str(curp),'current_ids_count':len(cur_ids),'id_set_equal':set(hist_ids)==set(cur_ids),'historical_order_equals_current':hist_ids==cur_ids,'historical_source_sha256':sha(H/'subset_120_inputs.json'),'current_source_canonical_jsonl_sha256':sha(curp) if curp.exists() else None,'historical_gold_eval_sha256':sha(H/'eval'/'subset_final_gold_eval.jsonl'),'current_gold_jsonl_sha256':sha(Path('data/annotations/pilot_120_v1/pilot_120_final_gold.jsonl')) if Path('data/annotations/pilot_120_v1/pilot_120_final_gold.jsonl').exists() else None,'caveat':'Historical tree extracted from Git commit 8e430ab; current source/gold are alignment evidence. Hash equality is not assumed.'}
(align/'alignment_report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
(align/'pilot_ids.txt').write_text('\n'.join(cur_ids)+'\n',encoding='utf-8')

prov=ROOT/'provenance'; prov.mkdir(exist_ok=True); entries=[]
for p in sorted(ROOT.rglob('*')):
    if p.is_file() and p.relative_to(ROOT).as_posix() not in {'provenance/MANIFEST.tsv','provenance/SHA256SUMS'}:
        entries.append((p.relative_to(ROOT).as_posix(),p.stat().st_size,sha(p)))
with (prov/'MANIFEST.tsv').open('w',encoding='utf-8',newline='') as f:
    f.write('path\tsize_bytes\tsha256\n'); f.writelines(f'{a}\t{b}\t{c}\n' for a,b,c in entries)
(prov/'SHA256SUMS').write_text(''.join(f'{c}  {a}\n' for a,b,c in entries),encoding='utf-8')
(ROOT/'contamination_audit').mkdir(exist_ok=True)
(ROOT/'contamination_audit'/'blindness_report.md').write_text('''# Blindness and contamination audit

Evidence basis: preserved brief, protocol, raw A/B JSON, adjudication packets, and adjudicator brief.

| actor | classification | evidence | limit |
|---|---|---|---|
| Annotator A (Grok) | LIKELY_BLIND | Brief prohibits model outputs, prior labels, sibling records, and gold. | No runtime transcript proves compliance. |
| Annotator B (Claude/GLM eras) | LIKELY_BLIND | Same one-record isolation brief; roster documents the model-era split. | No runtime transcript proves compliance. |
| Adjudicator | NOT_BLIND to A/B | Packets contain both annotator answers and disagreement context. | Intentional adjudication exposure. |
| A/B vs T39 outputs | UNKNOWN | No prediction/result fields found in preserved A/B inputs or brief. | Absence is not proof about external sessions. |

The final-protocol scaffold is not completed reannotation: its A/B directories are empty and agreement is `not_started`.
''',encoding='utf-8')
(ROOT/'MISSING_ARTIFACTS.md').write_text('''# Missing or unresolved historical artifacts

- No model API request/response transcript, temperature/decoding log, or session-level proof of A/B instruction compliance.
- No separate human adjudicator transcript; preserved material is model packet decisions plus human-gate documents.
- Historical reports/code are preserved, but the exact historical runtime environment/dependency lock is not.
- Current final-protocol A/B annotation and agreement are absent by design (`status: not_started`).
- Historical/current source hash equality is not assumed; see `pilot_alignment/alignment_report.json`.
''',encoding='utf-8')
(ROOT/'ANNOTATION_AUDIT_HANDOFF.md').write_text(f'''# Pilot-120 Historical Annotation Audit Handoff

This package preserves the historical annotation tree from Git commit `8e430ab` and adds current frozen Pilot-120 alignment evidence plus mechanically derived ledgers. No annotation values were created or modified.

## Direct answers

- **A. Raw independent annotations:** YES. A: `annotations/manual_kappa_v7/annotator_a_grok/` ({len(ar)} records). B: `annotations/manual_kappa_v7/annotator_b_claude/` ({len(br)} records). B is documented as 70 Claude-era and 50 GLM-era records.
- **B. Final adjudicated annotation:** YES. `annotations/manual_kappa_v7/gold/` ({len(gr)} records), with JSONL exports and manifests.
- **C. Exact annotation prompts:** YES for preserved v7 brief/handbook/schema and adjudicator brief; runtime/API transcripts are missing.
- **D. Agreement code/results:** PARTIAL. Reports and kappa outputs are preserved; relevant repository implementation is copied under `repository_context/`.
- **E. Meaning of 80%:** Historical artifacts report **Cohen's kappa and raw percentage agreement separately**; no universal 0.80 kappa gate is evidenced in the preserved result. Core gold fields are `terminal_strategy` and `ambiguity_types`.
- **F. Historical pooled results:** n=120 paired=120; terminal κ={kmetrics['terminal_strategy']['cohen_kappa']}, raw={kmetrics['terminal_strategy']['raw_agreement']}; capability κ={kmetrics['capability_status']['cohen_kappa']}, raw={kmetrics['capability_status']['raw_agreement']}; primary κ={kmetrics['primary_ambiguity_type']['cohen_kappa']}, raw={kmetrics['primary_ambiguity_type']['raw_agreement']}; recommended κ={kmetrics['recommended_strategy']['cohen_kappa']}, raw={kmetrics['recommended_strategy']['raw_agreement']}; risk κ={kmetrics['risk_level']['cohen_kappa']}, raw={kmetrics['risk_level']['raw_agreement']}; validity κ={kmetrics['record_validity']['cohen_kappa']}, raw={kmetrics['record_validity']['raw_agreement']}.
- **G. Adjudication selection:** {len(list((ADJ/'packets').glob('CA-*.json')))} preserved packet records; historical report states 3 terminal and 30 ambiguity-type-set disagreements. Mechanical top-level ledger rows: {len(rows)}.
- **H. Distinct adjudicator:** YES, a distinct Claude packet-adjudicator role; A/B answers were exposed. Human-gate documents are preserved.
- **I. Exact frozen T39 alignment:** PARTIAL; ID/order and hashes are compared in `pilot_alignment/alignment_report.json` without silent remapping.
- **J. A/B blindness:** LIKELY_BLIND from the preserved brief, not independently verified; adjudicator intentionally NOT_BLIND to A/B; T39-output exposure UNKNOWN.
- **K. Fields covered:** `inventory/annotation_field_inventory.csv`; raw nested structures remain in original JSON.
- **L. Missing:** `MISSING_ARTIFACTS.md`.

## Preservation and verification

Historical files were extracted from Git without semantic rewriting. Derived ledgers are clearly labelled. Manifest and SHA-256 list are under `provenance/`.
''',encoding='utf-8')
print(json.dumps({'annotator_A':len(ar),'annotator_B':len(br),'gold':len(gr),'disagreement_rows':len(rows),'fields':len(fields),'manifest_entries':len(entries)},indent=2))
