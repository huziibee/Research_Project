# Blind Annotator Brief — Compound Ambiguity v7 (Kappa Study)

You are an **independent blind annotator**. Annotate **exactly one** input record.

## Hard isolation rules (non-negotiable)

1. Read **only** these files (absolute paths provided in the task prompt):
   - this brief
   - the handbook
   - the output schema
   - the **single** input JSON for your assigned `record_id`
2. Do **not** open, list, search, or read any other compound, annotation, package partition, generator label, failed attempt, or sibling `CA-*.json`.
3. Do **not** use GPT Sol / generator outputs or any pre-existing gold labels.
4. Do **not** look at Annotator A or Annotator B outputs (yours or the other stream).
5. If you encounter another record accidentally, stop and ignore it.

## Task

Produce one JSON annotation object conforming to the v7 output schema and handbook.

- One canonical handling path and exactly one terminal outcome.
- Use only `command`, `dialogue_history`, `scene_context`, `capability_context` (+ ordinary linguistic competence).
- Label linguistic ambiguity types from the v7 inventory when two task-relevant readings exist before contextual resolution.
- Risk / authorization / capability are routing constraints, **not** ambiguity types.

## Allowed ambiguity types

`pragmatic`, `discourse_ellipsis`, `lexical`, `scope`, `object_reference`, `pronoun_reference`, `recipient_reference`, `destination_reference`, `instrument_reference`, `spatial_reference`, `temporal_reference`, `routine_reference`, `action_order`, `fuzzy_temporal`, `fuzzy_quantity`, `degree_vagueness`, `endpoint_vagueness`

## Write output

Write **only** the annotation JSON object to the output path given in the prompt (overwrite if present).

No markdown fences. No commentary file. No chain-of-thought dump in evidence fields — keep evidence/support concise and quotation-backed.

## Sanity checks before writing

1. `compound_ambiguity_count == len(ambiguity_types)`
2. `primary_ambiguity_type` is in `ambiguity_types` (or null only if none)
3. `strategy_sequence` ends with `terminal_strategy`
4. Evidence quotations are exact substrings of named fields
5. Clarification: exactly one unresolved slot with exactly two complete candidate values
6. Valid records should have ≥2 defensible ambiguity types per handbook §9
