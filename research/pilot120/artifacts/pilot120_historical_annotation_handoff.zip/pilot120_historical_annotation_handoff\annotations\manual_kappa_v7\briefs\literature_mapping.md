# Literature mapping (annotator appendix) — not a second taxonomy

This study uses the **v7 handbook taxonomy** as the sole annotation codeset.

The mapping below situates v7 against common NLP taxonomies ([Li et al. 2024](https://arxiv.org/abs/2403.14072); AMBIENT / Liu et al. 2023). Use it only if a borderline case needs intuition; **always emit v7 labels**.

| Literature / classical bucket | Closest v7 label(s) | Robot-HRI note |
| --- | --- | --- |
| Lexical | `lexical` | Task-relevant senses only |
| Syntactic / attachment | often `scope`, sometimes reference | Prefer slot effect over grammar debate |
| Scopal | `scope` | Operator/order changing action or target |
| Elliptical | `discourse_ellipsis` | Recover omitted operation from dialogue/context |
| Coreferential | `pronoun_reference` (+ other `*_reference`) | Split by referent class in v7 |
| Implicative / pragmatic force | `pragmatic` | Indirect request / ISA vs literal form |
| Idiomatic / figurative | usually `lexical` or `pragmatic` | Choose by whether sense or force dominates route |
| Genericity / type–token | rare; often `lexical` or fuzzy | Only if it changes robot action |
| Collective / distributive | often `scope` | Affects how many actions/targets |
| Vagueness (time/qty/degree/end) | `fuzzy_temporal`, `fuzzy_quantity`, `degree_vagueness`, `endpoint_vagueness` | Deterministic silent resolve vs clarify |
| Temporal event pick | `temporal_reference` | Distinct event occurrences — not mere vague “soon” |
| Routine / procedure pick | `routine_reference` | Multiple procedures initially match |
| Action sequencing | `action_order` | Materially different feasible orders |

Primary-type tie-break (handbook): pragmatic → discourse ellipsis → scope → lexical → reference → action order/routine → fuzzy.
