# FINAL SEMANTIC QA REPORT — Compound Ambiguity v7

Date: 2026-08-07  
Scope decision: **minimal subset repairs + full deferred audit** (do not mass-edit the 1000 yet).

## Verdict

### 1000 input benchmark

**NOT READY TO FREEZE**

Outstanding: **231** category-D capability rows remain outside the intended minimal-repair scope
(see `docs/DEFERRED_FULL_1000_SEMANTIC_QA_NOTES.md` and `annotations/private_owner_qa_v7/FULL_1000_CAPABILITY_AUDIT.json`).

### 120 gold evaluation set

**NOT FINALIZED** — pilot gold remains usable for interim analysis under calibrated rules, but
`120 GOLD EVALUATION SET FINALIZED` requires completing
`annotations/manual_kappa_v7_final_protocol/` independent reannotation + adjudication.

Pilot agreement is preserved as `pilot_annotation_agreement`
(`annotations/manual_kappa_v7/KAPPA_STRATA.md`). Final-protocol agreement must be reported separately.

## Defects found

1. **Family-wide insufficient capability evidence (D)** for refill / seal / inspect / charge / deliver / record
   action families — public `capability_context` often omitted the requested action while gold/intended
   execute paths assumed capability. **Family-wide**, not isolated.
2. **Subset-critical slice of (1)** — execute (and some clarify) rows in the 120 lacked explicit action
   evidence under the finalized handbook rule. **Repaired in this pass (capability_context only).**
3. **Full 1000 one-path private contracts** still incomplete for non-subset rows (deferred; not a single
   isolated record issue).
4. Prior repaired issues (clean / open-return / degree-endpoint / human-gate / known CA-* cases) remain
   intact and must not be reverted.

## What changed this pass

| Metric | Value |
| --- | ---: |
| Records changed (subset-only capability repairs) | 20 |
| Families touched | 9 |
| `capability_context` changes | 20 |
| `scene_context` changes | 0 |
| `command` changes | 0 |
| Replacements | 0 |

Families: `['charge_sensible_level', 'deliver_selected_after_scheduled', 'deliver_to_recipient_after_scheduled', 'do_not_move_and_inspect', 'inspect_camera_release', 'refill_only_small_amount', 'refill_top_up_return', 'seal_batch_tool_until', 'seal_beside_return']`

## Capability QA counts (full 1000, post subset repairs)

| Class | Count |
| --- | ---: |
| A (explicitly supported) | 748 |
| B (explicitly blocked) | 21 |
| C (capability not route-critical yet) | 0 |
| D (insufficient capability evidence) | 231 |

Target before freeze: **D == 0** (currently unmet).

## One-path QA

| Scope | Result |
| --- | --- |
| Kappa subset private contracts | 120 / 120 `one_path_determinacy=true` |
| Full 1000 | Deferred stubs in `FULL_1000_ONE_PATH_QA.json` (`pending_full_semantic_pass`) |

## 120 gold terminal / routing / depth (pilot gold; interim)

| Terminal | n |
| --- | ---: |
| execute | 76 |
| clarify | 23 |
| face_preserving_rejection | 21 |

Ambiguity depth on pilot gold: depth 2 = 46, depth 3 = 54, depth 4 = 9, depth 5+ = 11.  
Human gates remaining: **0**.

## Annotation QA

| Item | Status |
| --- | --- |
| Pilot gold records | 120 (`pilot_annotation_agreement`) |
| Final-protocol reannotation package prepared | 120 inputs + empty A/B dirs |
| Final-protocol agreement run | **not started** |

## Artifacts

1. `FINAL_SEMANTIC_QA_REPORT.md` (this file)
2. `annotations/private_owner_qa_v7/FULL_1000_CAPABILITY_AUDIT.json`
3. `annotations/private_owner_qa_v7/FULL_1000_ONE_PATH_QA.json`
4. `annotations/private_owner_qa_v7/FINAL_SEMANTIC_REPAIR_CHANGELOG.json`
5. Updated 1000-record JSON / JSONL (subset capability_context repairs only)
6. Updated checksums
7. Handbook unchanged this pass (prior degree/endpoint + capability rules already present)
8. Validator unchanged this pass
9. Extended `tests/test_compound_ambiguity_v7_qa.py`
10–12. Annotator/experimenter/public fields unchanged aside from repaired subset inputs synced into kappa + final-protocol trees
13. `annotations/manual_kappa_v7_final_protocol/` scaffold
14. `docs/DEFERRED_FULL_1000_SEMANTIC_QA_NOTES.md`

## Exact commands to run next

```text
# 1) Automated QA
python -m pytest tests/test_compound_ambiguity_v7_qa.py -q

# 2) Review deferred full-1000 checklist before any freeze claim
#    docs/DEFERRED_FULL_1000_SEMANTIC_QA_NOTES.md

# 3) Start final-protocol reannotation (fresh contexts; do not read pilot A/B/gold)
#    See annotations/manual_kappa_v7_final_protocol/README.md

# 4) When ready for the deferred full-1000 repair:
python scripts/final_semantic_qa_v7_pass.py --help
# then implement family-wide D repairs in a dedicated follow-up (do not silent-regenerate).
```
