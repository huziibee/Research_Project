#!/usr/bin/env python3
"""Validate one JSONL annotation file against the v7 schema and one-path contract."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import jsonschema

TERMINALS = {'execute', 'clarify', 'face_preserving_rejection'}
REJECTION_STATUS = {
    'safety_constraint': 'unsafe',
    'hazard_constraint': 'unsafe',
    'authorization_constraint': 'unauthorized',
    'privacy_constraint': 'unauthorized',
    'capability_constraint': 'incapable',
}


def fail(msg: str) -> None:
    print(msg, file=sys.stderr)


def evidence_source(record: dict, field: str) -> str:
    if field == 'dialogue_history':
        return '\n'.join(record.get(field, []))
    return str(record.get(field, ''))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('dataset_json')
    ap.add_argument('annotations_jsonl')
    ap.add_argument('--schema', default=str(Path(__file__).with_name('compound_ambiguity_annotation_output_schema_v7.json')))
    args = ap.parse_args()

    dataset = json.loads(Path(args.dataset_json).read_text(encoding='utf-8'))
    expected_ids = [r['record_id'] for r in dataset]
    dataset_by_id = {r['record_id']: r for r in dataset}
    schema = json.loads(Path(args.schema).read_text(encoding='utf-8'))
    validator = jsonschema.Draft202012Validator(schema)

    annotations = []
    for line_no, line in enumerate(Path(args.annotations_jsonl).read_text(encoding='utf-8').splitlines(), 1):
        if not line.strip():
            continue
        try:
            annotations.append(json.loads(line))
        except json.JSONDecodeError as e:
            fail(f'line {line_no}: invalid JSON: {e}')
            return 1

    errors = []
    ids = [a.get('record_id') for a in annotations]
    if ids != expected_ids:
        missing = sorted(set(expected_ids) - set(ids))
        extra = sorted(set(ids) - set(expected_ids))
        errors.append(f'record order/coverage mismatch; missing={missing[:10]} extra={extra[:10]}')
    if len(ids) != len(set(ids)):
        errors.append('duplicate record_id values')

    for i, a in enumerate(annotations, 1):
        rid = a.get('record_id', f'line-{i}')
        for e in validator.iter_errors(a):
            errors.append(f'{rid}: schema: {e.message}')

        types = a.get('ambiguity_types', [])
        count = a.get('compound_ambiguity_count')
        present = a.get('ambiguity_present')
        compound = a.get('compound_ambiguity')
        primary = a.get('primary_ambiguity_type')
        validity = a.get('record_validity')
        if count != len(types):
            errors.append(f'{rid}: compound_ambiguity_count must equal len(ambiguity_types)')
        if present != (len(types) > 0):
            errors.append(f'{rid}: ambiguity_present inconsistent with ambiguity_types')
        if compound != (len(types) >= 2):
            errors.append(f'{rid}: compound_ambiguity inconsistent with ambiguity_types')
        if types and primary not in types:
            errors.append(f'{rid}: nonempty ambiguity_types requires primary_ambiguity_type in the set')
        if not types and primary is not None:
            errors.append(f'{rid}: empty ambiguity_types requires primary_ambiguity_type=null')
        if validity == 'valid' and len(types) < 2:
            errors.append(f'{rid}: a valid benchmark record must contain at least two defensible ambiguity types')

        route = a.get('recommended_strategy')
        terminal = a.get('terminal_strategy')
        seq = a.get('strategy_sequence', [])
        outcome = a.get('canonical_outcome', {})
        kind = outcome.get('terminal_kind')
        expected_kind = {
            'execute': 'executable_interpretation',
            'clarify': 'clarification',
            'face_preserving_rejection': 'rejection'
        }.get(terminal)
        if kind != expected_kind:
            errors.append(f'{rid}: terminal_kind does not match terminal_strategy')
        if not seq or seq[-1] != terminal:
            errors.append(f'{rid}: strategy_sequence must end in terminal_strategy')
        if any(step in TERMINALS for step in seq[:-1]):
            errors.append(f'{rid}: terminal step appears before the end of strategy_sequence')

        if terminal == 'clarify':
            question = outcome.get('clarification_question')
            if isinstance(question, str) and question.count('?') != 1:
                errors.append(f'{rid}: clarification_question must contain exactly one question mark')
            unresolved = outcome.get('unresolved_slot')
            candidates = unresolved.get('candidate_values') if isinstance(unresolved, dict) else None
            if not isinstance(candidates, list) or len(candidates) != 2:
                errors.append(f'{rid}: a clarification must provide exactly two complete candidate values for one slot')

        if route == 'execute' and not (terminal == 'execute' and seq == ['execute']):
            errors.append(f'{rid}: execute route must have sequence [execute]')
        elif route == 'silently_resolve' and not (terminal == 'execute' and seq == ['silently_resolve', 'execute']):
            errors.append(f'{rid}: silently_resolve route must have sequence [silently_resolve, execute]')
        elif route == 'clarify' and not (terminal == 'clarify' and seq == ['clarify']):
            errors.append(f'{rid}: clarify route must have sequence [clarify]')
        elif route == 'face_preserving_rejection' and not (
            terminal == 'face_preserving_rejection' and seq == ['face_preserving_rejection']
        ):
            errors.append(f'{rid}: rejection route must have sequence [face_preserving_rejection]')
        elif route == 'multi_step' and len(seq) < 2:
            errors.append(f'{rid}: multi_step requires at least one preterminal step and one terminal step')

        status = a.get('capability_status')
        block = outcome.get('blocking_constraint')
        risk_factors = a.get('risk_factors', [])
        # Capability is independently grounded; do not require route→capability mappings.
        if terminal == 'face_preserving_rejection' and isinstance(block, dict):
            factor = block.get('factor')
            if factor not in risk_factors:
                errors.append(f'{rid}: blocking_constraint.factor must occur in risk_factors')
            expected_status = REJECTION_STATUS.get(factor)
            if expected_status and status != expected_status:
                errors.append(f'{rid}: blocking factor {factor} requires capability_status={expected_status}')
        elif terminal in {'execute', 'clarify'} and status in {'incapable', 'unauthorized', 'unsafe'}:
            # Soft warning-as-error: execute/clarify terminals should not claim a hard capability block
            # unless the record is intentionally inconsistent (record_validity handles that separately).
            if validity == 'valid':
                errors.append(
                    f'{rid}: valid {terminal} terminal is inconsistent with capability_status={status}'
                )

        record = dataset_by_id.get(rid)
        if record:
            evidence = a.get('evidence', [])
            fields_seen = set()
            for j, item in enumerate(evidence):
                field = item.get('field')
                text = item.get('evidence_text')
                fields_seen.add(field)
                if isinstance(text, str) and text not in evidence_source(record, field):
                    errors.append(f'{rid}: evidence[{j}] is not an exact substring of input field {field}')
            if 'command' not in fields_seen:
                errors.append(f'{rid}: evidence must include the command')
            if not fields_seen.intersection({'dialogue_history', 'scene_context', 'capability_context'}):
                errors.append(f'{rid}: evidence must include at least one contextual field')

    if errors:
        for e in errors[:250]:
            fail(e)
        if len(errors) > 250:
            fail(f'... {len(errors)-250} additional errors')
        return 1
    print(f'PASS: {len(annotations)} annotations satisfy the v7 schema and one-path contract')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
