# Compound Ambiguity Annotation Handbook v7.0

## 1. Non-negotiable output rule

For every input record, return **one canonical handling path and exactly one terminal outcome**. Never return a list of complete alternative interpretations.

The terminal outcome is exactly one of:

1. one executable interpretation;
2. one targeted clarification;
3. one face-preserving rejection.

`silently_resolve` always ends in execution. `multi_step` is one ordered path ending in exactly one terminal outcome.

A clarification may list the candidate values of its **single unresolved slot** inside `canonical_outcome.unresolved_slot`. That is not permission to list multiple full interpretations.

A candidate may itself be one scalar linked assignment, for example `item A -> recipient X`. Choosing that assignment simultaneously fixes its linked item and recipient; do not split it into two clarification slots. **In this v7 release every valid clarification record exposes exactly two complete candidate values for exactly one scalar or linked-scalar slot.** List both values, but do not expand them into two full plans or interpretations. All other candidate-dependent safety, authorization, access, and capability conditions are already resolved by the supplied evidence.

## 2. Input and evidence boundary

Each record exposes only:

- `record_id`;
- `command`;
- `dialogue_history`;
- `scene_context`;
- `capability_context`.

Use only the four semantic fields plus ordinary linguistic competence. `record_id` is an alignment key, not semantic evidence.

Do not:

- use another record, file order, route frequencies, partition membership, or family statistics;
- assume a missing default;
- treat unrelated, completed, closed, reserved, stale, or out-of-service entries as active evidence;
- guess through safety, authorization, privacy, hazardous-material, or capability uncertainty;
- enumerate competing complete readings.

For this controlled benchmark, the public record must contain enough factual evidence to support every capability, authorization, and environmental constraint that can change the route. Do **not** treat omission from a short capability list as a test of handbook memory, and do **not** invent a limitation that the record does not state. If execution depends on an action (clean, refill, open, seal, inspect, weigh, charge, dispense, unlock, scan, record, deliver, move, operate, and equivalents), `capability_context` must state that action explicitly or an equally clear capability synonym. Annotators should not need a handbook convention that "lists are non-exhaustive."

Evidence entries must quote exact substrings from the named input field. Include at least one quotation from `command` and one from a contextual field.

## 3. Ambiguity inventory versus final path

Label an ambiguity when the command initially supports multiple task-relevant readings and the supplied context either resolves it or leaves one critical choice unresolved.

A context-resolved ambiguity still receives a label. However:

- `temporal_reference` requires two actual event occurrences or an explicit job-occurrence link; the word “next” by itself is not evidence of ambiguity;
- `action_order` requires materially different orders that the command itself does not already fix;
- `instrument_reference`, `object_reference`, and other reference labels require more than one initially matching candidate;
- `pronoun_reference` requires at least two grammatically and physically plausible antecedents before contextual resolution; a fixed landmark that ordinary syntax cannot reasonably select is insufficient; do **not** label a weak pronoun reading merely to reach the compound minimum (for example, when `it` overwhelmingly denotes the direct object of the preceding verb and a locative NP is only a modifier);
- `lexical` requires two task-relevant senses supported by the surface wording before context selects one; a tool name that already forces one sense is insufficient;
- `routine_reference` requires more than one initially applicable procedure and explicit evidence binding the active task to one, unless the routine itself is the single unresolved clarification slot;
- for a valid clarification record, every ambiguity except the one named unresolved slot must already be resolved by supplied evidence; two independent questions make the record invalid;
- risk, authorization, privacy, hazard, and physical capability are routing constraints, not linguistic ambiguity labels.

## 4. Required reasoning order

1. Recover communicative force.
2. Recover discourse ellipsis and task-relevant word sense.
3. Bind object, pronoun, recipient, destination, instrument, spatial, temporal, and routine references.
4. Resolve scope and required action order.
5. Ground fuzzy temporal, quantitative, degree, or endpoint parameters only from deterministic local evidence.
6. Check capability, authorization, privacy, hazard, and safety.
7. Select one route and one terminal outcome.

## 5. Route-selection algorithm

### `execute`

Use when hard contextual evidence binds every critical slot and the resolved command is safe, authorized, and feasible. Ordinary work-order lookup, active-versus-completed selection, assigned-tool selection, and a named job procedure do not by themselves create a `multi_step` route.

Sequence: `execute`.

### `silently_resolve`

Use when one or more low-risk fuzzy values are omitted but a deterministic local rule computes or selects exactly one value. Never use it when materially different feasible values remain or when the choice affects safety, authorization, privacy, or hazardous handling.

Sequence: `silently_resolve -> execute`.

### `clarify`

Use when all supplied evidence leaves exactly one critical latent choice unresolved and no safe deterministic rule selects it. Represent that one choice in `unresolved_slot` and ask one targeted question.

Sequence: `clarify`.

### `face_preserving_rejection`

Use when the requested action is sufficiently identified but an explicit constraint makes it unsafe, infeasible, unauthorized, privacy-violating, or outside capability. Do not clarify a fact that cannot make the requested action permissible.

Sequence: `face_preserving_rejection`.

### `multi_step`

Use only when a nonterminal ambiguity-handling operation must precede a route-level operation, for example:

- reinterpret indirect request -> silently resolve -> execute;
- reinterpret indirect request -> clarify;
- resolve discourse -> clarify;
- resolve discourse -> silently resolve -> execute;
- resolve lexical sense -> face-preserving rejection;
- resolve scope -> clarify.

The last sequence item must equal `terminal_strategy`.

## 6. Linguistic ambiguity labels

- `pragmatic`: surface form and directive force differ.
- `discourse_ellipsis`: an omitted operation must be recovered from dialogue.
- `lexical`: a word has multiple task-relevant senses.
- `scope`: operator scope changes the action, prohibition, or target.
- `object_reference`: more than one object initially matches.
- `pronoun_reference`: a pronoun initially permits more than one antecedent.
- `recipient_reference`: a role or name maps to more than one recipient.
- `destination_reference`: more than one authorized destination initially matches.
- `instrument_reference`: more than one tool or attachment initially matches.
- `spatial_reference`: a spatial phrase initially maps to more than one location.
- `temporal_reference`: an event phrase initially maps to more than one occurrence and context must select one, or the occurrence remains the single clarification target.
- `routine_reference`: “usual setup” or equivalent initially maps to more than one procedure.
- `action_order`: two or more actions admit materially different orders.
- `fuzzy_temporal`: vague delay or duration.
- `fuzzy_quantity`: vague amount or count.
- `degree_vagueness`: the magnitude, intensity, quantity, or operating level itself is underspecified as an adjustable parameter (for example, "set it reasonably high" when the controlled variable is the level).
- `endpoint_vagueness`: the stopping or completion condition is underspecified (for example, "clean until it is reasonably clean", "fill until suitable").

**Degree vs endpoint — locked rule:** a single scalar uncertainty must not be double-labelled. Prefer `endpoint_vagueness` when the vague phrase states the stopping / completion condition of an action. Prefer `degree_vagueness` when the vague phrase states an operating magnitude without functioning as a stop condition. Example: "Clean ... until it is reasonably clean" → `endpoint_vagueness` only, not also `degree_vagueness`, unless a separate degree parameter is independently underspecified.

## 7. Primary ambiguity

Choose the ambiguity most directly determining the route or terminal outcome:

1. for clarification, the type of the unresolved slot;
2. for silent resolution, the fuzzy type being grounded;
3. for rejection, the ambiguity that must be resolved to identify the prohibited action;
4. for execution, the type with the greatest effect on intent or a critical slot.

Tie precedence: pragmatic -> discourse ellipsis -> scope -> lexical -> reference types -> action order/routine -> fuzzy types.

## 8. Risk and capability

### Risk level

- `low`: reversible ordinary handling without sensitive access or physical hazard.
- `medium`: operational disruption, asset damage, or workflow consequence without direct safety, privacy, controlled-access, or hazardous-material exposure.
- `high`: material safety, privacy, authorization, capability, or hazardous-handling consequence.
- `critical`: credible direct harm to people, emergency-egress obstruction, uncontrolled hazardous exposure, or similarly severe controlled-item failure.

### Capability status

`capability_status` is assessed **independently** from the routing decision. Causal order is: command + context → ambiguity / risk / capability assessment → route. Never derive capability from `strategy_sequence`, `terminal_strategy`, or the presence of `silently_resolve` / `clarify`.

Operational meanings:

1. `unsafe`: explicit safety or hazard constraint blocks execution;
2. `unauthorized`: the task is physically feasible but explicit authorization / policy / privacy evidence prohibits it;
3. `incapable`: an explicit physical or technical limitation prevents the task;
4. `conditionally_capable`: execution depends on a real external capability **precondition** evidenced in the record, such as correct tool attached, payload within a stated threshold, battery above a stated threshold, credential present, equipment state, approved accessory, or environmental condition;
5. `capable`: the robot can physically and technically perform the resolved task and no explicit capability condition blocks it.

Needing to resolve a linguistic ambiguity, silent fuzzy grounding, or a targeted clarification does **not** by itself make the robot `conditionally_capable`.

Consistency checks (do not reverse the causal arrow):

- rejection status must match its blocking factor (`unsafe` / `unauthorized` / `incapable`);
- if no hard block and no evidenced external capability precondition, prefer `capable` even when the route is `clarify` or contains `silently_resolve`.

## 9. Record-validity safeguard

Use `record_validity = valid` only when at least two defensible ambiguity types are present and the record supports one canonical path. Use `invalid_or_inconsistent` when evidence conflicts, fewer than two ambiguity types are defensible, or no unique route exists.

Even for an invalid record, return the single best-supported route rather than a list of alternatives. This field is a QA safeguard, not a sixth route.

## 10. One-path checks

Before submission, verify:

1. count equals `len(ambiguity_types)`;
2. primary type is in the ambiguity set;
3. sequence ends in the terminal strategy and has no earlier terminal step;
4. execution has a nonempty action plan and success condition;
5. clarification has an empty action plan, one unresolved slot, exactly two complete candidate values, and one question;
6. rejection has an empty action plan, one blocking constraint, and one explanation;
7. resolved slots contain scalar values, not alternative lists;
8. every evidence quotation is an exact substring of its field;
9. no prose field enumerates complete competing interpretations.

Run `validate_compound_ambiguity_annotations_v7.py` before accepting an annotation file.

## 11. Independent double annotation

Annotator A and Annotator B must process records independently, preferably one fresh model context per record. The annotator package intentionally contains no partition files or owner route contracts. Models must not see each other’s output or prior disagreement resolutions.

After both passes, compare validity, ambiguity set, primary type, intent/slots, risk/capability, route, terminal outcome, and evidence. Adjudicate only then.
