# Compound Ambiguity v7 — Final QA Report (auditor repair)

Date: 2026-08-07  
Scope: `data/compound 1000/` (1000 records) + `annotations/manual_kappa_v7/` (120-record gold sample)

## Automated tests

Command:

```text
python -m pytest tests/test_compound_ambiguity_v7_qa.py -q
```

Result: **21 passed**.

Coverage includes: human-gate lifecycle, capability–route independence, no gated final export, clarify/execute/rejection consistency, schema/IDs/splits, owner-metadata exclusion, handbook contracts, and regressions for CA-0394 / CA-0739 / CA-0841 / CA-0907.

## Gold sample status

| Metric | Count |
| --- | ---: |
| Subset records | 120 |
| `final_gold` lifecycle | 120 |
| `human_review_required` | 0 |
| Final export rows (`subset_final_gold_eval.jsonl`) | 120 |
| Open human gates | 0 |

## Dataset repairs

| Family | Records changed | Change |
| --- | ---: | --- |
| `clean_until_reasonably_clean` | 16 | Appended explicit exterior-cleaning capability |
| `open_beside_return_it` | 20 | Dual-check scene + deterministic job link |
| **Total inputs touched** | **36** | Partition membership unchanged |

## Systemic rule changes

1. **Capability–route independence** — removed `silently_resolve → conditionally_capable` auto-rule from merge scripts / GOLD rules / handbook / validator.
2. **Capability evidence** — omission from a short list is no longer a handbook “memory test”; public records must state action-critical capabilities.
3. **Degree vs endpoint** — single scalar stop-condition (“until reasonably clean”) is `endpoint_vagueness` only.
4. **Weak pronoun ban** — do not add `pronoun_reference` solely to hit compound ≥2.
5. **Gold lifecycle** — `gold_lifecycle ∈ {auto_agreed, adjudicated_provisional, human_review_required, final_gold}`; human-gated rows cannot enter final export.

## Four known cases (before → after)

| ID | Terminal | Capability | Ambiguity | Gate |
| --- | --- | --- | --- | --- |
| CA-0394 | execute → **clarify** | capable → **capable** | unchanged (object/pragmatic/temporal) | cleared |
| CA-0739 | execute (prov.) | conditionally_capable → **capable** | dropped degree; keep endpoint/object/temporal | cleared |
| CA-0907 | execute (prov.) | conditionally_capable → **capable** | endpoint/object/temporal | cleared |
| CA-0841 | rejection | unauthorized | pronoun+spatial → **spatial+temporal** | cleared |

## Remaining known limitations

1. **Other capability omissions** (refill / seal / inspect / deliver / record) remain partially present outside the clean/open families. Heuristic audit flagged many candidates; only execution-critical clean omissions and open-family temporal repairs were applied family-wide. A second owned-route pass is recommended before claiming full 1000-record capability completeness.
2. **No owner route contracts** in the annotator package — full one-path verification for all 1000 records still requires complete dual annotations, not only input QA.
3. **Annotator A/B files** were not rewritten; gold reflects auditor overrides where conventions were defective. κ metrics computed against A/B remain historically valid for those files.
4. Legacy `subset_120_eval.jsonl` still contains all valid rows (now all final). Prefer `subset_final_gold_eval.jsonl` for export-safe eval.

## Freeze readiness

- **120-record gold sample:** safe to freeze for eval/export under current automated checks.
- **Full 1000-record dataset:** valid for the research objective after family repairs for the audited failure modes; residual capability-list completeness outside clean/open families is a known limitation (see above).
