# Manual Kappa v7 — Stratified Cohen’s κ

Annotator A = Grok for all records. Annotator B split by mid-study cost switch.
Roster: [`annotator_b_model_roster.json`](annotator_b_model_roster.json).

| Stratum | n | terminal κ / raw | types mean κ | types Jaccard | primary κ / raw | recommended κ / raw | risk κ / raw | capability κ / raw |
| --- | ---: | --- | ---: | ---: | --- | --- | --- | --- |
| Grok × Claude | 70 | 0.9723 / 0.9857 | 0.9143 | 0.9000 | 0.6706 / 0.7000 | 0.4967 / 0.6857 | 0.6328 / 0.8000 | 0.8555 / 0.9143 |
| Grok × GLM | 50 | 0.9286 / 0.9600 | 0.8505 | 0.8620 | 0.8209 / 0.8400 | 0.5344 / 0.6400 | 0.5267 / 0.7800 | 0.8029 / 0.8800 |
| All (pooled) | 120 | 0.9533 / 0.9750 | 0.8920 | 0.8842 | 0.7332 / 0.7583 | 0.5109 / 0.6667 | 0.5937 / 0.7917 | 0.8332 / 0.9000 |

## Disagreement counts

| Stratum | terminal disagreements | ambiguity_types set disagreements |
| --- | ---: | ---: |
| Grok × Claude | 1 | 14 |
| Grok × GLM | 2 | 16 |
| All (pooled) | 3 | 30 |

## Notes

- `record_validity` near-ceiling agreement yields unstable chance-corrected κ; prefer raw agreement.
- Core gold-v1 uses `terminal_strategy` + `ambiguity_types` (not recommended/primary/risk).
- CA-0440 Annotator B = Claude Opus (counted in Claude-era).
