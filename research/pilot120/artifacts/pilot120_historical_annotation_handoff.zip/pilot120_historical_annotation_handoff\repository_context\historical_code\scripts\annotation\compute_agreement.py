"""Compute deterministic agreement summaries from paired annotations."""
from __future__ import annotations
import argparse, json
from pathlib import Path
def read(path):
    return {x["record_id"]:x for x in map(json.loads,Path(path).read_text(encoding="utf-8").splitlines()) if x.get("record_id")}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--a",required=True); ap.add_argument("--b",required=True); ap.add_argument("--output",required=True); args=ap.parse_args(); a=read(args.a); b=read(args.b); shared=sorted(set(a)&set(b)); fields=["ambiguity_present","ambiguity_types","compound_ambiguity","risk_level","capability_status","recommended_strategy"]
    summary={"record_count_a":len(a),"record_count_b":len(b),"shared_count":len(shared),"fields":{},"disagreement_record_ids":[]}
    for f in fields:
        same=sum(a[i].get(f)==b[i].get(f) for i in shared); summary["fields"][f]={"raw_percent_agreement":same/len(shared) if shared else None,"exact_matches":same}
    summary["disagreement_record_ids"]=[i for i in shared if any(a[i].get(f)!=b[i].get(f) for f in fields)]; Path(args.output).write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8")
if __name__=="__main__": main()
