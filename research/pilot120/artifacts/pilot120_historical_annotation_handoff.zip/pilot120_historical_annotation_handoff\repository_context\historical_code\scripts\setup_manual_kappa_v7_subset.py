#!/usr/bin/env python3
"""Build a stratified 120-record blind double-annotation subset for Cohen's Kappa."""
from __future__ import annotations

import json
import random
import re
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "data" / "compound 1000" / "compound_ambiguity_unique_resolution_1000_v7.json"
OUT = ROOT / "annotations" / "manual_kappa_v7"
SEED = 20260807


def main() -> int:
    with open(SRC, encoding="utf-8") as f:
        data = json.load(f)

    random.seed(SEED)

    heur = {
        "has_dialogue": lambda r: 1 if (r.get("dialogue_history") or []) else 0,
        "pragmatic_cue": lambda r: 1
        if re.search(
            r"\b(could you|would you|can you|might want|suggest|wonder)\b",
            r["command"],
            re.I,
        )
        else 0,
        "recipient_cue": lambda r: 1
        if re.search(
            r"\b(to |for )(the )?(guest|patient|nurse|manager|tech|resident|staff|clerk)\b",
            r["command"] + " " + r.get("scene_context", ""),
            re.I,
        )
        else 0,
        "routine_cue": lambda r: 1
        if re.search(
            r"\b(usual|standard|typical|routine|as usual)\b",
            r["command"] + " " + r.get("scene_context", ""),
            re.I,
        )
        else 0,
        "fuzzy_qty_cue": lambda r: 1
        if re.search(r"\b(some|a few|several|couple|enough)\b", r["command"], re.I)
        else 0,
        "endpoint_cue": lambda r: 1
        if re.search(r"\b(until|once it|when it|as soon as)\b", r["command"], re.I)
        else 0,
        "order_cue": lambda r: 1
        if re.search(r"\b(then|first|after that|prioritize)\b", r["command"], re.I)
        else 0,
        "fuzzy_temp_cue": lambda r: 1
        if re.search(
            r"\b(soon|later|a bit|while|moment|shortly)\b", r["command"], re.I
        )
        else 0,
    }

    # Prefer rare surface strata so almost every ambiguity class can appear.
    priority = [
        "pragmatic_cue",
        "recipient_cue",
        "fuzzy_qty_cue",
        "endpoint_cue",
        "has_dialogue",
        "routine_cue",
        "order_cue",
        "fuzzy_temp_cue",
    ]

    buckets: dict[str, list] = defaultdict(list)
    for r in data:
        flags = {k: fn(r) for k, fn in heur.items()}
        assigned = "baseline"
        for p in priority:
            if flags[p]:
                assigned = p
                break
        buckets[assigned].append(r)

    targets = {
        "pragmatic_cue": 12,
        "recipient_cue": 12,
        "fuzzy_qty_cue": 12,
        "endpoint_cue": 12,
        "has_dialogue": 20,
        "routine_cue": 14,
        "order_cue": 14,
        "fuzzy_temp_cue": 12,
        "baseline": 12,
    }
    assert sum(targets.values()) == 120

    selected = []
    used: set[str] = set()
    for b, n in targets.items():
        pool = [r for r in buckets.get(b, []) if r["record_id"] not in used]
        random.shuffle(pool)
        take = pool[:n]
        if len(take) < n:
            rest = [r for r in data if r["record_id"] not in used and r not in take]
            random.shuffle(rest)
            take = take + rest[: n - len(take)]
        for r in take:
            used.add(r["record_id"])
            selected.append(
                {
                    "record_id": r["record_id"],
                    "stratum": b,
                    **{k: heur[k](r) for k in heur},
                }
            )

    id_to_rec = {r["record_id"]: r for r in data}
    subset_records = []
    for s in selected:
        r = id_to_rec[s["record_id"]]
        subset_records.append(
            {
                "record_id": r["record_id"],
                "command": r["command"],
                "dialogue_history": r["dialogue_history"],
                "scene_context": r["scene_context"],
                "capability_context": r["capability_context"],
            }
        )

    subset_records.sort(key=lambda x: x["record_id"])
    selected.sort(key=lambda x: x["record_id"])

    for sub in (
        OUT,
        OUT / "subset",
        OUT / "annotator_a_grok",
        OUT / "annotator_b_claude",
        OUT / "inputs",
        OUT / "logs",
        OUT / "briefs",
    ):
        sub.mkdir(parents=True, exist_ok=True)

    manifest = {
        "seed": SEED,
        "n": len(subset_records),
        "targets": targets,
        "realized_strata": {
            k: sum(1 for s in selected if s["stratum"] == k) for k in targets
        },
        "record_ids": [r["record_id"] for r in subset_records],
        "records_meta": selected,
        "annotator_a": {
            "id": "A",
            "model": "cursor-grok-4.5-high-fast",
            "label": "Grok",
            "output_dir": "annotations/manual_kappa_v7/annotator_a_grok",
        },
        "annotator_b": {
            "id": "B",
            "model": "claude-4.6-sonnet-medium-thinking",
            "label": "Claude",
            "output_dir": "annotations/manual_kappa_v7/annotator_b_claude",
        },
        "isolation": "one_fresh_subagent_per_record_per_annotator",
        "taxonomy": "compound_ambiguity_v7_handbook",
        "generator_model_excluded": "GPT Sol / any generator labels must not be used",
        "kappa_fields": [
            "primary_ambiguity_type",
            "ambiguity_types_per_label",
            "terminal_strategy",
            "recommended_strategy",
            "risk_level",
            "capability_status",
            "record_validity",
        ],
    }

    (OUT / "subset_manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8"
    )
    (OUT / "subset_120_inputs.json").write_text(
        json.dumps(subset_records, indent=2), encoding="utf-8"
    )
    for r in subset_records:
        (OUT / "inputs" / f"{r['record_id']}.json").write_text(
            json.dumps(r, indent=2), encoding="utf-8"
        )

    print(
        json.dumps(
            {
                "status": "ok",
                "n": len(subset_records),
                "strata": manifest["realized_strata"],
                "out": str(OUT),
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
