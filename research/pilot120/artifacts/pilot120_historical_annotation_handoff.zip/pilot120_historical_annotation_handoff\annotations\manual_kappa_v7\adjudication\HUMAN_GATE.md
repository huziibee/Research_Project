# Human gate — gold-v1

Status after 2026-08-07 auditor QA repair:

- Previous deferred IDs `CA-0394`, `CA-0739`, `CA-0841`, `CA-0907` were repaired at **source evidence** (and/or gold labels) under an explicit human-auditor decision.
- All four now have `human_gate_required=false` and `gold_lifecycle=final_gold`.
- Final export: `eval/subset_final_gold_eval.jsonl` (must never contain human-gated rows).

## Auditor resolutions (summary)

| ID | Resolution |
| --- | --- |
| CA-0394 | Keep singular command; `terminal_strategy=clarify` (one unresolved object slot). |
| CA-0739 / CA-0907 | Add explicit exterior-cleaning capability; execute; `endpoint_vagueness` only; `capability_status=capable`. |
| CA-0841 | Dual-check scene repair → `spatial_reference` + `temporal_reference`; drop weak `pronoun_reference`; keep unauthorized rejection. |

## Open gates

None.
