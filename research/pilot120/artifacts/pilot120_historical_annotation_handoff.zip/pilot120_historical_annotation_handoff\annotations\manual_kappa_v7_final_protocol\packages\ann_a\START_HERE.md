# START HERE — Steven James (ANN-A)

You are the official **ANN-A** annotator for **Pilot-120 final-protocol** reannotation.

## What to annotate

Exactly **120** records under `records/` in the listed order (`record_order_index`).

## Blindness rules

- Use only: this START_HERE, `briefs/`, and **one** `records/` file at a time.
- Do **NOT** open:
  - `annotations/manual_kappa_v7/` (pilot ANN-A/ANN-B, gold, adjudication, kappa)
  - `annotations/private_owner_qa_v7/`
  - the other annotator package
  - any historical kappa / gold / agreement numbers
- Do **NOT** discuss labels with the other annotator before both submissions are complete.

## How to submit

1. For each record, write a complete v7 annotation JSON (see `briefs/output_schema_v7.json`).
2. Save as `CA-XXXX.json` (use the real record_id).
3. Deliver the folder of 120 JSON files for import:

```text
python -m ambiguity_manager.evaluation.pilot_120_cli import-annotations \
  --role ANN-A \
  --from-dir <YOUR_SUBMISSION_DIR>
```

Validate one file:

```text
python -m ambiguity_manager.evaluation.pilot_120_cli validate-annotation \
  --annotation <CA-XXXX.json> \
  --input annotations/manual_kappa_v7_final_protocol/inputs/CA-XXXX.json
```

## Role identity

- Official ANN-A: Steven James
- Official ANN-B: Benjamin Rosman
- AUTHOR-01 must not act as ANN-A or ANN-B on this set
