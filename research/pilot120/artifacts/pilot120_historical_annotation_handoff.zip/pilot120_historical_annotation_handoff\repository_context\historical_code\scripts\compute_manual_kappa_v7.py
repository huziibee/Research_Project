#!/usr/bin/env python3
"""Compute Cohen's Kappa suite for dual blind annotations (v7), including B-era strata."""
from __future__ import annotations

import json
import math
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "annotations" / "manual_kappa_v7"
A_DIR = OUT / "annotator_a_grok"
B_DIR = OUT / "annotator_b_claude"
MANIFEST = OUT / "subset_manifest.json"
ROSTER = OUT / "annotator_b_model_roster.json"

AMBIGUITY_TYPES = [
    "pragmatic",
    "discourse_ellipsis",
    "lexical",
    "scope",
    "object_reference",
    "pronoun_reference",
    "recipient_reference",
    "destination_reference",
    "instrument_reference",
    "spatial_reference",
    "temporal_reference",
    "routine_reference",
    "action_order",
    "fuzzy_temporal",
    "fuzzy_quantity",
    "degree_vagueness",
    "endpoint_vagueness",
]

EXCLUSIVE_FIELDS = [
    "record_validity",
    "primary_ambiguity_type",
    "recommended_strategy",
    "terminal_strategy",
    "risk_level",
    "capability_status",
]


def cohen_kappa(y1: list, y2: list) -> float | None:
    if len(y1) != len(y2) or not y1:
        return None
    n = len(y1)
    labels = sorted(set(y1) | set(y2))
    if len(labels) == 1:
        return 1.0 if y1 == y2 else 0.0
    agree = sum(a == b for a, b in zip(y1, y2)) / n
    c1 = Counter(y1)
    c2 = Counter(y2)
    chance = sum((c1[l] / n) * (c2[l] / n) for l in labels)
    if math.isclose(1.0 - chance, 0.0):
        return 1.0 if math.isclose(agree, 1.0) else 0.0
    return (agree - chance) / (1.0 - chance)


def load_pair(record_id: str):
    a_path = A_DIR / f"{record_id}.json"
    b_path = B_DIR / f"{record_id}.json"
    if not a_path.exists() or not b_path.exists():
        return None
    a = json.loads(a_path.read_text(encoding="utf-8-sig"))
    b = json.loads(b_path.read_text(encoding="utf-8-sig"))
    return a, b


def compute_metrics(pairs: list[tuple[str, dict, dict]]) -> dict:
    metrics: dict = {}
    if not pairs:
        return metrics

    for field in EXCLUSIVE_FIELDS:
        y1 = [str(a.get(field)) for _, a, _ in pairs]
        y2 = [str(b.get(field)) for _, _, b in pairs]
        raw = sum(x == y for x, y in zip(y1, y2)) / len(pairs)
        metrics[field] = {
            "cohen_kappa": cohen_kappa(y1, y2),
            "raw_agreement": raw,
        }

    per_label = {}
    kappas = []
    for lab in AMBIGUITY_TYPES:
        y1 = [1 if lab in (a.get("ambiguity_types") or []) else 0 for _, a, _ in pairs]
        y2 = [1 if lab in (b.get("ambiguity_types") or []) else 0 for _, _, b in pairs]
        k = cohen_kappa(y1, y2)
        raw = sum(x == y for x, y in zip(y1, y2)) / len(pairs)
        per_label[lab] = {
            "cohen_kappa": k,
            "raw_agreement": raw,
            "a_positive": sum(y1),
            "b_positive": sum(y2),
        }
        if k is not None and (sum(y1) + sum(y2)) > 0:
            kappas.append(k)
    metrics["ambiguity_types_per_label"] = per_label
    metrics["ambiguity_types_mean_kappa"] = (
        sum(kappas) / len(kappas) if kappas else None
    )

    jaccards = []
    n_type_disagree = 0
    n_terminal_disagree = 0
    for _, a, b in pairs:
        sa = set(a.get("ambiguity_types") or [])
        sb = set(b.get("ambiguity_types") or [])
        if sa != sb:
            n_type_disagree += 1
        if a.get("terminal_strategy") != b.get("terminal_strategy"):
            n_terminal_disagree += 1
        if not sa and not sb:
            jaccards.append(1.0)
        else:
            jaccards.append(len(sa & sb) / len(sa | sb))
    metrics["ambiguity_types_mean_jaccard"] = sum(jaccards) / len(jaccards)
    metrics["n_terminal_disagreement"] = n_terminal_disagree
    metrics["n_ambiguity_types_set_disagreement"] = n_type_disagree
    return metrics


def build_report(
    ids: list[str],
    *,
    stratum: str,
    annotator_a: dict,
    annotator_b: dict,
) -> dict:
    pairs = []
    missing = []
    for rid in ids:
        p = load_pair(rid)
        if p is None:
            missing.append(rid)
        else:
            pairs.append((rid, p[0], p[1]))

    report = {
        "stratum": stratum,
        "n_subset": len(ids),
        "n_paired": len(pairs),
        "n_missing": len(missing),
        "missing_ids": missing,
        "annotator_a": annotator_a,
        "annotator_b": annotator_b,
        "metrics": compute_metrics(pairs),
    }
    return report


def _fmt_k(metrics: dict, field: str) -> str:
    m = metrics.get(field) or {}
    k = m.get("cohen_kappa")
    raw = m.get("raw_agreement")
    if k is None:
        return "— / —"
    return f"{k:.4f} / {raw:.4f}"


def write_strata_markdown(all_r: dict, claude_r: dict, glm_r: dict) -> None:
    lines = [
        "# Manual Kappa v7 — Stratified Cohen’s κ",
        "",
        "Annotator A = Grok for all records. Annotator B split by mid-study cost switch.",
        "Roster: [`annotator_b_model_roster.json`](annotator_b_model_roster.json).",
        "",
        "| Stratum | n | terminal κ / raw | types mean κ | types Jaccard | primary κ / raw | recommended κ / raw | risk κ / raw | capability κ / raw |",
        "| --- | ---: | --- | ---: | ---: | --- | --- | --- | --- |",
    ]
    for label, r in [
        ("Grok × Claude", claude_r),
        ("Grok × GLM", glm_r),
        ("All (pooled)", all_r),
    ]:
        m = r["metrics"]
        lines.append(
            "| {label} | {n} | {term} | {tk:.4f} | {tj:.4f} | {pri} | {rec} | {risk} | {cap} |".format(
                label=label,
                n=r["n_paired"],
                term=_fmt_k(m, "terminal_strategy"),
                tk=m.get("ambiguity_types_mean_kappa") or 0.0,
                tj=m.get("ambiguity_types_mean_jaccard") or 0.0,
                pri=_fmt_k(m, "primary_ambiguity_type"),
                rec=_fmt_k(m, "recommended_strategy"),
                risk=_fmt_k(m, "risk_level"),
                cap=_fmt_k(m, "capability_status"),
            )
        )
    lines.extend(
        [
            "",
            "## Disagreement counts",
            "",
            "| Stratum | terminal disagreements | ambiguity_types set disagreements |",
            "| --- | ---: | ---: |",
        ]
    )
    for label, r in [
        ("Grok × Claude", claude_r),
        ("Grok × GLM", glm_r),
        ("All (pooled)", all_r),
    ]:
        m = r["metrics"]
        lines.append(
            f"| {label} | {m.get('n_terminal_disagreement', 0)} | {m.get('n_ambiguity_types_set_disagreement', 0)} |"
        )
    lines.extend(
        [
            "",
            "## Notes",
            "",
            "- `record_validity` near-ceiling agreement yields unstable chance-corrected κ; prefer raw agreement.",
            "- Core gold-v1 uses `terminal_strategy` + `ambiguity_types` (not recommended/primary/risk).",
            "- CA-0440 Annotator B = Claude Opus (counted in Claude-era).",
            "",
        ]
    )
    (OUT / "KAPPA_STRATA.md").write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    roster = json.loads(ROSTER.read_text(encoding="utf-8"))
    ids = manifest["record_ids"]
    claude_ids = roster["annotator_b_by_era"]["claude_era"]["record_ids"]
    glm_ids = roster["annotator_b_by_era"]["glm_era"]["record_ids"]

    all_r = build_report(
        ids,
        stratum="all",
        annotator_a=manifest["annotator_a"],
        annotator_b={
            **manifest["annotator_b"],
            "note": "Pooled Claude-era + GLM-era B annotations in annotator_b_claude/",
        },
    )
    claude_r = build_report(
        claude_ids,
        stratum="claude_era",
        annotator_a=manifest["annotator_a"],
        annotator_b={
            "id": "B",
            "label": "Claude",
            "model": roster["annotator_b_by_era"]["claude_era"]["default_model"],
            "output_dir": "annotations/manual_kappa_v7/annotator_b_claude",
            "n": len(claude_ids),
        },
    )
    glm_r = build_report(
        glm_ids,
        stratum="glm_era",
        annotator_a=manifest["annotator_a"],
        annotator_b={
            "id": "B",
            "label": "GLM",
            "model": roster["annotator_b_by_era"]["glm_era"]["default_model"],
            "output_dir": "annotations/manual_kappa_v7/annotator_b_claude",
            "n": len(glm_ids),
        },
    )

    (OUT / "kappa_report.json").write_text(
        json.dumps(all_r, indent=2) + "\n", encoding="utf-8"
    )
    (OUT / "kappa_report_claude_era.json").write_text(
        json.dumps(claude_r, indent=2) + "\n", encoding="utf-8"
    )
    (OUT / "kappa_report_glm_era.json").write_text(
        json.dumps(glm_r, indent=2) + "\n", encoding="utf-8"
    )
    write_strata_markdown(all_r, claude_r, glm_r)

    summary = {
        "all": {
            "n": all_r["n_paired"],
            "terminal": all_r["metrics"].get("terminal_strategy"),
            "types_mean_kappa": all_r["metrics"].get("ambiguity_types_mean_kappa"),
        },
        "claude_era": {
            "n": claude_r["n_paired"],
            "terminal": claude_r["metrics"].get("terminal_strategy"),
            "types_mean_kappa": claude_r["metrics"].get("ambiguity_types_mean_kappa"),
        },
        "glm_era": {
            "n": glm_r["n_paired"],
            "terminal": glm_r["metrics"].get("terminal_strategy"),
            "types_mean_kappa": glm_r["metrics"].get("ambiguity_types_mean_kappa"),
        },
    }
    print(json.dumps(summary, indent=2))
    return 0 if all_r["n_missing"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
