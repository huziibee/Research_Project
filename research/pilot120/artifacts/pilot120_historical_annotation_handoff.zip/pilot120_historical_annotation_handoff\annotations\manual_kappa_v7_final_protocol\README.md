# Final-protocol reannotation (120)

This package supports **independent reannotation** of the 120-record evaluation subset under the **finalized** compound-ambiguity v7 protocol.

## Why this exists

Pilot double annotation (`annotations/manual_kappa_v7/`) exposed systematic defects in capability-status and ambiguity-label operationalization. After guideline calibration and selective input repairs, this package restarts annotation from a clean context.

## Do NOT use / do NOT open

- `annotations/manual_kappa_v7/annotator_a_grok/`
- `annotations/manual_kappa_v7/annotator_b_claude/`
- `annotations/manual_kappa_v7/gold/`
- `annotations/manual_kappa_v7/adjudication/`
- `annotations/private_owner_qa_v7/`
- any owner route / private QA contract

Pilot agreement metrics remain:
`pilot_annotation_agreement` (see `annotations/manual_kappa_v7/KAPPA_STRATA.md`).

New agreement metrics must be written to:
`final_protocol_annotation_agreement` (this tree).

## Layout

| Path | Role |
| --- | --- |
| `inputs/` | Clean public 120 inputs only |
| `briefs/` | Finalized handbook, schemas, annotator brief |
| `annotator_a/` | Fresh Annotator A outputs (empty at scaffold) |
| `annotator_b/` | Fresh Annotator B outputs (empty at scaffold) |
| `adjudication/` | Disagreement packets / decisions |
| `gold/` | Final-protocol gold (after adjudication) |
| `eval/` | Export-safe eval files |
| `packages/` | Blind ANN-A / ANN-B delivery zips (built by CLI) |
| `HUMAN_ANNOTATION_GATE.md` | Exact remaining human steps |
| `scripts/` | Validator + launch helpers |

## Isolation rules

Same as the pilot brief: one fresh context per `(annotator, record)`. Only brief + handbook + schema + **one** input file.

## Canonical repaired source (Pilot-120 v1)

Authoritative repaired public 120 (capability-context fixes applied):

- per-record inputs: `inputs/CA-*.json`
- deterministic JSONL: `data/annotations/pilot_120_v1/source_canonical.jsonl`
- provenance/hashes: `data/annotations/pilot_120_v1/SOURCE_PROVENANCE.json`
- status / freeze blockers: `data/annotations/pilot_120_v1/STATUS.json`

## Suggested launch commands

```text
# Hard preflight + status
python -m ambiguity_manager.evaluation.pilot_120_cli preflight
python -m ambiguity_manager.evaluation.pilot_120_cli status

# Build blind ANN-A / ANN-B packages (no historical labels)
python -m ambiguity_manager.evaluation.pilot_120_cli build-packages

# Validate a single annotation against schema + matching input
python -m ambiguity_manager.evaluation.pilot_120_cli validate-annotation \
  --annotation <CA-XXXX.json> \
  --input annotations/manual_kappa_v7_final_protocol/inputs/CA-XXXX.json

# Import completed official submissions (Steven James / Benjamin Rosman)
python -m ambiguity_manager.evaluation.pilot_120_cli import-annotations --role ANN-A --from-dir <STEVE_DIR>
python -m ambiguity_manager.evaluation.pilot_120_cli import-annotations --role ANN-B --from-dir <BEN_DIR>

# After both annotators finish, compute agreement INTO THIS TREE
python -m ambiguity_manager.evaluation.pilot_120_cli agreement

# ADJ-01 must be resolved explicitly (see adjudication/ADJ01_DECISION_REQUEST.md)
# then disagreement-only adjudication + gold + freeze:
python -m ambiguity_manager.evaluation.pilot_120_cli adjudication-queue
python -m ambiguity_manager.evaluation.pilot_120_cli assemble-gold
python -m ambiguity_manager.evaluation.pilot_120_cli freeze

# Evaluate predictions against frozen gold
python -m ambiguity_manager.evaluation.pilot_120_cli evaluate \
  --config configs/evaluation/pilot_120_v1.json \
  --predictions <PREDICTIONS.jsonl>
```

Human steps are also listed in `HUMAN_ANNOTATION_GATE.md`.

## Freeze distinction

- **1000 input benchmark freeze** — separate gate; currently blocked on remaining capability D records outside this subset.
- **120 gold evaluation set finalized** — only after this final-protocol double annotation + ADJ-01 resolution + adjudication completes.
- Do **not** claim `Pilot-120 v1: FINAL-PROTOCOL ANNOTATED, ADJUDICATED, FROZEN, HASHED, EVALUATION-ONLY` while `STATUS.json` has `"claim_allowed": false`.
