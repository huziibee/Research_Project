#!/usr/bin/env python3
"""Report dual-annotation progress for manual Kappa study."""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "annotations" / "manual_kappa_v7"
MANIFEST = OUT / "subset_manifest.json"
A = OUT / "annotator_a_grok"
B = OUT / "annotator_b_claude"


def main() -> int:
    ids = json.loads(MANIFEST.read_text(encoding="utf-8"))["record_ids"]
    done_a = {p.stem for p in A.glob("CA-*.json")}
    done_b = {p.stem for p in B.glob("CA-*.json")}
    paired = sorted(done_a & done_b)
    missing_a = [i for i in ids if i not in done_a]
    missing_b = [i for i in ids if i not in done_b]
    report = {
        "n": len(ids),
        "grok_done": len(done_a),
        "claude_done": len(done_b),
        "paired": len(paired),
        "missing_a_count": len(missing_a),
        "missing_b_count": len(missing_b),
        "next_unlaunched_hint": [i for i in ids if i not in done_a or i not in done_b][:20],
        "paired_ids_sample": paired[:20],
    }
    (OUT / "progress.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
