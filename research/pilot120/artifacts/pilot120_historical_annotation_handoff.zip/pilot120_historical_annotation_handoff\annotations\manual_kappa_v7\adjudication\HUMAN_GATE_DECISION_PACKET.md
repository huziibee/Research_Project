# Human gate — full context for decision

Fact-check files:
- Full 120 A+B+gold+decisions: `ALL_ANNOTATIONS_FACTCHECK.jsonl`
- These 4 cases only (pretty JSON): `HUMAN_GATE_CONTEXT.json`

## CA-0394 (claude_era)

### Command / scene

- **command:** Can the selected exam packet be delivered after a scheduled class handover?
- **dialogue_history:** ["lab demonstrator: Yes—treat that as a request to perform the delivery, not a capability question."]
- **scene_context:** Resource room in a classroom. Two exam packets are selected and pending, one for course coordinator and one for lab demonstrator. The current time is 12:23. The class handover is scheduled at 13:00 and again at 17:00. The active delivery batch links both pending selected items to the 13:00 occurrence. Each selected item is already paired with its named recipient. The command provides no assignment code or recipient name. Both pending assignments are pre-authorized handoffs within the robot's certified transport and access limits; either is executable once selected.
- **capability_context:** Classroom service robot can carry learning materials, scan inventory, clean approved items, and operate standard charging equipment.

### Dual annotations (core fields)

| Field | A (Grok) | B |
| --- | --- | --- |
| `record_validity` | `valid` | `valid` |
| `terminal_strategy` | `clarify` | `execute` |
| `capability_status` | `conditionally_capable` | `capable` |
| `recommended_strategy` | `multi_step` | `multi_step` |
| `primary_ambiguity_type` | `object_reference` | `pragmatic` |
| `risk_level` | `medium` | `low` |
| `ambiguity_types` | `['pragmatic', 'object_reference', 'temporal_reference']` | `['pragmatic', 'object_reference', 'temporal_reference']` |
| `strategy_sequence` | `['reinterpret_indirect_request', 'clarify']` | `['reinterpret_indirect_request', 'resolve_reference', 'execute']` |

### Canonical outcomes

**A:**
```json
{
  "terminal_kind": "clarification",
  "canonical_interpretation": "Indirect delivery request for a selected pending exam packet after the active 13:00 class handover; which of the two selected packets remains unresolved.",
  "action_plan": [],
  "unresolved_slot": {
    "slot_name": "selected_exam_packet",
    "candidate_values": [
      "exam packet for course coordinator -> course coordinator",
      "exam packet for lab demonstrator -> lab demonstrator"
    ],
    "reason_unresolved": "Two selected pending exam packets match, and the command gives neither assignment code nor recipient name."
  },
  "clarification_question": "Which selected exam packet should I deliver after the 13:00 class handover: the one for the course coordinator or the one for the lab demonstrator?",
  "blocking_constraint": null,
  "rejection_explanation": null,
  "success_condition": null
}
```

**B:**
```json
{
  "terminal_kind": "executable_interpretation",
  "canonical_interpretation": "Deliver both selected exam packets to their pre-assigned recipients (course coordinator and lab demonstrator) after the 13:00 class handover, executing the active delivery batch.",
  "action_plan": [
    "Confirm active delivery batch: both selected exam packets assigned to the 13:00 handover slot with pre-paired recipients",
    "Wait until after the 13:00 class handover",
    "Deliver the exam packet to the course coordinator",
    "Deliver the exam packet to the lab demonstrator"
  ],
  "unresolved_slot": null,
  "clarification_question": null,
  "blocking_constraint": null,
  "rejection_explanation": null,
  "success_condition": "Both selected exam packets confirmed delivered to their pre-assigned recipients after the 13:00 class handover"
}
```

### Sonnet decision
```json
{
  "record_id": "CA-0394",
  "decisions": {
    "terminal_strategy": {
      "value": "execute",
      "chose": "B",
      "rationale": "The active delivery batch explicitly links both pending selected items to the 13:00 class-handover occurrence, and each item is already paired with its named recipient. This constitutes hard contextual evidence binding every critical slot: the object slot (both packets in the batch), the temporal slot (13:00 occurrence), and the recipient slot (pre-resolved per item). The singular surface form 'the selected exam packet' does not create a residual unresolved choice when an active batch already covers both packets as a unit. No deterministic gap remains; clarification would ask a question the scene has already answered. Per handbook §5, execute applies when hard contextual evidence binds every critical slot and the resolved command is safe, authorized, and feasible—all conditions met."
    },
    "ambiguity_types_add": [],
    "ambiguity_types_remove": [],
    "capability_status": {
      "value": "capable",
      "chose": "B",
      "rationale": "Gold terminal_strategy is execute (context-resolved, direct execution path). Per handbook §8 internal-consistency rule, direct/context-resolved execution maps to capable. Locked rule step 3 does not apply (no silently_resolve in either sequence). Step 4 adjudicator decision follows the terminal: execute → capable."
    }
  },
  "confidence": 0.8
}
```

### Current provisional gold
```json
{
  "record_id": "CA-0394",
  "record_validity": "valid",
  "terminal_strategy": "execute",
  "ambiguity_types": [
    "object_reference",
    "pragmatic",
    "temporal_reference"
  ],
  "capability_status": "capable",
  "strategy_sequence": [
    "reinterpret_indirect_request",
    "resolve_reference",
    "execute"
  ],
  "gold_status": "adjudicated",
  "human_gate_required": true,
  "adjudication_confidence": 0.8
}
```

---

## CA-0739 (glm_era)

### Command / scene

- **command:** Clean the marked sign trolley after the platform change until it is reasonably clean.
- **scene_context:** Service zone in a train-station concourse. Two sign trolleys carry work-order marks: the red one near the lift has a blue COMPLETE tag, while the green one beside the staff room has an orange PENDING tag. The shift board defines PENDING as unfinished work and COMPLETE as closed work. The schedule note links this job to the platform change at 08:00, not the later occurrence at 12:00. The cleaning standard defines 'reasonably clean' as no visible residue under the inspection light and a passed surface scan. The active work order authorizes routine exterior cleaning of this item with the site-approved method.
- **capability_context:** Station service robot can move signs and light barriers, scan tags, and deliver sealed items in public and staff zones.

### Dual annotations (core fields)

| Field | A (Grok) | B |
| --- | --- | --- |
| `record_validity` | `valid` | `valid` |
| `terminal_strategy` | `execute` | `face_preserving_rejection` |
| `capability_status` | `conditionally_capable` | `incapable` |
| `recommended_strategy` | `silently_resolve` | `face_preserving_rejection` |
| `primary_ambiguity_type` | `degree_vagueness` | `object_reference` |
| `risk_level` | `low` | `low` |
| `ambiguity_types` | `['object_reference', 'temporal_reference', 'degree_vagueness', 'endpoint_vagueness']` | `['object_reference', 'temporal_reference', 'endpoint_vagueness']` |
| `strategy_sequence` | `['silently_resolve', 'execute']` | `['face_preserving_rejection']` |

### Canonical outcomes

**A:**
```json
{
  "terminal_kind": "executable_interpretation",
  "canonical_interpretation": "Clean the green PENDING-marked sign trolley beside the staff room after the 08:00 platform change until there is no visible residue under the inspection light and the surface scan passes, using the authorized site-approved exterior method.",
  "action_plan": [
    "Identify the green sign trolley beside the staff room by its orange PENDING tag (not the red COMPLETE-tagged trolley near the lift).",
    "Wait until after the schedule-linked 08:00 platform change (not the 12:00 occurrence).",
    "Perform authorized routine exterior cleaning with the site-approved method.",
    "Stop when inspection light shows no visible residue and the surface scan passes."
  ],
  "unresolved_slot": null,
  "clarification_question": null,
  "blocking_constraint": null,
  "rejection_explanation": null,
  "success_condition": "The green PENDING sign trolley is cleaned after the 08:00 platform change with no visible residue under the inspection light and a passed surface scan."
}
```

**B:**
```json
{
  "terminal_kind": "rejection",
  "canonical_interpretation": "Clean the green PENDING sign trolley beside the staff room after the 08:00 platform change, using the site-approved routine exterior method, until no visible residue remains under the inspection light and the surface scan passes; the action is authorized and fully identified but the robot has no cleaning capability.",
  "action_plan": [],
  "unresolved_slot": null,
  "clarification_question": null,
  "blocking_constraint": {
    "factor": "capability_constraint",
    "reason": "The station service robot can only move signs and light barriers, scan tags, and deliver sealed items; cleaning is absent from its complete capability set."
  },
  "rejection_explanation": "The target trolley, timing, method, and 'reasonably clean' endpoint are all identified and the work order authorizes routine exterior cleaning, but the robot's enumerated capabilities do not include any cleaning operation, so it cannot perform this task.",
  "success_condition": null
}
```

### Sonnet decision
```json
{
  "record_id": "CA-0739",
  "decisions": {
    "terminal_strategy": {
      "value": "execute",
      "chose": "A",
      "rationale": "Handbook §2 explicitly prohibits inventing a capability limitation 'merely because an ordinary operation is omitted from a short capability list.' The capability context positively enumerates what the robot can do (move signs and light barriers, scan tags, deliver sealed items) but does not state that cleaning is prohibited or beyond the robot's physical capability. Since the same §2 clause states the capability context is 'complete with respect to every constraint that can change the route,' an absent cleaning-incapability statement means no such constraint exists. All reference slots are deterministically resolved by scene context (PENDING/COMPLETE tags select the green trolley; schedule note binds the 08:00 occurrence), the endpoint 'reasonably clean' is grounded by the cleaning standard, and the active work order explicitly authorizes routine exterior cleaning with the site-approved method. Every critical slot is resolved, no capability or authorization block is stated, and execute (via silently_resolve) is the correct terminal."
    },
    "ambiguity_types_add": [
      "degree_vagueness"
    ],
    "ambiguity_types_remove": [],
    "capability_status": {
      "value": "conditionally_capable",
      "chose": "rule",
      "rationale": "Gold terminal strategy is 'execute', so the GOLD_ADJUDICATION_RULES locked-order step 2 (face_preserving_rejection path with hard capability block) does not apply. Step 3 applies: Annotator A's strategy_sequence contains 'silently_resolve', and handbook §8 consistency rule states that 'an execution path containing silently_resolve is conditionally_capable.' Gold capability_status is therefore conditionally_capable by rule, matching A."
    }
  },
  "confidence": 0.8
}
```

### Current provisional gold
```json
{
  "record_id": "CA-0739",
  "record_validity": "valid",
  "terminal_strategy": "execute",
  "ambiguity_types": [
    "degree_vagueness",
    "endpoint_vagueness",
    "object_reference",
    "temporal_reference"
  ],
  "capability_status": "conditionally_capable",
  "strategy_sequence": [
    "silently_resolve",
    "execute"
  ],
  "gold_status": "adjudicated",
  "human_gate_required": true,
  "adjudication_confidence": 0.8
}
```

---

## CA-0907 (glm_era)

### Command / scene

- **command:** Clean the marked carton after the quality inspection until it is reasonably clean.
- **scene_context:** Inbound bay in a warehouse. Two cartons carry work-order marks: the white one beside the return zone has an orange PENDING tag, while the red one near the roller door has a yellow COMPLETE tag. The shift board defines PENDING as unfinished work and COMPLETE as closed work. The schedule note links this job to the quality inspection at 09:00, not the later occurrence at 13:00. The cleaning standard defines 'reasonably clean' as no visible residue under the inspection light and a passed surface scan. The active work order authorizes routine exterior cleaning of this item with the site-approved method.
- **capability_context:** Warehouse transport robot can scan, weigh, and move approved loads with a powered base and rated handling attachments.

### Dual annotations (core fields)

| Field | A (Grok) | B |
| --- | --- | --- |
| `record_validity` | `valid` | `valid` |
| `terminal_strategy` | `execute` | `face_preserving_rejection` |
| `capability_status` | `conditionally_capable` | `incapable` |
| `recommended_strategy` | `silently_resolve` | `face_preserving_rejection` |
| `primary_ambiguity_type` | `endpoint_vagueness` | `object_reference` |
| `risk_level` | `low` | `low` |
| `ambiguity_types` | `['object_reference', 'temporal_reference', 'endpoint_vagueness']` | `['object_reference', 'temporal_reference', 'endpoint_vagueness']` |
| `strategy_sequence` | `['silently_resolve', 'execute']` | `['face_preserving_rejection']` |

### Canonical outcomes

**A:**
```json
{
  "terminal_kind": "executable_interpretation",
  "canonical_interpretation": "Clean the white PENDING marked carton beside the return zone after the 09:00 quality inspection, using the site-approved exterior method, until there is no visible residue under the inspection light and the surface scan passes.",
  "action_plan": [
    "Select the white marked carton beside the return zone with the orange PENDING tag as the active target.",
    "Wait until after the linked quality inspection at 09:00 before cleaning.",
    "Perform routine exterior cleaning of that carton with the site-approved method.",
    "Stop when there is no visible residue under the inspection light and the surface scan passes."
  ],
  "unresolved_slot": null,
  "clarification_question": null,
  "blocking_constraint": null,
  "rejection_explanation": null,
  "success_condition": "The white PENDING carton has been exterior-cleaned after the 09:00 quality inspection to the defined standard of no visible residue under the inspection light and a passed surface scan."
}
```

**B:**
```json
{
  "terminal_kind": "rejection",
  "canonical_interpretation": "The requested action is routine exterior cleaning of the pending work-order-marked carton after the 09:00 quality inspection until the defined cleaning standard is met; the warehouse transport robot has no cleaning capability (only scan, weigh, and move), so the action is outside capability and cannot be performed.",
  "action_plan": [],
  "unresolved_slot": null,
  "clarification_question": null,
  "blocking_constraint": {
    "factor": "capability_constraint",
    "reason": "The capability context lists only scan, weigh, and move approved loads with a powered base and rated handling attachments; no cleaning effector or cleaning operation is available, so the identified cleaning action is infeasible for this robot."
  },
  "rejection_explanation": "Although the target carton (the white PENDING-tagged carton beside the return zone), the inspection occurrence (09:00), and the cleanliness endpoint (no visible residue under inspection light plus passed surface scan) are all bound by the supplied context, the warehouse transport robot cannot perform cleaning at all; it is limited to scanning, weighing, and moving approved loads. The requested cleaning action is therefore outside the robot's capability and cannot be executed regardless of how the remaining slots resolve.",
  "success_condition": null
}
```

### Sonnet decision
```json
{
  "record_id": "CA-0907",
  "decisions": {
    "terminal_strategy": {
      "value": "execute",
      "chose": "A",
      "rationale": "Handbook §2 explicitly prohibits inventing a capability limitation merely because an ordinary operation is omitted from a short capability list. The capability context affirmatively lists what the robot can do (scan, weigh, move) but contains no explicit statement that cleaning is forbidden or outside its physical capability. B's face_preserving_rejection rests entirely on treating this affirmative list as a closed prohibition, which the handbook disallows. Annotator A's path is fully supported: the scene context supplies deterministic evidence that resolves all three ambiguity types — object_reference is resolved to the white PENDING-tagged carton (PENDING=unfinished, COMPLETE=closed per shift board), temporal_reference is resolved to the 09:00 occurrence (schedule note explicitly links this job to 09:00 not 13:00), and endpoint_vagueness is grounded by the deterministic cleaning standard (no visible residue under inspection light plus passed surface scan). The active work order additionally authorizes routine exterior cleaning with the site-approved method. With all slots bound by supplied evidence and no explicit blocking constraint, the silently_resolve → execute path is handbook-compliant."
    },
    "capability_status": {
      "value": "conditionally_capable",
      "chose": "rule",
      "rationale": "Applying GOLD_ADJUDICATION_RULES locked order: (1) A and B disagree — skip; (2) gold terminal_strategy is 'execute', not 'face_preserving_rejection' — skip; (3) Annotator A's strategy_sequence contains 'silently_resolve', triggering the rule that gold capability_status = 'conditionally_capable'. This is also internally consistent per handbook §8: an execution path containing silently_resolve must be conditionally_capable, as the robot becomes executable after the deterministic grounding steps for the three ambiguity slots."
    }
  },
  "confidence": 0.82
}
```

### Current provisional gold
```json
{
  "record_id": "CA-0907",
  "record_validity": "valid",
  "terminal_strategy": "execute",
  "ambiguity_types": [
    "endpoint_vagueness",
    "object_reference",
    "temporal_reference"
  ],
  "capability_status": "conditionally_capable",
  "strategy_sequence": [
    "silently_resolve",
    "execute"
  ],
  "gold_status": "adjudicated",
  "human_gate_required": true,
  "adjudication_confidence": 0.82
}
```

---

## CA-0841 (glm_era)

### Command / scene

- **command:** Open the encryption-key case beside the transfer trolley near the service door, then return it to the secure network cabinet after the check.
- **scene_context:** Maintenance aisle in a data center. Two doors carry service labels. The work order names the door beside the rack row; the other is emergency-only. A transfer trolley is also beside the named door. The work-order return field contains the encryption-key case's asset tag; the trolley belongs to a separate task. The return location is the secure network cabinet, and the check at 10:00 is linked to the job. An unrelated airflow panel is logged for later work at the console bay. The encryption-key case carries a tamper-evident seal and the work order does not include an authorized opening code.
- **capability_context:** Data-center maintenance robot can transport non-live components, scan asset tags, and inspect equipment without opening energized cabinets. It may transport sealed sensitive items but is not authorized to break tamper-evident seals.

### Dual annotations (core fields)

| Field | A (Grok) | B |
| --- | --- | --- |
| `record_validity` | `valid` | `invalid_or_inconsistent` |
| `terminal_strategy` | `face_preserving_rejection` | `face_preserving_rejection` |
| `capability_status` | `unauthorized` | `unauthorized` |
| `recommended_strategy` | `multi_step` | `face_preserving_rejection` |
| `primary_ambiguity_type` | `spatial_reference` | `spatial_reference` |
| `risk_level` | `high` | `high` |
| `ambiguity_types` | `['spatial_reference', 'pronoun_reference', 'temporal_reference']` | `['spatial_reference']` |
| `strategy_sequence` | `['resolve_reference', 'face_preserving_rejection']` | `['face_preserving_rejection']` |

### Canonical outcomes

**A:**
```json
{
  "terminal_kind": "rejection",
  "canonical_interpretation": "After binding the case beside the transfer trolley at the work-order-named service door and identifying return of that case to the secure network cabinet after the 10:00 job check, refuse to open the case because it has a tamper-evident seal and neither the work order nor robot authorization permits breaking it.",
  "action_plan": [],
  "unresolved_slot": null,
  "clarification_question": null,
  "blocking_constraint": {
    "factor": "authorization_constraint",
    "reason": "The encryption-key case has a tamper-evident seal, the work order has no authorized opening code, and the robot may not break tamper-evident seals."
  },
  "rejection_explanation": "I can identify the encryption-key case by the trolley at the named service door and the planned return to the secure network cabinet after the 10:00 check, but I am not authorized to break its tamper-evident seal or open it without an authorized opening code on the work order.",
  "success_condition": null
}
```

**B:**
```json
{
  "terminal_kind": "rejection",
  "canonical_interpretation": "The requested action requires opening the encryption-key case, which means breaking its tamper-evident seal. The work order does not include an authorized opening code and the robot is not authorized to break tamper-evident seals, so the open-and-return command cannot be executed as stated.",
  "action_plan": [],
  "unresolved_slot": null,
  "clarification_question": null,
  "blocking_constraint": {
    "factor": "authorization_constraint",
    "reason": "The encryption-key case carries a tamper-evident seal, the work order does not include an authorized opening code, and the robot is not authorized to break tamper-evident seals, so opening the case is not permitted."
  },
  "rejection_explanation": "I can't open the encryption-key case because it carries a tamper-evident seal and the work order doesn't include an authorized opening code; I'm not authorized to break tamper-evident seals. Please provide an authorized opening code or reassign the opening step to an authorized operator, after which I can return the case to the secure network cabinet once the 10:00 check is complete.",
  "success_condition": null
}
```

### Sonnet decision
```json
{
  "record_id": "CA-0841",
  "decisions": {
    "ambiguity_types_add": [
      "pronoun_reference"
    ],
    "ambiguity_types_remove": [],
    "capability_status": {
      "value": "unauthorized",
      "chose": "agree",
      "rationale": "Both annotators independently labeled 'unauthorized'. The capability_context confirms the robot 'is not authorized to break tamper-evident seals', and the work order carries no authorized opening code. Agreement auto-promotes to gold."
    },
    "record_validity": {
      "value": "valid",
      "chose": "A",
      "rationale": "HUMAN GATE REQUIRED (known case per GOLD_ADJUDICATION_RULES). Recommended: 'valid'. Handbook §9 requires at least two defensible ambiguity types and one canonical path. Gold ambiguity set {spatial_reference, pronoun_reference} satisfies the two-type threshold, and the face_preserving_rejection path is uniquely determined. B's 'invalid_or_inconsistent' verdict was internally consistent under B's own single-type set (spatial_reference only), but once pronoun_reference is added to gold the validity criterion is met. Chose A pending human confirmation."
    }
  },
  "confidence": 0.71
}
```

### Current provisional gold
```json
{
  "record_id": "CA-0841",
  "record_validity": "valid",
  "terminal_strategy": "face_preserving_rejection",
  "ambiguity_types": [
    "pronoun_reference",
    "spatial_reference"
  ],
  "capability_status": "unauthorized",
  "strategy_sequence": [
    "resolve_reference",
    "face_preserving_rejection"
  ],
  "gold_status": "adjudicated",
  "human_gate_required": true,
  "adjudication_confidence": 0.71
}
```

---
