#!/usr/bin/env python3
"""Build gold-v1 labels and adjudication packets for manual Kappa v7."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "annotations" / "manual_kappa_v7"
A_DIR = OUT / "annotator_a_grok"
B_DIR = OUT / "annotator_b_claude"
IN_DIR = OUT / "inputs"
MANIFEST = OUT / "subset_manifest.json"
ROSTER = OUT / "annotator_b_model_roster.json"
GOLD_DIR = OUT / "gold"
PACKET_DIR = OUT / "adjudication" / "packets"
DECISION_DIR = OUT / "adjudication" / "decisions"
QUEUE_PATH = OUT / "adjudication" / "pending_queue.json"
GOLD_MANIFEST = OUT / "gold_manifest.json"
EVAL_DIR = OUT / "eval"
EVAL_JSONL = EVAL_DIR / "subset_120_eval.jsonl"
EVAL_FINAL_JSONL = EVAL_DIR / "subset_final_gold_eval.jsonl"

TERMINAL_VALUES = {
    "execute",
    "clarify",
    "face_preserving_rejection",
}
CAPABILITY_VALUES = {
    "capable",
    "conditionally_capable",
    "incapable",
    "unauthorized",
    "unsafe",
}
VALIDITY_VALUES = {"valid", "invalid_or_inconsistent"}
LIFECYCLE_VALUES = {
    "auto_agreed",
    "adjudicated_provisional",
    "human_review_required",
    "final_gold",
}


def _load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def _dump(path: Path, obj: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()


def _era_for(rid: str, roster: dict) -> str:
    if rid in roster["annotator_b_by_era"]["claude_era"]["record_ids"]:
        return "claude_era"
    return "glm_era"


def _seq(ann: dict) -> list:
    seq = ann.get("strategy_sequence")
    if isinstance(seq, list):
        return [str(x) for x in seq]
    return []


def apply_capability_rule(
    *,
    terminal: str | None,
    a: dict,
    b: dict,
) -> str | None:
    """Return ruled capability or None if unresolved.

    Capability is route-independent: never derive status from silently_resolve /
    clarify / strategy_sequence. Only agreement or hard-block heuristic applies.
    """
    a_cap = a.get("capability_status")
    b_cap = b.get("capability_status")
    if a_cap == b_cap and a_cap in CAPABILITY_VALUES:
        return str(a_cap)

    # Hard rejection blocks may still leave A/B disagreeing on which label —
    # defer to adjudication packet rather than inventing a route-derived value.
    if terminal == "face_preserving_rejection":
        hard = {"incapable", "unauthorized", "unsafe"}
        if a_cap in hard and b_cap in hard and a_cap != b_cap:
            return None
        if {a_cap, b_cap} & hard and a_cap != b_cap:
            return None
    return None


def compute_gold_lifecycle(*, gold_status: str, human_gate: bool) -> str:
    """Authoritative export lifecycle. Human-gated records are never final_gold."""
    if human_gate:
        return "human_review_required"
    if gold_status == "adjudicated":
        return "final_gold"
    if gold_status in {"auto_agree", "auto_agree_with_rule"}:
        return "final_gold"
    return "adjudicated_provisional"


def build_packet(rid: str, inp: dict, a: dict, b: dict, pending: dict, era: str) -> dict:
    sa = set(a.get("ambiguity_types") or [])
    sb = set(b.get("ambiguity_types") or [])
    return {
        "record_id": rid,
        "annotator_b_era": era,
        "pending_fields": sorted(pending.keys()),
        "field_diffs": pending,
        "intersection_ambiguity_types": sorted(sa & sb),
        "a_only_ambiguity_types": sorted(sa - sb),
        "b_only_ambiguity_types": sorted(sb - sa),
        "annotator_a": {
            "record_validity": a.get("record_validity"),
            "ambiguity_types": a.get("ambiguity_types"),
            "terminal_strategy": a.get("terminal_strategy"),
            "capability_status": a.get("capability_status"),
            "strategy_sequence": a.get("strategy_sequence"),
            "recommended_strategy": a.get("recommended_strategy"),
            "canonical_outcome": a.get("canonical_outcome"),
            "evidence": a.get("evidence"),
        },
        "annotator_b": {
            "record_validity": b.get("record_validity"),
            "ambiguity_types": b.get("ambiguity_types"),
            "terminal_strategy": b.get("terminal_strategy"),
            "capability_status": b.get("capability_status"),
            "strategy_sequence": b.get("strategy_sequence"),
            "recommended_strategy": b.get("recommended_strategy"),
            "canonical_outcome": b.get("canonical_outcome"),
            "evidence": b.get("evidence"),
        },
        "input": inp,
    }


def synthesize_record(
    rid: str,
    a: dict,
    b: dict,
    era: str,
    *,
    decisions: dict | None = None,
) -> tuple[dict, dict | None]:
    """Return (gold_record_or_partial, pending_diffs_or_None)."""
    decisions = decisions or {}
    field_status: dict[str, str] = {}
    pending: dict = {}

    # validity
    av, bv = a.get("record_validity"), b.get("record_validity")
    if "record_validity" in (decisions.get("decisions") or {}):
        d = decisions["decisions"]["record_validity"]
        validity = d["value"]
        field_status["record_validity"] = f"adjudicated:{d.get('chose')}"
    elif av == bv and av in VALIDITY_VALUES:
        validity = av
        field_status["record_validity"] = "auto_agree"
    else:
        validity = None
        pending["record_validity"] = {"A": av, "B": bv}
        field_status["record_validity"] = "pending"

    # terminal
    at, bt = a.get("terminal_strategy"), b.get("terminal_strategy")
    if "terminal_strategy" in (decisions.get("decisions") or {}):
        d = decisions["decisions"]["terminal_strategy"]
        terminal = d["value"]
        field_status["terminal_strategy"] = f"adjudicated:{d.get('chose')}"
    elif at == bt and at in TERMINAL_VALUES:
        terminal = at
        field_status["terminal_strategy"] = "auto_agree"
    else:
        terminal = None
        pending["terminal_strategy"] = {"A": at, "B": bt}
        field_status["terminal_strategy"] = "pending"

    # types
    sa = set(a.get("ambiguity_types") or [])
    sb = set(b.get("ambiguity_types") or [])
    types = set(sa & sb)
    if decisions.get("decisions"):
        d = decisions["decisions"]
        for t in d.get("ambiguity_types_add") or []:
            types.add(t)
        for t in d.get("ambiguity_types_remove") or []:
            types.discard(t)
        if sa != sb or d.get("ambiguity_types_add") or d.get("ambiguity_types_remove"):
            field_status["ambiguity_types"] = "adjudicated"
        else:
            field_status["ambiguity_types"] = "auto_agree"
    elif sa == sb:
        field_status["ambiguity_types"] = "auto_agree"
    else:
        field_status["ambiguity_types"] = "pending"
        pending["ambiguity_types"] = {
            "intersection": sorted(sa & sb),
            "A_only": sorted(sa - sb),
            "B_only": sorted(sb - sa),
        }

    # capability (route-independent)
    ac, bc = a.get("capability_status"), b.get("capability_status")
    ruled = apply_capability_rule(terminal=terminal, a=a, b=b) if terminal is not None else None
    if "capability_status" in (decisions.get("decisions") or {}):
        d = decisions["decisions"]["capability_status"]
        capability = d["value"]
        chose = d.get("chose")
        # Legacy decisions may say chose:rule from the removed silently_resolve mapping.
        field_status["capability_status"] = f"adjudicated:{chose}"
    elif ac == bc and ac in CAPABILITY_VALUES:
        capability = ac
        field_status["capability_status"] = "auto_agree"
    elif ruled is not None:
        capability = ruled
        field_status["capability_status"] = "rule"
    else:
        capability = None
        pending["capability_status"] = {"A": ac, "B": bc, "ruled": ruled}
        field_status["capability_status"] = "pending"

    # strategy_sequence: promote if agree; else prefer side matching gold terminal
    aseq, bseq = _seq(a), _seq(b)
    if aseq == bseq and aseq:
        seq = aseq
        field_status["strategy_sequence"] = "auto_agree"
    elif terminal is not None:
        if aseq and aseq[-1] == terminal:
            seq = aseq
            field_status["strategy_sequence"] = "from_A_matching_terminal"
        elif bseq and bseq[-1] == terminal:
            seq = bseq
            field_status["strategy_sequence"] = "from_B_matching_terminal"
        else:
            seq = [terminal] if terminal else []
            field_status["strategy_sequence"] = "terminal_only"
    else:
        seq = []
        field_status["strategy_sequence"] = "pending"

    human_gate = False
    if field_status.get("terminal_strategy", "").startswith("adjudicated"):
        chose = (decisions.get("decisions") or {}).get("terminal_strategy", {}).get("chose")
        if chose == "neither" or field_status["terminal_strategy"] != "auto_agree":
            # any adjudicated terminal needs human gate per protocol
            if "pending" not in field_status.get("terminal_strategy", ""):
                if at != bt or chose == "neither":
                    human_gate = True
    if field_status.get("record_validity", "").startswith("adjudicated"):
        human_gate = True
    if (decisions.get("decisions") or {}).get("terminal_strategy", {}).get("chose") == "neither":
        human_gate = True
    if (decisions.get("decisions") or {}).get("capability_status", {}).get("chose") == "neither":
        human_gate = True
    if (decisions.get("decisions") or {}).get("record_validity", {}).get("chose") == "neither":
        human_gate = True

    if pending and not decisions:
        return {
            "record_id": rid,
            "annotator_b_era": era,
            "field_status": field_status,
            "partial": {
                "record_validity": validity,
                "terminal_strategy": terminal,
                "ambiguity_types": sorted(types),
                "capability_status": capability,
                "strategy_sequence": seq,
            },
        }, pending

    gold_status = "auto_agree"
    if any(str(v).startswith("adjudicated") for v in field_status.values()):
        gold_status = "adjudicated"
    elif any(v == "rule" for v in field_status.values()):
        gold_status = "auto_agree_with_rule"

    if pending:
        # still unfinished
        return {
            "record_id": rid,
            "annotator_b_era": era,
            "field_status": field_status,
            "partial": {
                "record_validity": validity,
                "terminal_strategy": terminal,
                "ambiguity_types": sorted(types),
                "capability_status": capability,
                "strategy_sequence": seq,
            },
        }, pending

    lifecycle = compute_gold_lifecycle(gold_status=gold_status, human_gate=human_gate)
    gold = {
        "record_id": rid,
        "record_validity": validity,
        "ambiguity_types": sorted(types),
        "terminal_strategy": terminal,
        "capability_status": capability,
        "strategy_sequence": seq,
        "gold_status": gold_status,
        "gold_lifecycle": lifecycle,
        "field_status": field_status,
        "annotator_b_era": era,
        "annotator_b_model": None,
        "human_gate_required": human_gate,
        "adjudication_confidence": decisions.get("confidence") if decisions else None,
        "provenance": {
            "annotator_a_sha256": None,
            "annotator_b_sha256": None,
            "input_sha256": None,
        },
    }
    return gold, None


def run_build(*, apply_decisions: bool) -> dict:
    manifest = _load_json(MANIFEST)
    roster = _load_json(ROSTER)
    ids = manifest["record_ids"]
    PACKET_DIR.mkdir(parents=True, exist_ok=True)
    DECISION_DIR.mkdir(parents=True, exist_ok=True)
    GOLD_DIR.mkdir(parents=True, exist_ok=True)
    EVAL_DIR.mkdir(parents=True, exist_ok=True)

    pending_queue = []
    gold_records = []
    human_gate_ids = []

    for rid in ids:
        a = _load_json(A_DIR / f"{rid}.json")
        b = _load_json(B_DIR / f"{rid}.json")
        inp = _load_json(IN_DIR / f"{rid}.json")
        era = _era_for(rid, roster)
        decision_path = DECISION_DIR / f"{rid}.json"
        decisions = _load_json(decision_path) if apply_decisions and decision_path.exists() else None

        gold, pending = synthesize_record(rid, a, b, era, decisions=decisions)
        if pending is not None and decisions is None:
            packet = build_packet(rid, inp, a, b, pending, era)
            _dump(PACKET_DIR / f"{rid}.json", packet)
            pending_queue.append(
                {
                    "record_id": rid,
                    "annotator_b_era": era,
                    "pending_fields": sorted(pending.keys()),
                    "needs_human_gate_if_terminal_or_validity": bool(
                        {"terminal_strategy", "record_validity"} & set(pending.keys())
                    ),
                }
            )
            continue

        if pending is not None and decisions is not None:
            # decisions incomplete
            packet = build_packet(rid, inp, a, b, pending, era)
            _dump(PACKET_DIR / f"{rid}.json", packet)
            pending_queue.append(
                {
                    "record_id": rid,
                    "annotator_b_era": era,
                    "pending_fields": sorted(pending.keys()),
                    "note": "decisions present but fields still pending",
                }
            )
            continue

        gold["annotator_b_model"] = roster["per_record_b_model"][rid]
        gold["provenance"] = {
            "annotator_a_sha256": _sha256_file(A_DIR / f"{rid}.json"),
            "annotator_b_sha256": _sha256_file(B_DIR / f"{rid}.json"),
            "input_sha256": _sha256_file(IN_DIR / f"{rid}.json"),
        }
        _dump(GOLD_DIR / f"{rid}.json", gold)
        gold_records.append(gold)
        if gold.get("human_gate_required"):
            human_gate_ids.append(rid)

    _dump(
        QUEUE_PATH,
        {
            "n_pending": len(pending_queue),
            "n_gold": len(gold_records),
            "pending": pending_queue,
            "human_gate_ids": human_gate_ids,
        },
    )

    summary = {
        "n_subset": len(ids),
        "n_gold_written": len(gold_records),
        "n_pending_packets": len(pending_queue),
        "pending_ids": [p["record_id"] for p in pending_queue],
        "human_gate_ids": human_gate_ids,
        "pending_field_histogram": {},
    }
    hist: dict[str, int] = {}
    for p in pending_queue:
        for f in p["pending_fields"]:
            hist[f] = hist.get(f, 0) + 1
    summary["pending_field_histogram"] = hist
    return summary


def auto_accept_type_only_decisions(min_confidence: float = 0.7) -> list[str]:
    """Mark which pending packets are type/capability-only for auto-accept after Sonnet."""
    queue = _load_json(QUEUE_PATH)
    auto_ids = []
    for item in queue.get("pending", []):
        fields = set(item["pending_fields"])
        if fields & {"terminal_strategy", "record_validity"}:
            continue
        auto_ids.append(item["record_id"])
    _dump(
        OUT / "adjudication" / "auto_accept_candidates.json",
        {"min_confidence": min_confidence, "record_ids": auto_ids},
    )
    return auto_ids


def write_eval_and_manifest() -> dict:
    roster = _load_json(ROSTER)
    manifest = _load_json(MANIFEST)
    ids = manifest["record_ids"]
    gold_ids = sorted(p.stem for p in GOLD_DIR.glob("CA-*.json"))
    missing = [i for i in ids if i not in set(gold_ids)]
    entries = []
    lines_all = []
    lines_final = []
    gated_in_final = []
    for rid in ids:
        gpath = GOLD_DIR / f"{rid}.json"
        if not gpath.exists():
            continue
        gold = _load_json(gpath)
        inp = _load_json(IN_DIR / f"{rid}.json")
        if gold.get("record_validity") != "valid":
            continue
        lifecycle = gold.get("gold_lifecycle") or compute_gold_lifecycle(
            gold_status=str(gold.get("gold_status")),
            human_gate=bool(gold.get("human_gate_required")),
        )
        row = {
            "record_id": rid,
            "input": inp,
            "gold": {
                "terminal_strategy": gold["terminal_strategy"],
                "ambiguity_types": gold["ambiguity_types"],
                "capability_status": gold["capability_status"],
            },
            "annotator_b_era": gold["annotator_b_era"],
            "gold_status": gold["gold_status"],
            "gold_lifecycle": lifecycle,
            "human_gate_required": gold.get("human_gate_required", False),
        }
        lines_all.append(json.dumps(row, ensure_ascii=False))
        if gold.get("human_gate_required") or lifecycle == "human_review_required":
            # provisional all-subset export may retain, but final export must not
            pass
        else:
            lines_final.append(json.dumps(row, ensure_ascii=False))
        if gold.get("human_gate_required") and lifecycle == "final_gold":
            gated_in_final.append(rid)
        entries.append(
            {
                "record_id": rid,
                "gold_sha256": _sha256_file(gpath),
                "annotator_b_era": gold["annotator_b_era"],
                "gold_status": gold["gold_status"],
                "gold_lifecycle": lifecycle,
                "human_gate_required": gold.get("human_gate_required", False),
            }
        )

    if gated_in_final:
        raise RuntimeError(
            "human_gate_required records incorrectly marked final_gold: "
            + ", ".join(gated_in_final)
        )

    EVAL_JSONL.write_text("\n".join(lines_all) + ("\n" if lines_all else ""), encoding="utf-8")
    EVAL_FINAL_JSONL.write_text(
        "\n".join(lines_final) + ("\n" if lines_final else ""), encoding="utf-8"
    )
    n_human = sum(1 for e in entries if e.get("human_gate_required"))
    n_final = sum(1 for e in entries if e.get("gold_lifecycle") == "final_gold")
    gm = {
        "version": 2,
        "n_subset": len(ids),
        "n_gold": len(entries),
        "n_missing_gold": len(missing),
        "missing_gold_ids": missing,
        "n_eval_valid": len(lines_all),
        "n_final_gold_export": len(lines_final),
        "n_human_review_required": n_human,
        "n_final_gold_lifecycle": n_final,
        "roster_sha256": _sha256_file(ROSTER),
        "eval_jsonl": str(EVAL_JSONL.relative_to(ROOT)).replace("\\", "/"),
        "eval_final_gold_jsonl": str(EVAL_FINAL_JSONL.relative_to(ROOT)).replace("\\", "/"),
        "records": entries,
        "annotator_b_era_counts": {
            "claude_era": sum(1 for e in entries if e["annotator_b_era"] == "claude_era"),
            "glm_era": sum(1 for e in entries if e["annotator_b_era"] == "glm_era"),
        },
    }
    _dump(GOLD_MANIFEST, gm)
    return gm


def write_human_gate_md() -> None:
    queue = _load_json(QUEUE_PATH) if QUEUE_PATH.exists() else {"human_gate_ids": []}
    ids = []
    for p in GOLD_DIR.glob("CA-*.json"):
        g = _load_json(p)
        if g.get("human_gate_required"):
            ids.append(g["record_id"])
    # also pending terminals/validity still not gold
    pending_human = [
        p["record_id"]
        for p in queue.get("pending", [])
        if set(p.get("pending_fields", [])) & {"terminal_strategy", "record_validity"}
    ]
    lines = [
        "# Human gate — gold-v1",
        "",
        "Review these before treating gold as final for publication claims.",
        "Cluster pilot may proceed with Sonnet-applied gold while this list is open.",
        "",
        "## Terminal / validity adjudications requiring confirmation",
        "",
    ]
    for rid in sorted(set(ids) | set(pending_human)):
        dpath = DECISION_DIR / f"{rid}.json"
        gpath = GOLD_DIR / f"{rid}.json"
        apath = A_DIR / f"{rid}.json"
        bpath = B_DIR / f"{rid}.json"
        a = _load_json(apath)
        b = _load_json(bpath)
        lines.append(f"### {rid}")
        lines.append("")
        lines.append(f"- A terminal: `{a.get('terminal_strategy')}` | B terminal: `{b.get('terminal_strategy')}`")
        lines.append(f"- A validity: `{a.get('record_validity')}` | B validity: `{b.get('record_validity')}`")
        if dpath.exists():
            d = _load_json(dpath)
            lines.append(f"- Sonnet decision: `{json.dumps(d.get('decisions'), ensure_ascii=False)}`")
            lines.append(f"- confidence: `{d.get('confidence')}`")
        if gpath.exists():
            g = _load_json(gpath)
            lines.append(
                f"- current gold terminal=`{g.get('terminal_strategy')}` types=`{g.get('ambiguity_types')}` cap=`{g.get('capability_status')}`"
            )
        lines.append("")
    path = OUT / "adjudication" / "HUMAN_GATE.md"
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--apply-decisions",
        action="store_true",
        help="Apply adjudication/decisions/*.json when synthesizing gold",
    )
    parser.add_argument(
        "--write-eval",
        action="store_true",
        help="Write gold_manifest.json and eval JSONL from existing gold/",
    )
    args = parser.parse_args()

    if args.write_eval and not args.apply_decisions:
        gm = write_eval_and_manifest()
        write_human_gate_md()
        print(json.dumps(gm, indent=2))
        return 0

    summary = run_build(apply_decisions=args.apply_decisions)
    auto_accept_type_only_decisions()
    if args.apply_decisions or summary["n_pending_packets"] == 0:
        gm = write_eval_and_manifest()
        write_human_gate_md()
        summary["gold_manifest"] = {
            "n_gold": gm["n_gold"],
            "n_eval_valid": gm["n_eval_valid"],
            "n_missing_gold": gm["n_missing_gold"],
        }
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
