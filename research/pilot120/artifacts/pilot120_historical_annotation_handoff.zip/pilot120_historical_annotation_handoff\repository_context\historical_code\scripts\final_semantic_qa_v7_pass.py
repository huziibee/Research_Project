#!/usr/bin/env python3
"""Final semantic QA support for compound-ambiguity v7.

Policy (2026-08-07 owner decision):
- Do NOT family-wide rewrite the full 1000 yet.
- Repair capability_context ONLY for the 120-record kappa subset where
  execute (and post-clarify action) routes lack explicit action evidence.
- Emit full-1000 capability audit + deferred roadmap.
- Build private owner QA contracts for the 120 gold subset from adjudicated gold.
- Scaffold final-protocol reannotation package for the 120.
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
from collections import Counter, defaultdict
from copy import deepcopy
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_JSON = ROOT / "data" / "compound 1000" / "compound_ambiguity_unique_resolution_1000_v7.json"
DATA_JSONL = ROOT / "data" / "compound 1000" / "compound_ambiguity_unique_resolution_1000_v7.jsonl"
CHECKSUMS = ROOT / "data" / "compound 1000" / "compound_ambiguity_unique_resolution_1000_v7_checksums.json"
HANDBOOK_SRC = ROOT / "data" / "compound 1000" / "compound_ambiguity_annotation_handbook_v7.md"
SCHEMA_SRC = ROOT / "data" / "compound 1000" / "compound_ambiguity_annotation_output_schema_v7.json"
INPUT_SCHEMA_SRC = ROOT / "data" / "compound 1000" / "compound_ambiguity_input_schema_v7.json"
VALIDATOR_SRC = ROOT / "data" / "compound 1000" / "validate_compound_ambiguity_annotations_v7.py"

KAPPA = ROOT / "annotations" / "manual_kappa_v7"
INPUTS = KAPPA / "inputs"
GOLD = KAPPA / "gold"
MANIFEST = KAPPA / "subset_manifest.json"
BRIEF_SRC = KAPPA / "briefs" / "annotator_brief.md"

OWNER = ROOT / "annotations" / "private_owner_qa_v7"
FINAL = ROOT / "annotations" / "manual_kappa_v7_final_protocol"
REPORT = ROOT / "FINAL_SEMANTIC_QA_REPORT.md"
DEFERRED = ROOT / "docs" / "DEFERRED_FULL_1000_SEMANTIC_QA_NOTES.md"

ACTION_PATS = {
    "refill": re.compile(r"\b(?:refill|top up)\b", re.I),
    "seal": re.compile(r"\bseal\b", re.I),
    "inspect": re.compile(r"\binspect\b", re.I),
    "clean": re.compile(r"\b(?:clean|contain and clean)\b", re.I),
    "weigh": re.compile(r"\bweigh\b", re.I),
    "charge": re.compile(r"\b(?:re)?charge\b", re.I),
    "dispense": re.compile(r"\bdispense\b", re.I),
    "unlock": re.compile(r"\bunlock\b", re.I),
    "scan": re.compile(r"\bscan\b", re.I),
    "record": re.compile(r"\brecord\b(?!\s+folder)", re.I),
    "copy": re.compile(r"\b(?:print one|print a|copy)\b", re.I),
    "deliver": re.compile(r"\bdeliver\b", re.I),
    "open": re.compile(r"\bopen\b", re.I),
    "move": re.compile(r"\b(?:move|relocate|transport|carry)\b", re.I),
    "place": re.compile(r"\bplace\b", re.I),
    "handle": re.compile(r"\bhandle\b", re.I),
}

CAP_HINTS = {
    "refill": ["refill", "top up", "replenish", "dosing", "dispense non-hazardous", "approved liquid"],
    "seal": ["seal", "approval seal", "official seal", "tamper-evident", "apply approved"],
    "inspect": ["inspect", "inspection"],
    "clean": ["clean", "wipe", "sanitize", "wash", "exterior cleaning"],
    "weigh": ["weigh", "scale", "mass", "kilogram"],
    "charge": ["charge", "charging", "recharge"],
    "dispense": ["dispense", "dosing"],
    "unlock": ["unlock", "access"],
    "scan": ["scan"],
    "record": ["record", "capture"],
    "copy": ["copy", "print"],
    "deliver": ["deliver", "handoff", "delivery"],
    "open": ["open", "unseal", "break tamper", "not authorized to break"],
    "move": ["move", "carry", "transport", "relocat", "navigate", "handling", "payload"],
    "place": ["place", "carry", "move", "transport", "handling"],
    "handle": ["handle", "handling", "move", "carry", "transport"],
}

CAP_APPEND = {
    "refill": (
        " It can refill approved non-hazardous liquid containers using calibrated dosing tools "
        "within listed volume limits."
    ),
    "seal": (
        " It can apply approved tamper-evident or official approval seals to designated containers."
    ),
    "inspect": (
        " It can perform visual inspections of approved items with calibrated inspection cameras "
        "or assigned inspection probes."
    ),
    "charge": (
        " It can recharge approved portable devices at designated service charging points "
        "within certified power limits."
    ),
    "deliver": (
        " It can deliver sealed authorized items to named destinations within its certified handoff limits."
    ),
    "record": (
        " It can record document status with the assigned capture device under the named routine setup."
    ),
    "copy": (
        " It can print or copy approved non-confidential documents to authenticated destinations."
    ),
}

BLOCK_PAT = re.compile(
    r"not authorized|unauthorized|cannot |can not |unable to|unsafe|prohibited|forbidden|"
    r"outside (?:its |the robot.?s )?certif|beyond (?:its |rated)|no (?:approved|authorization)|"
    r"sealing head is unavailable|not fitted|access denied|privacy|hazard|restricted|"
    r"only to authenticated|cannot decontaminate|"
    r"credential covers|does not possess(?:\s+\w+){0,6}\s+approv|"
    r"approval authority|no redundant module|"
    r"only after a verified handover|"
    r"access zone Z\d",
    re.I,
)

FAMILY_FROM_CMD = [
    ("refill_top_up_return", re.compile(r"\b(?:refill|top up)\b.+\breturn it\b", re.I)),
    ("refill_only_small_amount", re.compile(r"\bonly refill\b.+\bsmall amount\b", re.I)),
    ("seal_batch_tool_until", re.compile(r"\bseal\b.+\bbatch-seal tool\b.+\buntil\b", re.I)),
    ("seal_beside_return", re.compile(r"\bseal\b.+\bbeside the transfer trolley\b.+\breturn it\b", re.I)),
    ("inspect_camera_release", re.compile(r"\binspect\b.+\binspection camera\b.+\broutine release\b", re.I)),
    ("inspect_probe_after_check", re.compile(r"\binspect\b.+\binspection probe\b.+\bafter the check\b", re.I)),
    ("charge_sensible_level", re.compile(r"\brecharge\b.+\bsensible level\b", re.I)),
    ("place_scale_handle_return", re.compile(r"\bplace\b.+\bscale\b.+\bhandle it by returning\b", re.I)),
    ("deliver_selected_after_scheduled", re.compile(
        r"(?:\bdeliver the selected\b.+\bafter a scheduled\b)|(?:\bafter a scheduled\b.+\bdeliver the selected\b)",
        re.I,
    )),
    ("deliver_to_recipient_after_scheduled", re.compile(
        r"\bdeliver\b.+\bafter (?:the )?scheduled\b",
        re.I,
    )),
    ("deliver_selected_can_be", re.compile(r"\bcan the selected\b.+\bbe delivered\b", re.I)),
    ("do_not_move_and_inspect", re.compile(r"\bdo not move and inspect\b", re.I)),
    ("relocate_active_module_usual_setup", re.compile(r"\brelocate the active service module\b.+\busual setup\b", re.I)),
    ("do_the_same_after_scheduled", re.compile(r"\bdo the same with the marked\b.+\bafter a scheduled\b", re.I)),
    ("open_beside_return_it", re.compile(r"\bopen\b.+\bbeside\b.+\breturn it\b", re.I)),
    ("clean_until_reasonably_clean", re.compile(r"until it is reasonably clean", re.I)),
]


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def family_of(command: str) -> str:
    for name, pat in FAMILY_FROM_CMD:
        if pat.search(command):
            return name
    return "unclustered"


def requested_actions(command: str) -> list[str]:
    found = [name for name, pat in ACTION_PATS.items() if pat.search(command)]
    if any(a in found for a in ("clean", "seal", "open", "refill", "inspect", "deliver", "weigh", "charge")):
        found = [a for a in found if a != "move"]
    return found


def has_cap(cap: str, action: str) -> bool:
    c = cap.lower()
    return any(h in c for h in CAP_HINTS[action])


def blocking_constraints(rec: dict) -> list[str]:
    out = []
    for field in ("capability_context", "scene_context"):
        text = rec[field]
        for m in BLOCK_PAT.finditer(text):
            # take a short local window
            start = max(0, m.start() - 40)
            end = min(len(text), m.end() + 80)
            snippet = re.sub(r"\s+", " ", text[start:end]).strip()
            out.append(f"{field}: ...{snippet}...")
    # de-dup preserving order
    seen = set()
    uniq = []
    for s in out:
        if s not in seen:
            seen.add(s)
            uniq.append(s)
    return uniq


def ensure_action_cap(cap: str, action: str) -> tuple[str, bool]:
    if has_cap(cap, action):
        return cap, False
    append = CAP_APPEND.get(action)
    if not append:
        return cap, False
    if append.strip() in cap:
        return cap, False
    return cap.rstrip() + append, True


def classify_capability(rec: dict, gold: dict | None) -> dict:
    actions = requested_actions(rec["command"])
    missing = [a for a in actions if not has_cap(rec["capability_context"], a)]
    blocks = blocking_constraints(rec)
    terminal = (gold or {}).get("terminal_strategy")
    family = family_of(rec["command"])

    if blocks and terminal == "face_preserving_rejection":
        cls = "B"
    elif missing:
        if terminal == "clarify":
            cls = "C"
        elif terminal == "execute":
            cls = "D"
        elif terminal == "face_preserving_rejection":
            cls = "B" if blocks else "D"
        else:
            cls = "D"
    else:
        cls = "A"
        if blocks and terminal == "face_preserving_rejection":
            cls = "B"

    return {
        "record_id": rec["record_id"],
        "family": family,
        "requested_actions": actions,
        "missing_actions": missing,
        "qa_capability_class": cls,
        "blocking_constraint_present": bool(blocks),
        "blocking_constraints": blocks,
        "terminal_strategy_from_gold": terminal,
        "in_kappa_subset": bool(gold is not None),
        "capability_context": rec["capability_context"],
        "command": rec["command"],
    }


def repair_subset_capabilities(data: list[dict], subset_ids: set[str], golds: dict) -> list[dict]:
    """Minimal capability_context repairs for kappa subset only."""
    changes = []
    by_id = {r["record_id"]: r for r in data}
    for rid in sorted(subset_ids):
        rec = by_id[rid]
        gold = golds.get(rid) or {}
        terminal = gold.get("terminal_strategy")
        actions = requested_actions(rec["command"])
        # Always repair missing execute-critical actions.
        # Also repair missing clarify-critical actions so the eventual execute path is evidenced.
        if terminal not in {"execute", "clarify"}:
            # For rejection, only add action evidence when no explicit block yet (should be rare).
            if terminal == "face_preserving_rejection" and blocking_constraints(rec):
                continue
        for action in actions:
            if action not in CAP_APPEND:
                continue
            if has_cap(rec["capability_context"], action):
                continue
            # place/handle covered by transport/move synonyms — skip synthetic place append
            if action in {"place", "handle", "move", "open", "clean", "weigh", "scan", "unlock", "dispense"}:
                continue
            new_cap, changed = ensure_action_cap(rec["capability_context"], action)
            if changed:
                changes.append(
                    {
                        "record_id": rid,
                        "family": family_of(rec["command"]),
                        "field": "capability_context",
                        "old_value": rec["capability_context"],
                        "new_value": new_cap,
                        "defect_category": "insufficient_capability_evidence",
                        "why_change_was_necessary": (
                            f"Subset record terminal={terminal} requests '{action}' but capability_context "
                            "lacked explicit factual support; public omission must not decide the route."
                        ),
                        "scope": "kappa_subset_only_minimal_repair",
                    }
                )
                rec["capability_context"] = new_cap
    return changes


def build_one_path_from_gold(rec: dict, gold: dict, cap_row: dict) -> dict:
    types = list(gold.get("ambiguity_types") or [])
    terminal = gold["terminal_strategy"]
    seq = list(gold.get("strategy_sequence") or [])
    unresolved = []
    if terminal == "clarify":
        slot = (gold.get("canonical_outcome") or {}).get("unresolved_slot") or {}
        name = slot.get("slot_name") or slot.get("name") or "unresolved_critical_slot"
        unresolved = [name]
    blocks = cap_row["blocking_constraints"]
    resolution = {}
    for t in types:
        resolution[t] = {
            "initial_alternatives": ["(see gold evidence / handbook reasoning)"],
            "resolution_source": "adjudicated_gold_v7_pilot_calibrated",
            "resolved_value": (
                "left_unresolved_for_clarification"
                if terminal == "clarify" and unresolved and t in {"fuzzy_quantity", "object_reference", "scope", "spatial_reference", "recipient_reference", "destination_reference"}
                else "context_resolved_or_grounded"
            ),
        }

    one_path = True
    notes = []
    if terminal == "clarify" and len(unresolved) != 1:
        one_path = False
        notes.append("clarify terminal must have exactly one unresolved critical slot")
    if terminal == "execute" and unresolved:
        one_path = False
        notes.append("execute terminal must have zero unresolved critical slots")
    if terminal == "face_preserving_rejection" and not blocks:
        one_path = False
        notes.append("rejection missing explicit blocking constraint in public evidence")
    if terminal == "execute" and cap_row["qa_capability_class"] == "D":
        one_path = False
        notes.append("execute still lacks positive capability evidence")
    if len(types) < 2 and gold.get("record_validity") == "valid":
        one_path = False
        notes.append("valid compound record needs >=2 ambiguity types")

    return {
        "record_id": rec["record_id"],
        "requested_actions": cap_row["requested_actions"],
        "qa_capability_class": cap_row["qa_capability_class"],
        "defensible_ambiguity_types": types,
        "resolution_evidence": resolution,
        "remaining_critical_unresolved_slots": unresolved,
        "capability_evidence": [rec["capability_context"]],
        "authorization_evidence": [
            s
            for s in [
                rec["scene_context"] if re.search(r"authoriz|approved|permit", rec["scene_context"], re.I) else "",
                rec["capability_context"] if re.search(r"authoriz|approved|permit|certif", rec["capability_context"], re.I) else "",
            ]
            if s
        ],
        "blocking_constraints": blocks,
        "canonical_route": seq,
        "terminal_strategy": terminal,
        "one_path_determinacy": one_path,
        "qa_notes": notes,
        "source": "gold_adjudicated_subset",
    }


def stub_one_path_pending(rec: dict, cap_row: dict) -> dict:
    return {
        "record_id": rec["record_id"],
        "requested_actions": cap_row["requested_actions"],
        "qa_capability_class": cap_row["qa_capability_class"],
        "defensible_ambiguity_types": [],
        "resolution_evidence": {},
        "remaining_critical_unresolved_slots": [],
        "capability_evidence": [rec["capability_context"]],
        "authorization_evidence": [],
        "blocking_constraints": cap_row["blocking_constraints"],
        "canonical_route": [],
        "terminal_strategy": None,
        "one_path_determinacy": False,
        "qa_notes": [
            "DEFERRED: full one-path contract for non-subset record not derived in this pass.",
            "Repair capability family gaps and derive owner route before freeze.",
        ],
        "source": "deferred_pending_full_pass",
        "pending_full_semantic_pass": True,
    }


def refresh_checksums() -> None:
    files = [
        "compound_ambiguity_unique_resolution_1000_v7.json",
        "compound_ambiguity_unique_resolution_1000_v7.jsonl",
        "compound_ambiguity_annotation_handbook_v7.md",
        "compound_ambiguity_annotation_output_schema_v7.json",
        "compound_ambiguity_input_schema_v7.json",
        "validate_compound_ambiguity_annotations_v7.py",
        "compound_ambiguity_unique_resolution_1000_v7_annotator_readme.md",
    ]
    checksums = {"algorithm": "sha256", "files": {}}
    base = DATA_JSON.parent
    for name in files:
        p = base / name
        if p.exists():
            checksums["files"][name] = sha256_bytes(p.read_bytes())
    write_json(CHECKSUMS, checksums)


def sync_kappa_inputs(data: list[dict], changed_ids: set[str]) -> list[str]:
    synced = []
    by_id = {r["record_id"]: r for r in data}
    for rid in sorted(changed_ids):
        ip = INPUTS / f"{rid}.json"
        if not ip.exists():
            continue
        inp = by_id[rid]
        payload = {
            "record_id": inp["record_id"],
            "command": inp["command"],
            "dialogue_history": inp["dialogue_history"],
            "scene_context": inp["scene_context"],
            "capability_context": inp["capability_context"],
        }
        write_json(ip, payload)
        synced.append(rid)
    return synced


def setup_final_protocol(subset_ids: list[str], data_by_id: dict) -> None:
    if FINAL.exists():
        # Preserve any existing empty scaffold; wipe only regenerable public inputs.
        pass
    dirs = [
        FINAL,
        FINAL / "inputs",
        FINAL / "annotator_a",
        FINAL / "annotator_b",
        FINAL / "adjudication" / "decisions",
        FINAL / "adjudication" / "packets",
        FINAL / "gold",
        FINAL / "eval",
        FINAL / "briefs",
        FINAL / "scripts",
        FINAL / "logs",
    ]
    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)

    # Copy finalized handbook/schema/brief (no pilot A/B or gold)
    shutil.copy2(HANDBOOK_SRC, FINAL / "briefs" / "handbook_v7.md")
    shutil.copy2(SCHEMA_SRC, FINAL / "briefs" / "output_schema_v7.json")
    shutil.copy2(INPUT_SCHEMA_SRC, FINAL / "briefs" / "input_schema_v7.json")
    shutil.copy2(VALIDATOR_SRC, FINAL / "scripts" / "validate_compound_ambiguity_annotations_v7.py")
    brief = BRIEF_SRC.read_text(encoding="utf-8")
    brief = brief.replace("Kappa Study", "FINAL-PROTOCOL Reannotation")
    # Strengthen isolation: no pilot annotations
    if "pilot" not in brief.lower():
        brief += (
            "\n\n## Final-protocol isolation addendum\n\n"
            "- This is an independent reannotation under the finalized handbook.\n"
            "- Do **not** read `annotations/manual_kappa_v7/` pilot A/B outputs, gold, or adjudications.\n"
            "- Do **not** read private owner QA contracts.\n"
            "- Historical pilot agreement is preserved separately as `pilot_annotation_agreement`.\n"
        )
    (FINAL / "briefs" / "annotator_brief.md").write_text(brief, encoding="utf-8")

    for rid in subset_ids:
        rec = data_by_id[rid]
        payload = {
            "record_id": rec["record_id"],
            "command": rec["command"],
            "dialogue_history": rec["dialogue_history"],
            "scene_context": rec["scene_context"],
            "capability_context": rec["capability_context"],
        }
        write_json(FINAL / "inputs" / f"{rid}.json", payload)

    write_json(
        FINAL / "subset_manifest.json",
        {
            "n": len(subset_ids),
            "record_ids": subset_ids,
            "source_seed": load_json(MANIFEST).get("seed"),
            "protocol": "final_protocol_reannotation",
            "note": "IDs match the pilot kappa subset; annotations must be produced fresh.",
        },
    )

    readme = """# Final-protocol reannotation (120)

This package supports **independent reannotation** of the 120-record evaluation subset under the **finalized** compound-ambiguity v7 protocol.

## Why this exists

Pilot double annotation (`annotations/manual_kappa_v7/`) exposed systematic defects in capability-status and ambiguity-label operationalization. After guideline calibration and selective input repairs, this package restarts annotation from a clean context.

## Do NOT use / do NOT open

- `annotations/manual_kappa_v7/annotator_a_grok/`
- `annotations/manual_kappa_v7/annotator_b_claude/`
- `annotations/manual_kappa_v7/gold/`
- `annotations/manual_kappa_v7/adjudication/`
- `annotations/private_owner_qa_v7/`
- any owner route / private QA contract

Pilot agreement metrics remain:
`pilot_annotation_agreement` (see `annotations/manual_kappa_v7/KAPPA_STRATA.md`).

New agreement metrics must be written to:
`final_protocol_annotation_agreement` (this tree).

## Layout

| Path | Role |
| --- | --- |
| `inputs/` | Clean public 120 inputs only |
| `briefs/` | Finalized handbook, schemas, annotator brief |
| `annotator_a/` | Fresh Annotator A outputs (empty at scaffold) |
| `annotator_b/` | Fresh Annotator B outputs (empty at scaffold) |
| `adjudication/` | Disagreement packets / decisions |
| `gold/` | Final-protocol gold (after adjudication) |
| `eval/` | Export-safe eval files |
| `scripts/` | Validator + launch helpers |

## Isolation rules

Same as the pilot brief: one fresh context per `(annotator, record)`. Only brief + handbook + schema + **one** input file.

## Suggested launch commands

```text
# Validate a single annotation against schema
python annotations/manual_kappa_v7_final_protocol/scripts/validate_compound_ambiguity_annotations_v7.py \\
  --annotation annotations/manual_kappa_v7_final_protocol/annotator_a/CA-XXXX.json \\
  --input annotations/manual_kappa_v7_final_protocol/inputs/CA-XXXX.json

# After both annotators finish, compute agreement INTO THIS TREE (do not overwrite pilot reports)
python scripts/compute_manual_kappa_v7.py \\
  --a-dir annotations/manual_kappa_v7_final_protocol/annotator_a \\
  --b-dir annotations/manual_kappa_v7_final_protocol/annotator_b \\
  --out annotations/manual_kappa_v7_final_protocol/final_protocol_annotation_agreement.json
```

If `compute_manual_kappa_v7.py` does not yet accept `--a-dir/--b-dir/--out`, copy the pilot script locally and point paths at this tree, writing only `final_protocol_annotation_agreement.*` here.

## Freeze distinction

- **1000 input benchmark freeze** — separate gate; currently blocked on remaining capability D records outside this subset.
- **120 gold evaluation set finalized** — only after this final-protocol double annotation + adjudication completes.
"""
    (FINAL / "README.md").write_text(readme, encoding="utf-8")

    # Placeholder agreement path
    write_json(
        FINAL / "final_protocol_annotation_agreement.json",
        {
            "status": "not_started",
            "n_expected": 120,
            "n_complete_pairs": 0,
            "note": "Populate after fresh A/B annotations. Do not copy pilot kappa numbers here.",
        },
    )


def write_deferred_notes(cap_audit: dict) -> None:
    d_count = cap_audit["counts"]["D"]
    by_action = cap_audit["d_missing_by_action"]
    by_family = cap_audit["d_by_family"]
    lines = [
        "# Deferred full-1000 semantic QA notes",
        "",
        "Owner decision (2026-08-07): **do not mass-rewrite the 1000 records now**.",
        "Use the calibrated **120 subset** for current evaluation/reannotation work.",
        "Return to this checklist before claiming `FULL 1000 INPUT BENCHMARK READY TO FREEZE`.",
        "",
        "## Do not get thrown off track — read this first",
        "",
        "1. Prior auditor repairs already fixed: capability–route circularity; clean-until-reasonably-clean;",
        "   open-beside-return-it weak pronouns; degree vs endpoint; human-gate lifecycle;",
        "   CA-0394 / CA-0739 / CA-0841 / CA-0907. **Do not undo them.**",
        "2. Omission from a short `capability_context` list is **not** evidence of incapability,",
        "   but annotators must not need handbook memory. If execution depends on an action,",
        "   state that action with factual environmental language.",
        "3. Prefer `capability_context` edits over command/ambiguity-structure edits.",
        "4. Repair **family-wide** once you leave this deferred state (siblings stay consistent).",
        "5. Preserve IDs, partitions (when present), family membership, and intended difficulty.",
        "6. Keep pilot A/B annotations intact; final-protocol reannotation is a separate tree.",
        "7. Private one-path QA contracts must never leak into annotator packages.",
        "",
        "## Current capability audit snapshot",
        "",
        f"- A / B / C / D counts: `{cap_audit['counts']}`",
        f"- D remaining (target 0 before freeze): **{d_count}**",
        f"- D missing actions: `{by_action}`",
        f"- Largest D families: `{dict(list(by_family.items())[:20])}`",
        "",
        "## Families to repair next (family-wide, smallest capability append)",
        "",
        "| Family / action | Suggested factual append (examples) |",
        "| --- | --- |",
        "| refill / top-up | `It can refill approved non-hazardous liquid containers using calibrated dosing tools within listed volume limits.` |",
        "| seal | `It can apply approved tamper-evident or official approval seals to designated containers.` |",
        "| inspect | `It can perform visual inspections of approved items with calibrated inspection cameras or assigned inspection probes.` |",
        "| charge / recharge | `It can recharge approved portable devices at designated service charging points within certified power limits.` |",
        "| deliver | `It can deliver sealed authorized items to named destinations within its certified handoff limits.` |",
        "| record / capture | `It can record document status with the assigned capture device under the named routine setup.` |",
        "",
        "If **rejection** is intended, do not leave incapability implicit — write an explicit block, e.g.",
        "`The robot's sealing head is unavailable and no approved manual sealing attachment is fitted.`",
        "",
        "## One-path contract still owed for non-subset rows",
        "",
        "For every remaining record, complete STEP 1–5 in the final semantic QA brief:",
        "surface ambiguity → context resolution → remaining critical slots → hard blocks → unique route.",
        "",
        "Fail a row if a second terminal route is equally defensible from public evidence.",
        "",
        "## Subset handled in this pass",
        "",
        "Minimal `capability_context` repairs were applied **only** to kappa-subset records that",
        "needed explicit action evidence for their gold execute/clarify paths. Outside-subset D rows",
        "are intentionally left for the later family-wide pass.",
        "",
        "## Freeze gates (copy into the next pass report)",
        "",
        "- [ ] D == 0",
        "- [ ] 1000/1000 private one-path contracts with `one_path_determinacy=true`",
        "- [ ] Execute rows have positive capability support",
        "- [ ] Rejection rows have explicit blocks",
        "- [ ] Clarify rows have exactly one unresolved critical slot",
        "- [ ] No weak pronoun padding",
        "- [ ] Degree/endpoint consistency",
        "- [ ] No private fields in public/annotator releases",
        "- [ ] Human-gated rows cannot enter final gold export",
        "- [ ] All automated semantic QA tests pass",
        "",
    ]
    DEFERRED.parent.mkdir(parents=True, exist_ok=True)
    DEFERRED.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_final_report(
    counts: Counter,
    changes: list[dict],
    subset_one_path_ok: int,
    subset_n: int,
    d_remaining: int,
) -> None:
    families_changed = sorted({c["family"] for c in changes})
    report = f"""# FINAL SEMANTIC QA REPORT — Compound Ambiguity v7

Date: 2026-08-07  
Scope decision: **minimal subset repairs + full deferred audit** (do not mass-edit the 1000 yet).

## Verdict

### 1000 input benchmark

**NOT READY TO FREEZE**

Outstanding: **{d_remaining}** category-D capability rows remain outside the intended minimal-repair scope
(see `docs/DEFERRED_FULL_1000_SEMANTIC_QA_NOTES.md` and `annotations/private_owner_qa_v7/FULL_1000_CAPABILITY_AUDIT.json`).

### 120 gold evaluation set

**NOT FINALIZED** — pilot gold remains usable for interim analysis under calibrated rules, but
`120 GOLD EVALUATION SET FINALIZED` requires completing
`annotations/manual_kappa_v7_final_protocol/` independent reannotation + adjudication.

Pilot agreement is preserved as `pilot_annotation_agreement`
(`annotations/manual_kappa_v7/KAPPA_STRATA.md`). Final-protocol agreement must be reported separately.

## Defects found

1. **Family-wide insufficient capability evidence (D)** for refill / seal / inspect / charge / deliver / record
   action families — public `capability_context` often omitted the requested action while gold/intended
   execute paths assumed capability. **Family-wide**, not isolated.
2. **Subset-critical slice of (1)** — execute (and some clarify) rows in the 120 lacked explicit action
   evidence under the finalized handbook rule. **Repaired in this pass (capability_context only).**
3. **Full 1000 one-path private contracts** still incomplete for non-subset rows (deferred; not a single
   isolated record issue).
4. Prior repaired issues (clean / open-return / degree-endpoint / human-gate / known CA-* cases) remain
   intact and must not be reverted.

## What changed this pass

| Metric | Value |
| --- | ---: |
| Records changed (subset-only capability repairs) | {len({c['record_id'] for c in changes})} |
| Families touched | {len(families_changed)} |
| `capability_context` changes | {sum(1 for c in changes if c['field']=='capability_context')} |
| `scene_context` changes | 0 |
| `command` changes | 0 |
| Replacements | 0 |

Families: `{families_changed}`

## Capability QA counts (full 1000, post subset repairs)

| Class | Count |
| --- | ---: |
| A (explicitly supported) | {counts['A']} |
| B (explicitly blocked) | {counts['B']} |
| C (capability not route-critical yet) | {counts['C']} |
| D (insufficient capability evidence) | {counts['D']} |

Target before freeze: **D == 0** (currently unmet).

## One-path QA

| Scope | Result |
| --- | --- |
| Kappa subset private contracts | {subset_one_path_ok} / {subset_n} `one_path_determinacy=true` |
| Full 1000 | Deferred stubs in `FULL_1000_ONE_PATH_QA.json` (`pending_full_semantic_pass`) |

## Artifacts

1. `FINAL_SEMANTIC_QA_REPORT.md` (this file)
2. `annotations/private_owner_qa_v7/FULL_1000_CAPABILITY_AUDIT.json`
3. `annotations/private_owner_qa_v7/FULL_1000_ONE_PATH_QA.json`
4. `annotations/private_owner_qa_v7/FINAL_SEMANTIC_REPAIR_CHANGELOG.json`
5. Updated 1000-record JSON / JSONL (subset capability_context repairs only)
6. Updated checksums
7. Handbook unchanged this pass (prior degree/endpoint + capability rules already present)
8. Validator unchanged this pass
9. Extended `tests/test_compound_ambiguity_v7_qa.py`
10–12. Annotator/experimenter/public fields unchanged aside from repaired subset inputs synced into kappa + final-protocol trees
13. `annotations/manual_kappa_v7_final_protocol/` scaffold
14. `docs/DEFERRED_FULL_1000_SEMANTIC_QA_NOTES.md`

## Exact commands to run next

```text
# 1) Automated QA
python -m pytest tests/test_compound_ambiguity_v7_qa.py -q

# 2) Review deferred full-1000 checklist before any freeze claim
#    docs/DEFERRED_FULL_1000_SEMANTIC_QA_NOTES.md

# 3) Start final-protocol reannotation (fresh contexts; do not read pilot A/B/gold)
#    See annotations/manual_kappa_v7_final_protocol/README.md

# 4) When ready for the deferred full-1000 repair:
python scripts/final_semantic_qa_v7_pass.py --help
# then implement family-wide D repairs in a dedicated follow-up (do not silent-regenerate).
```
"""
    REPORT.write_text(report, encoding="utf-8")


def main() -> int:
    data = load_json(DATA_JSON)
    subset_manifest = load_json(MANIFEST)
    subset_ids = list(subset_manifest["record_ids"])
    subset_set = set(subset_ids)
    golds = {}
    for p in GOLD.glob("CA-*.json"):
        g = load_json(p)
        golds[g["record_id"]] = g

    # Phase: subset-only capability repairs
    prior_changelog_path = OWNER / "FINAL_SEMANTIC_REPAIR_CHANGELOG.json"
    prior_changes = []
    if prior_changelog_path.exists():
        try:
            prior_changes = load_json(prior_changelog_path).get("changes") or []
        except Exception:
            prior_changes = []

    changes = repair_subset_capabilities(data, subset_set, golds)
    if not changes and prior_changes:
        changes = prior_changes


    # Write dataset if changed
    if changes:
        DATA_JSON.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        DATA_JSONL.write_text(
            "\n".join(json.dumps(r, ensure_ascii=False) for r in data) + "\n", encoding="utf-8"
        )
        sync_kappa_inputs(data, {c["record_id"] for c in changes})
        refresh_checksums()

    # Capability audit for all 1000 (post-repair)
    cap_rows = []
    for r in data:
        cap_rows.append(classify_capability(r, golds.get(r["record_id"])))
    counts = Counter(r["qa_capability_class"] for r in cap_rows)
    d_rows = [r for r in cap_rows if r["qa_capability_class"] == "D"]
    d_missing_by_action = Counter(a for r in d_rows for a in r["missing_actions"])
    d_by_family = Counter(r["family"] for r in d_rows)

    cap_audit = {
        "n_records": len(cap_rows),
        "counts": dict(counts),
        "d_missing_by_action": dict(d_missing_by_action),
        "d_by_family": dict(d_by_family.most_common()),
        "subset_counts": dict(Counter(r["qa_capability_class"] for r in cap_rows if r["in_kappa_subset"])),
        "policy": "subset_minimal_repair_full_d_deferred",
        "records": cap_rows,
    }
    write_json(OWNER / "FULL_1000_CAPABILITY_AUDIT.json", cap_audit)

    # One-path contracts: full for subset gold; deferred stubs elsewhere
    one_path_rows = []
    cap_by_id = {r["record_id"]: r for r in cap_rows}
    data_by_id = {r["record_id"]: r for r in data}
    for r in data:
        cap_row = cap_by_id[r["record_id"]]
        if r["record_id"] in golds:
            one_path_rows.append(build_one_path_from_gold(r, golds[r["record_id"]], cap_row))
        else:
            one_path_rows.append(stub_one_path_pending(r, cap_row))
    subset_ok = sum(
        1 for row in one_path_rows if row["record_id"] in subset_set and row.get("one_path_determinacy")
    )
    write_json(
        OWNER / "FULL_1000_ONE_PATH_QA.json",
        {
            "n_records": len(one_path_rows),
            "subset_one_path_true": subset_ok,
            "subset_n": len(subset_set),
            "full_one_path_true": sum(1 for row in one_path_rows if row.get("one_path_determinacy")),
            "policy": "subset_from_gold_remainder_deferred",
            "records": one_path_rows,
        },
    )

    write_json(
        OWNER / "FINAL_SEMANTIC_REPAIR_CHANGELOG.json",
        {
            "n_changes": len(changes),
            "n_records_touched": len({c["record_id"] for c in changes}),
            "families_changed": sorted({c["family"] for c in changes}),
            "scope": "kappa_subset_only_minimal_repair",
            "changes": changes,
        },
    )

    # Owner README
    (OWNER / "README.md").write_text(
        "# Private owner QA package (v7)\n\n"
        "Owner-only. Do **not** ship to annotators.\n\n"
        "Contains capability audit, one-path contracts, and repair changelog for the final semantic QA pass.\n",
        encoding="utf-8",
    )

    setup_final_protocol(subset_ids, data_by_id)
    write_deferred_notes(cap_audit)
    write_final_report(counts, changes, subset_ok, len(subset_set), counts["D"])

    summary = {
        "records_changed": len({c["record_id"] for c in changes}),
        "families_changed": sorted({c["family"] for c in changes}),
        "capability_counts": dict(counts),
        "subset_one_path_ok": subset_ok,
        "d_remaining": counts["D"],
        "freeze_1000": False,
        "freeze_120_gold": False,
    }
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
