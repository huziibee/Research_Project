# Pilot-120 human gate status (UPDATED)

## Current owner gold policy

Decision recorded in `data/annotations/pilot_120_v1/GOLD_POLICY.json`:

**Use existing Grok × Claude/GLM + adjudicated pilot gold** as Pilot-120 evaluation gold.

Under this policy:

- Steven James / Benjamin Rosman **fresh reannotation is NOT required** to freeze Pilot-120
- ADJ-01 fresh resolution is **NOT required** for this freeze (pilot adjudication already applied)
- Agreement remains labelled **`pilot_annotation_agreement`**
- Do **NOT** claim Steve/Ben final-protocol annotation

Honest freeze claim:

`Pilot-120 v1: PILOT-ADJUDICATED GOLD (Grok×Claude/GLM), CAPABILITY-REPAIRED SOURCE, FROZEN, HASHED, EVALUATION-ONLY`

## What did change in the inputs

20 records received `capability_context`-only factual repairs to match handbook evidence rules.
Those repairs support the existing gold routes; labels were **not** rewritten by the repair pass.

## Optional future upgrade (not required for current freeze)

If supervisors later want a separate `final_protocol_annotation_agreement`, use the
blind packages under `packages/` and the Steve/Ben import commands. That would be a
**new** gold version, not a silent rewrite of this freeze.

## Evaluate

```text
python -m ambiguity_manager.evaluation.pilot_120_cli evaluate \
  --config configs/evaluation/pilot_120_v1.json \
  --predictions <PREDICTIONS.jsonl>
```
