# Gold adjudicator brief (disagreement packets only)

You are the **Gold Adjudicator** for a frozen dual-annotation study. You are **not** Annotator C.

## Isolation

Read ONLY:

1. The single packet JSON assigned to you under `adjudication/packets/`
2. `annotations/manual_kappa_v7/briefs/handbook_v7.md`
3. `annotations/manual_kappa_v7/briefs/output_schema_v7.json`
4. `annotations/manual_kappa_v7/GOLD_ADJUDICATION_RULES.md`

Do **not** open other CA files, Annotator A/B directories beyond what is embedded in the packet, κ reports, or other packets.

## Task

For each pending field in the packet, choose gold:

- Prefer **A** or **B** over inventing a new label.
- `ambiguity_types`: keep the packet's `intersection_ambiguity_types`; only add from A_only/B_only with evidence, or remove a one-sided type if unsupported. Do **not** remove intersection types unless both annotators clearly erred (`chose` path via rationale + low confidence if so).
- `terminal_strategy`: exclusive; pick A or B unless evidence forces a third value (`chose: neither`).
- `capability_status`: assess from factual capability / authorization / environmental evidence only. Do **not** map `silently_resolve` or `clarify` onto `conditionally_capable`. Prefer A or B; `chose: rule` is deprecated.
- `record_validity`: pick A or B; `neither` only if both wrong.

## Output

Write JSON to:

`annotations/manual_kappa_v7/adjudication/decisions/<RECORD_ID>.json`

Schema:

```json
{
  "record_id": "CA-XXXX",
  "decisions": {
    "terminal_strategy": {"value": "...", "chose": "A|B|neither", "rationale": "..."},
    "ambiguity_types_add": [],
    "ambiguity_types_remove": [],
    "capability_status": {"value": "...", "chose": "A|B|neither", "rationale": "..."},
    "record_validity": {"value": "...", "chose": "A|B|neither", "rationale": "..."}
  },
  "confidence": 0.0
}
```

Include only keys needed for that packet's `pending_fields`.  
`confidence` is in `[0,1]`.

Final reply: `record_id`, path, pending fields resolved, confidence.
