#!/usr/bin/env python3
"""Apply auditor gold/lifecycle repairs for manual kappa v7 after dataset QA."""
from __future__ import annotations

import json
import re
from copy import deepcopy
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "annotations" / "manual_kappa_v7"
GOLD = OUT / "gold"
IN_DIR = OUT / "inputs"
DECISIONS = OUT / "adjudication" / "decisions"
CHANGELOG = OUT / "adjudication" / "QA_GOLD_REPAIR_CHANGELOG.json"

# Records with route-derived capability_status=conditionally_capable from
# silently_resolve / clarify handbook convention, and no evidenced external
# capability precondition beyond ordinary certified transport limits.
EXTERNAL_PRECONDITION = re.compile(
    r"battery (?:above|below|at)|payload (?:above|below|within)|credential|"
    r"tool (?:attached|missing)|approved accessory|once the .{0,40} is|"
    r"provided that|requires the .{0,30} attachment",
    re.I,
)

OPEN_FAMILY = {
    "CA-0086",
    "CA-0245",
    "CA-0654",
    "CA-0686",
    "CA-0808",
    "CA-0841",
}
CLEAN_FAMILY = {"CA-0197", "CA-0421", "CA-0739", "CA-0907", "CA-0967"}


def load(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8-sig"))


def dump(p: Path, obj: dict) -> None:
    p.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def has_external_precondition(inp: dict) -> bool:
    blob = f"{inp.get('scene_context','')} {inp.get('capability_context','')}"
    return bool(EXTERNAL_PRECONDITION.search(blob))


def set_lifecycle(g: dict) -> None:
    if g.get("human_gate_required"):
        g["gold_lifecycle"] = "human_review_required"
    elif g.get("gold_status") == "adjudicated":
        g["gold_lifecycle"] = "final_gold"
    else:
        g["gold_lifecycle"] = "final_gold"


def patch(rid: str, mutator, changes: list) -> None:
    path = GOLD / f"{rid}.json"
    old = load(path)
    new = deepcopy(old)
    mutator(new)
    set_lifecycle(new)
    if new != old:
        # record field-level diffs
        for key in sorted(set(old) | set(new)):
            if old.get(key) != new.get(key):
                changes.append(
                    {
                        "record_id": rid,
                        "field": key,
                        "old": old.get(key),
                        "new": new.get(key),
                        "reason": getattr(mutator, "reason", "auditor QA repair"),
                    }
                )
        dump(path, new)


def main() -> int:
    changes: list[dict] = []

    # --- CA-0394: singular NP → clarify ---
    def mut_0394(g: dict) -> None:
        g["terminal_strategy"] = "clarify"
        g["capability_status"] = "capable"
        g["strategy_sequence"] = ["reinterpret_indirect_request", "clarify"]
        g["field_status"] = {
            **g.get("field_status", {}),
            "terminal_strategy": "human_auditor:A",
            "capability_status": "human_auditor:independent",
            "strategy_sequence": "human_auditor:A",
        }
        g["human_gate_required"] = False
        g.pop("human_gate_status", None)
        g["gold_status"] = "adjudicated"
        g["adjudication_confidence"] = 1.0
        g.setdefault("provenance", {})["human_auditor_repair"] = (
            "singular 'the selected exam packet' does not denote the full batch; "
            "one unresolved object slot remains → clarify"
        )

    mut_0394.reason = "CA-0394 singular NP clarify"
    patch("CA-0394", mut_0394, changes)
    dump(
        DECISIONS / "CA-0394.json",
        {
            "record_id": "CA-0394",
            "decisions": {
                "terminal_strategy": {
                    "value": "clarify",
                    "chose": "A",
                    "rationale": "Human auditor: singular selected NP leaves one object slot unresolved despite active batch linking both items temporally.",
                },
                "capability_status": {
                    "value": "capable",
                    "chose": "neither",
                    "rationale": "Independent capability: delivery is within certified transport/access limits; linguistic clarify does not imply conditionally_capable.",
                },
            },
            "confidence": 1.0,
            "human_auditor": True,
        },
    )

    # --- CA-0739 / CA-0907: execute with explicit clean capability; endpoint only ---
    def mut_clean(g: dict) -> None:
        types = [t for t in g.get("ambiguity_types", []) if t != "degree_vagueness"]
        if "endpoint_vagueness" not in types:
            types.append("endpoint_vagueness")
        g["ambiguity_types"] = sorted(types)
        g["terminal_strategy"] = "execute"
        g["capability_status"] = "capable"
        g["strategy_sequence"] = ["silently_resolve", "execute"]
        g["field_status"] = {
            **g.get("field_status", {}),
            "terminal_strategy": "human_auditor:A",
            "ambiguity_types": "human_auditor:endpoint_only",
            "capability_status": "human_auditor:independent",
            "strategy_sequence": "human_auditor:A",
        }
        g["human_gate_required"] = False
        g.pop("human_gate_status", None)
        g["gold_status"] = "adjudicated"
        g["adjudication_confidence"] = 1.0
        g.setdefault("provenance", {})["human_auditor_repair"] = (
            "capability_context now states exterior cleaning; "
            "'reasonably clean' counted as endpoint_vagueness only; "
            "capability independent of silently_resolve"
        )

    mut_clean.reason = "clean family execute + endpoint_only + capable"
    for rid in ("CA-0739", "CA-0907"):
        patch(rid, mut_clean, changes)
        dump(
            DECISIONS / f"{rid}.json",
            {
                "record_id": rid,
                "decisions": {
                    "terminal_strategy": {
                        "value": "execute",
                        "chose": "A",
                        "rationale": "Human auditor: slots deterministically grounded; cleaning capability made explicit in public record.",
                    },
                    "ambiguity_types_add": [],
                    "ambiguity_types_remove": ["degree_vagueness"],
                    "capability_status": {
                        "value": "capable",
                        "chose": "neither",
                        "rationale": "Independent capability after explicit cleaning evidence; not derived from silently_resolve.",
                    },
                },
                "confidence": 1.0,
                "human_auditor": True,
            },
        )

    # --- CA-0841: spatial + temporal; drop weak pronoun ---
    def mut_0841(g: dict) -> None:
        g["ambiguity_types"] = sorted(["spatial_reference", "temporal_reference"])
        g["record_validity"] = "valid"
        g["terminal_strategy"] = "face_preserving_rejection"
        g["capability_status"] = "unauthorized"
        g["strategy_sequence"] = ["resolve_reference", "face_preserving_rejection"]
        g["field_status"] = {
            **g.get("field_status", {}),
            "record_validity": "human_auditor:valid",
            "ambiguity_types": "human_auditor:spatial+temporal",
            "capability_status": "auto_agree",
            "terminal_strategy": "auto_agree",
            "strategy_sequence": "from_A_matching_terminal",
        }
        g["human_gate_required"] = False
        g.pop("human_gate_status", None)
        g["gold_status"] = "adjudicated"
        g["adjudication_confidence"] = 1.0
        g.setdefault("provenance", {})["human_auditor_repair"] = (
            "weak pronoun_reference removed; scene now has two checks with deterministic job link "
            "→ temporal_reference + spatial_reference; seal block remains unauthorized rejection"
        )

    mut_0841.reason = "CA-0841 spatial+temporal rejection"
    patch("CA-0841", mut_0841, changes)
    dump(
        DECISIONS / "CA-0841.json",
        {
            "record_id": "CA-0841",
            "decisions": {
                "record_validity": {
                    "value": "valid",
                    "chose": "A",
                    "rationale": "Human auditor: after scene repair, spatial_reference and temporal_reference are both defensible; weak pronoun dropped.",
                },
                "ambiguity_types_add": ["temporal_reference"],
                "ambiguity_types_remove": ["pronoun_reference"],
                "capability_status": {
                    "value": "unauthorized",
                    "chose": "agree",
                    "rationale": "Tamper-evident seal / no opening code remains hard auth block.",
                },
            },
            "confidence": 1.0,
            "human_auditor": True,
        },
    )

    # --- Open-family siblings in subset: drop weak pronoun; ensure temporal ---
    for rid in sorted(OPEN_FAMILY - {"CA-0841"}):
        def mut(g: dict, _rid=rid) -> None:
            types = set(g.get("ambiguity_types") or [])
            types.discard("pronoun_reference")
            types.add("spatial_reference")
            types.add("temporal_reference")
            # keep endpoint if already present (CA-0808)
            g["ambiguity_types"] = sorted(types)
            g.setdefault("provenance", {})["human_auditor_repair"] = (
                g.get("provenance", {}).get("human_auditor_repair", "")
                + f"; open-family type repair ({_rid}): drop weak pronoun; keep/add temporal after scene dual-check repair"
            ).lstrip("; ")
            if g.get("field_status"):
                g["field_status"]["ambiguity_types"] = "human_auditor:open_family"

        mut.reason = "open-family sibling type repair"
        patch(rid, mut, changes)

    # --- Clean-family siblings: drop degree; capability independent ---
    for rid in sorted(CLEAN_FAMILY - {"CA-0739", "CA-0907"}):
        def mut(g: dict, _rid=rid) -> None:
            types = [t for t in g.get("ambiguity_types", []) if t != "degree_vagueness"]
            if "endpoint_vagueness" not in types:
                types.append("endpoint_vagueness")
            g["ambiguity_types"] = sorted(types)
            if g.get("terminal_strategy") == "execute" and not has_external_precondition(
                load(IN_DIR / f"{_rid}.json")
            ):
                if g.get("capability_status") == "conditionally_capable":
                    g["capability_status"] = "capable"
                    if g.get("field_status"):
                        g["field_status"]["capability_status"] = "human_auditor:independent"
            g.setdefault("provenance", {})["human_auditor_repair"] = (
                "clean-family: endpoint_vagueness only; capability not derived from silently_resolve"
            )
            if g.get("field_status"):
                g["field_status"]["ambiguity_types"] = "human_auditor:endpoint_only"

        mut.reason = "clean-family sibling repair"
        patch(rid, mut, changes)

    # --- Global: backfill lifecycle + fix route-derived conditionally_capable ---
    for path in sorted(GOLD.glob("CA-*.json")):
        g = load(path)
        old = deepcopy(g)
        rid = g["record_id"]
        inp = load(IN_DIR / f"{rid}.json")
        # route-derived convention cleanup
        if (
            g.get("capability_status") == "conditionally_capable"
            and g.get("terminal_strategy") in {"execute", "clarify"}
            and not has_external_precondition(inp)
        ):
            # Prefer capable unless rejection-flavored terminal (handled separately)
            seq = g.get("strategy_sequence") or []
            if "silently_resolve" in seq or g.get("terminal_strategy") == "clarify":
                g["capability_status"] = "capable"
                fs = g.setdefault("field_status", {})
                if fs.get("capability_status") in {"rule", "adjudicated:rule", "auto_agree"}:
                    fs["capability_status"] = "human_auditor:independent_from_route"
                g.setdefault("provenance", {})["capability_route_decouple"] = (
                    "conditionally_capable remapped to capable: no evidenced external capability precondition; "
                    "linguistic silently_resolve/clarify is not a capability condition"
                )
        # do not clear gates here except already patched
        set_lifecycle(g)
        if g != old:
            for key in sorted(set(old) | set(g)):
                if old.get(key) != g.get(key):
                    changes.append(
                        {
                            "record_id": rid,
                            "field": key,
                            "old": old.get(key),
                            "new": g.get(key),
                            "reason": "lifecycle backfill and/or capability-route decoupling",
                        }
                    )
            dump(path, g)

    CHANGELOG.write_text(json.dumps({"n_changes": len(changes), "changes": changes}, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"n_changes": len(changes), "n_records": len({c['record_id'] for c in changes})}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
