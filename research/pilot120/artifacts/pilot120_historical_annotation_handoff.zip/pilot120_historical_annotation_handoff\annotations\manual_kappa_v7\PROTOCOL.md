# Manual Kappa Study v7 — Status & Protocol

## Locked decisions

| Item | Choice |
| --- | --- |
| Taxonomy | Compound Ambiguity **handbook v7** (17 types); literature mapping is appendix-only |
| Subset | **120** stratified records (`seed=20260807`) |
| Annotators | **A = Grok** (`cursor-grok-4.5-high-fast`); **B = Claude** (`claude-4.6-sonnet-medium-thinking`) for **70** Claude-era records; **B = GLM** (`glm-5.2-high`) for **50** GLM-era records (mid-study cost switch) |
| Isolation | One fresh subagent per `(annotator, record)`; may only read brief/handbook/schema/mapping + that one input |
| Generator | **No GPT Sol** / no generator labels |
| Agreement | Cohen κ on exclusive fields + per-label κ on `ambiguity_types` + mean Jaccard; report **all** + **Claude-era** + **GLM-era** strata |
| Core gold (v1) | `terminal_strategy` + `ambiguity_types` (+ `capability_status` under locked rule). See `GOLD_ADJUDICATION_RULES.md` |

## Mid-study Annotator B switch

**2026-08-07:** Claude Sonnet/Opus launches stopped for cost. Existing Claude B files kept. Remaining Annotator B = `glm-5.2-high` (still writes to `annotator_b_claude/`). Annotator A stays Grok.

**Frozen roster:** `annotations/manual_kappa_v7/annotator_b_model_roster.json`  
- Claude-era: **70** IDs (through launch-log reconstruction; max id in stratum `CA-0611`)  
- GLM-era: **50** IDs (complement; min id `CA-0618`)  
- Provenance: Task launch logs (file mtimes not usable)

**Status: COMPLETE** — 120/120 paired. Stratified κ in `KAPPA_STRATA.md` / `kappa_report_*.json`.

## Annotator B policy-block exceptions

If the primary B model refuses a record due to provider usage policy (not annotator error), Annotator B for **that record only** may be replaced by a non-Grok, non–GPT-Sol model. Output still goes to `annotator_b_claude/`. Document each exception below.

| record_id | Final B model | Reason |
| --- | --- | --- |
| CA-0440 | `claude-4.6-opus-high-thinking` (Claude era) | Initial Claude Sonnet Usage Policy block; Kimi substitute resource_exhausted; GLM substitute wrote then **reverted** in favor of successful Claude Opus B annotation |

## Paths

- Inputs: `annotations/manual_kappa_v7/inputs/CA-XXXX.json`
- Grok outs: `annotations/manual_kappa_v7/annotator_a_grok/`
- B outs (Claude + GLM eras): `annotations/manual_kappa_v7/annotator_b_claude/`
- Manifest: `annotations/manual_kappa_v7/subset_manifest.json`
- B-model roster: `annotations/manual_kappa_v7/annotator_b_model_roster.json`
- Kappa script: `scripts/compute_manual_kappa_v7.py`
- Kappa reports: `kappa_report.json`, `kappa_report_claude_era.json`, `kappa_report_glm_era.json`, `KAPPA_STRATA.md`
- Gold rules: `GOLD_ADJUDICATION_RULES.md`
- Gold builder: `scripts/build_manual_kappa_v7_gold.py`
- Gold: `annotations/manual_kappa_v7/gold/`
- Eval export: `annotations/manual_kappa_v7/eval/subset_120_eval.jsonl`

## Dual annotation complete

Do not re-launch dual annotators. Disagreements go through Sonnet adjudication packets (disagreements only); human gate for terminal conflicts, `chose:neither`, and validity conflicts.
