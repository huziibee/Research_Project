# Gold adjudication rules (manual Kappa v7) — gold-v1

Taxonomy handbook v7 governs linguistic/capability semantics. These rules govern how dual annotations become **core gold**, including lifecycle separation from final exports.

## Core gold fields (v1)

| Field | In gold-v1? | Notes |
| --- | --- | --- |
| `terminal_strategy` | **yes** | Primary routing label for eval |
| `ambiguity_types` | **yes** | Multi-label type inventory |
| `capability_status` | **yes** | Independently grounded (see below) |
| `record_validity` | **yes** | Must be `valid` for cluster eval inclusion |
| `recommended_strategy` | no | Weak κ; exploratory only |
| `primary_ambiguity_type` | no | Tie-break noise; exploratory only |
| `risk_level` | no | Adjacent-band drift; exploratory only |
| `strategy_sequence` | retained as provenance when agreed or adjudicated with terminal | Not a primary κ field |
| `gold_lifecycle` | **yes** | See lifecycle section |

## Promotion rules

### Agreement auto-promote

- If Annotator A and B agree on a core field → that value is gold (`field_status` = `auto_agree`).
- A third model must **never** rewrite silent agreements unless a locked human auditor repair revises a defective convention (recorded in provenance).

### `ambiguity_types`

1. Gold always includes **A ∩ B**.
2. Adjudicator only decides the **symmetric difference** (A−B and B−A): add, drop, or keep neither / both with rationale.
3. Final gold set = `(A ∩ B) ∪ adjudicator_adds − adjudicator_removes`, with removes limited to labels that were only on one side unless evidence shows both annotators erred (requires `chose: neither` + human gate).
4. **Never** add a weak ambiguity label solely so `len(types) >= 2` or so `record_validity` flips from invalid to valid. Every added label must cite two initially plausible alternatives and relevance to command interpretation.

### `terminal_strategy`

- Exclusive label.
- On disagreement, adjudicator must prefer `chose: A` or `chose: B`.
- A third terminal value requires evidence quotes from the input and `chose: neither`, then **human gate**.

### `capability_status` (locked — route-independent)

Capability is assessed from factual capability / authorization / environmental evidence only.

Apply in order:

1. If A and B agree → use that value.
2. Else if the scene/capability fields show an explicit hard capability / authorization / safety block that clarification cannot cure → prefer A or B’s matching `incapable` / `unauthorized` / `unsafe` as supported by evidence (adjudicator picks A or B).
3. Else if still conflict → adjudicator packet (`chose: A|B|neither`). **Do not** auto-map `silently_resolve ∈ strategy_sequence` to `conditionally_capable`. Linguistic silent resolution / clarification is not a capability precondition.

Meanings (handbook §8):

- `capable`: physically/technically feasible; no explicit capability condition blocks.
- `conditionally_capable`: real external capability precondition (tool, payload/battery threshold, credential, equipment state, approved accessory, environmental condition).
- `incapable` / `unauthorized` / `unsafe`: explicit hard blocks.

### `record_validity`

- Agreement → promote.
- Disagreement → packet + **human gate**.

## Gold lifecycle (required)

| `gold_lifecycle` | Meaning |
| --- | --- |
| `auto_agreed` | All core fields from A/B agreement (no adjudication). |
| `adjudicated_provisional` | ≥1 field adjudicated; not yet human-cleared when a gate applies, or awaiting export classification. |
| `human_review_required` | `human_gate_required == true`. **Must not** enter final gold export. |
| `final_gold` | Cleared for training/evaluation export (`human_gate_required == false`). |

Rules:

- If `human_gate_required` → `gold_lifecycle` **must** be `human_review_required`.
- Final eval/export scripts **must fail** if any exported row has `human_gate_required == true` or `gold_lifecycle == human_review_required`.
- Legacy `gold_status` values (`auto_agree`, `auto_agree_with_rule`, `adjudicated`) remain as provenance; `gold_lifecycle` is authoritative for export safety.

## Adjudicator (Claude Sonnet)

- Sees **disagreement packets only** (never silent agreements).
- Isolation: packet + handbook v7 + output schema (+ this rules file).
- Not Annotator C for κ; decisions do not enter inter-annotator agreement metrics.
- Prefer selecting A or B over inventing labels.
- Type-only packets with confidence ≥ 0.7 and `chose` in `{A,B}` (type adds/drops clearly sourced from one side) may auto-accept.
- **Human gate:** all terminal disagreements; any `chose: neither`; validity conflicts.

## Packet output schema

```json
{
  "record_id": "CA-XXXX",
  "decisions": {
    "terminal_strategy": {"value": "...", "chose": "A|B|neither|agree", "rationale": "..."},
    "ambiguity_types_add": [],
    "ambiguity_types_remove": [],
    "capability_status": {"value": "...", "chose": "A|B|neither|agree", "rationale": "..."},
    "record_validity": {"value": "...", "chose": "A|B|neither|agree", "rationale": "..."}
  },
  "confidence": 0.0
}
```

Omit decision keys that are not pending for that packet. `chose: rule` is deprecated for capability (route-derived rules removed).

## Out of scope for gold-v1

Do not freeze `recommended_strategy`, `primary_ambiguity_type`, or `risk_level` into eval gold. Keep dual annotations for qualitative analysis.
